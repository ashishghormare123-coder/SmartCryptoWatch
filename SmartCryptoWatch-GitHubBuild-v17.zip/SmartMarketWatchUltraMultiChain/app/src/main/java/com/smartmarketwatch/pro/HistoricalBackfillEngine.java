package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * v8 historical qualification backfill with stablecoin and wrapped-native base legs.
 *
 * Goal: a freshly discovered wallet should not have to wait days before the qualification
 * engine has enough evidence. For Solana we replay recent wallet transactions through the
 * same transaction-delta logic used by the live scanner. For EVM chains we use public
 * Blockscout address token-transfer history where available and only learn swap-like
 * transfers that contain an explicit USD-stablecoin leg. This deliberately ignores
 * ambiguous airdrops/transfers and native-only swaps rather than inventing PnL.
 *
 * Historical events update SmartTraderQualificationEngine only; they are never added to
 * EarlyTokenStore and never generate user notifications.
 */
public final class HistoricalBackfillEngine {
    private static final String PREF = "scw";
    private static final long SUCCESS_TTL_MS = 24L * 60L * 60L * 1000L;
    private static final long RETRY_TTL_MS = 2L * 60L * 60L * 1000L;
    private static final int SOL_SIGNATURE_LIMIT = 40;
    private static final int MAX_EVM_TRANSFERS = 100;
    private static final double MIN_STABLE_LEG_USD = 50.0;

    private HistoricalBackfillEngine() {}

    public static final class Result {
        public int eventsLearned;
        public int closedAfter;
        public int scoreAfter;
        public boolean qualifiedAfter;
        public boolean attempted;
        public String source = "";
        public String error = "";
    }

    public static Result maybeBackfill(Context context, String chainSlug, String wallet, String label) {
        Result r = new Result();
        if (wallet == null || wallet.trim().isEmpty()) return r;
        String chain = norm(chainSlug);
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String key = "hist_v8_" + Integer.toHexString((chain + "|" + wallet.toLowerCase(Locale.US)).hashCode());
        long last = p.getLong(key + "_at", 0L);
        boolean priorSuccess = p.getBoolean(key + "_ok", false);
        long ttl = priorSuccess ? SUCCESS_TTL_MS : RETRY_TTL_MS;
        if (last > 0 && System.currentTimeMillis() - last < ttl) return r;
        r.attempted = true;

        try {
            if ("solana".equals(chain)) {
                r.source = "Solana RPC history";
                r.eventsLearned = CryptoEngine.backfillSolanaCandidate(context, wallet, label, SOL_SIGNATURE_LIMIT);
            } else if (isEvmAddress(wallet)) {
                ChainHistory h = chainHistory(chain);
                if (h == null) {
                    r.error = "history provider unavailable for " + chain;
                } else {
                    r.source = "Blockscout ERC-20 history";
                    r.eventsLearned = backfillEvm(context, h, chain, wallet, label);
                }
            }
        } catch (Exception e) {
            r.error = clean(e.getMessage());
        }

        SmartTraderQualificationEngine.Profile profile = SmartTraderQualificationEngine.getProfile(context, chain, wallet);
        if (profile != null) {
            r.closedAfter = profile.observedClosed;
            r.scoreAfter = profile.score;
            r.qualifiedAfter = "QUALIFIED".equals(profile.status);
        }
        boolean ok = r.eventsLearned > 0 || r.closedAfter > 0;
        p.edit().putLong(key + "_at", System.currentTimeMillis()).putBoolean(key + "_ok", ok).apply();
        return r;
    }

    private static int backfillEvm(Context context, ChainHistory h, String chainSlug, String wallet, String label) throws Exception {
        String endpoint = h.blockscoutBase + "/api/v2/addresses/" + wallet + "/token-transfers?type=ERC-20";
        JSONObject root = getJson(endpoint);
        JSONArray items = root.optJSONArray("items");
        if (items == null || items.length() == 0) return 0;

        // Blockscout returns newest first. Group by tx, then replay oldest -> newest.
        Map<String, TxGroup> groups = new LinkedHashMap<>();
        int count = Math.min(MAX_EVM_TRANSFERS, items.length());
        for (int i = 0; i < count; i++) {
            JSONObject x = items.optJSONObject(i);
            if (x == null) continue;
            String tx = x.optString("transaction_hash", x.optString("transactionHash", x.optString("hash", "")));
            if (tx.isEmpty()) continue;
            TxGroup g = groups.get(tx);
            if (g == null) { g = new TxGroup(); g.txHash = tx; groups.put(tx, g); }
            g.timestamp = Math.max(g.timestamp, parseTime(x.optString("timestamp", "")));

            String from = addressOf(x.opt("from"));
            String to = addressOf(x.opt("to"));
            JSONObject token = x.optJSONObject("token");
            if (token == null) continue;
            String tokenAddress = token.optString("address_hash", token.optString("address", ""));
            String symbol = token.optString("symbol", "");
            String name = token.optString("name", symbol);
            int decimals = parseInt(token.optString("decimals", "18"), 18);
            double amount = transferAmount(x, decimals);
            if (tokenAddress.isEmpty() || amount <= 0) continue;

            Transfer t = new Transfer();
            t.address = tokenAddress.toLowerCase(Locale.US); t.symbol = symbol; t.name = name; t.amount = amount;
            boolean incoming = wallet.equalsIgnoreCase(to);
            boolean outgoing = wallet.equalsIgnoreCase(from);
            if (!incoming && !outgoing) continue;
            if (isStable(symbol)) {
                if (incoming) g.stableIn += amount;
                if (outgoing) g.stableOut += amount;
            } else if (isWrappedBase(symbol)) {
                // Blockscout often includes an exchange_rate for wrapped native assets.
                // Use that only as approximate historical qualification evidence.
                double usdRate = tokenUsd(token);
                if (usdRate > 0) {
                    if (incoming) g.baseInUsd += amount * usdRate;
                    if (outgoing) g.baseOutUsd += amount * usdRate;
                }
            } else {
                if (incoming) g.ins.add(t);
                if (outgoing) g.outs.add(t);
            }
        }

        List<TxGroup> ordered = new ArrayList<>(groups.values());
        Collections.sort(ordered, Comparator.comparingLong(a -> a.timestamp));
        int learned = 0;
        for (TxGroup g : ordered) {
            if (g.timestamp <= 0) continue;
            double buyUsd = g.stableOut >= MIN_STABLE_LEG_USD ? g.stableOut : g.baseOutUsd;
            double sellUsd = g.stableIn >= MIN_STABLE_LEG_USD ? g.stableIn : g.baseInUsd;
            if (buyUsd >= MIN_STABLE_LEG_USD && !g.ins.isEmpty()) {
                double eachUsd = buyUsd / Math.max(1, g.ins.size());
                boolean approximate = g.stableOut < MIN_STABLE_LEG_USD;
                for (Transfer t : g.ins) {
                    EarlyTokenStore.Event e = historyEvent(h, chainSlug, wallet, label, g, t, "BUY", eachUsd, approximate);
                    SmartTraderQualificationEngine.processEvent(context, e);
                    learned++;
                }
            }
            if (sellUsd >= MIN_STABLE_LEG_USD && !g.outs.isEmpty()) {
                double eachUsd = sellUsd / Math.max(1, g.outs.size());
                boolean approximate = g.stableIn < MIN_STABLE_LEG_USD;
                for (Transfer t : g.outs) {
                    if (!SmartTraderQualificationEngine.hasOpenPosition(context, chainSlug, wallet, t.address)) continue;
                    EarlyTokenStore.Event e = historyEvent(h, chainSlug, wallet, label, g, t, "SELL", eachUsd, approximate);
                    SmartTraderQualificationEngine.processEvent(context, e);
                    learned++;
                }
            }
        }
        return learned;
    }

    private static EarlyTokenStore.Event historyEvent(ChainHistory h, String chainSlug, String wallet, String label,
                                                       TxGroup g, Transfer t, String action, double usd, boolean approximateNative) {
        EarlyTokenStore.Event e = new EarlyTokenStore.Event();
        e.id = "hist|" + chainSlug + "|" + g.txHash + "|" + t.address + "|" + action;
        e.chain = h.name; e.chainSlug = chainSlug; e.trader = label; e.traderAddress = wallet;
        e.action = action; e.confidence = approximateNative
                ? "HISTORICAL BACKFILL • wrapped-native swap leg • USD value approximated from current rate"
                : "HISTORICAL BACKFILL • paired stablecoin token transfers";
        e.tokenName = t.name; e.tokenSymbol = t.symbol; e.tokenAddress = t.address; e.txHash = g.txHash;
        e.timestamp = g.timestamp; e.tokenAmount = t.amount; e.estimatedSpendUsd = usd;
        e.spendLabel = ("BUY".equals(action) ? "Historical stablecoin cost ~$" : "Historical stablecoin proceeds ~$") + money(usd);
        e.explorerTxUrl = h.explorer + "/tx/" + g.txHash;
        e.explorerTraderUrl = h.explorer + "/address/" + wallet;
        e.explorerTokenUrl = h.explorer + "/token/" + t.address;
        e.riskNote = approximateNative
                ? "Historical qualification evidence only; wrapped-native USD conversion is approximate and is not a live alert."
                : "Historical qualification evidence only; not a live alert.";
        return e;
    }

    private static JSONObject getJson(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10_000); c.setReadTimeout(15_000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "SmartMarketWatchUltra/8.0");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("history HTTP " + code);
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close(); c.disconnect(); return new JSONObject(b.toString());
    }

    private static double tokenUsd(JSONObject token) {
        if (token == null) return 0;
        try {
            Object x = token.opt("exchange_rate");
            if (x == null || x == JSONObject.NULL) return 0;
            return Double.parseDouble(String.valueOf(x));
        } catch (Exception e) { return 0; }
    }

    private static double transferAmount(JSONObject x, int tokenDecimals) {
        try {
            Object total = x.opt("total");
            String raw = ""; int decimals = tokenDecimals;
            if (total instanceof JSONObject) {
                JSONObject t = (JSONObject) total;
                raw = t.optString("value", "");
                decimals = parseInt(t.optString("decimals", String.valueOf(tokenDecimals)), tokenDecimals);
            } else if (total != null && total != JSONObject.NULL) raw = String.valueOf(total);
            if (raw.isEmpty()) raw = x.optString("value", x.optString("amount", ""));
            if (raw.isEmpty()) return 0;
            java.math.BigDecimal v = new java.math.BigDecimal(raw);
            return v.movePointLeft(Math.max(0, decimals)).doubleValue();
        } catch (Exception e) { return 0; }
    }

    private static String addressOf(Object o) {
        if (o instanceof JSONObject) {
            JSONObject x = (JSONObject)o;
            return x.optString("hash", x.optString("address_hash", x.optString("address", "")));
        }
        return o == null || o == JSONObject.NULL ? "" : String.valueOf(o);
    }

    private static boolean isStable(String symbol) {
        String s = symbol == null ? "" : symbol.toUpperCase(Locale.US);
        return "USDC".equals(s) || "USDC.E".equals(s) || "USDBC".equals(s) || "USDT".equals(s)
                || "USDT0".equals(s) || "DAI".equals(s) || "USDS".equals(s) || "FDUSD".equals(s)
                || "USDE".equals(s) || "PYUSD".equals(s) || "TUSD".equals(s);
    }

    private static boolean isWrappedBase(String symbol) {
        String s = symbol == null ? "" : symbol.toUpperCase(Locale.US);
        return "WETH".equals(s) || "ETH".equals(s) || "WBNB".equals(s) || "BNB".equals(s)
                || "WPOL".equals(s) || "POL".equals(s) || "WAVAX".equals(s) || "AVAX".equals(s)
                || "WMNT".equals(s) || "MNT".equals(s) || "WS".equals(s);
    }

    private static ChainHistory chainHistory(String chain) {
        // Public instance URLs are used when available; failures are non-fatal and simply keep the wallet in REVIEW.
        if ("ethereum".equals(chain)) return new ChainHistory("Ethereum", "https://eth.blockscout.com", "https://eth.blockscout.com");
        if ("base".equals(chain)) return new ChainHistory("Base", "https://base.blockscout.com", "https://base.blockscout.com");
        if ("arbitrum".equals(chain)) return new ChainHistory("Arbitrum", "https://arbitrum.blockscout.com", "https://arbitrum.blockscout.com");
        if ("optimism".equals(chain)) return new ChainHistory("Optimism", "https://optimism.blockscout.com", "https://optimism.blockscout.com");
        if ("bsc".equals(chain)) return new ChainHistory("BNB Chain", "https://bsc.blockscout.com", "https://bsc.blockscout.com");
        if ("polygon".equals(chain)) return new ChainHistory("Polygon", "https://polygon.blockscout.com", "https://polygon.blockscout.com");
        if ("avalanche".equals(chain)) return new ChainHistory("Avalanche", "https://avalanche.blockscout.com", "https://avalanche.blockscout.com");
        if ("linea".equals(chain)) return new ChainHistory("Linea", "https://linea.blockscout.com", "https://linea.blockscout.com");
        if ("scroll".equals(chain)) return new ChainHistory("Scroll", "https://scroll.blockscout.com", "https://scroll.blockscout.com");
        if ("zksync".equals(chain)) return new ChainHistory("zkSync", "https://zksync.blockscout.com", "https://zksync.blockscout.com");
        if ("mantle".equals(chain)) return new ChainHistory("Mantle", "https://mantle.blockscout.com", "https://mantle.blockscout.com");
        if ("sonic".equals(chain)) return new ChainHistory("Sonic", "https://sonic.blockscout.com", "https://sonic.blockscout.com");
        if ("unichain".equals(chain)) return new ChainHistory("Unichain", "https://unichain.blockscout.com", "https://unichain.blockscout.com");
        if ("berachain".equals(chain)) return new ChainHistory("Berachain", "https://berachain.blockscout.com", "https://berachain.blockscout.com");
        if ("blast".equals(chain)) return new ChainHistory("Blast", "https://blast.blockscout.com", "https://blast.blockscout.com");
        if ("robinhood".equals(chain)) return new ChainHistory("Robinhood Chain", "https://robinhoodchain.blockscout.com", "https://robinhoodchain.blockscout.com");
        return null;
    }

    private static long parseTime(String s) { try { return Instant.parse(s).toEpochMilli(); } catch (Exception e) { return 0L; } }
    private static int parseInt(String s, int d) { try { return Integer.parseInt(s); } catch (Exception e) { return d; } }
    private static boolean isEvmAddress(String s) { return s != null && s.matches("(?i)^0x[0-9a-f]{40}$"); }
    private static String norm(String s) { return s == null ? "" : s.trim().toLowerCase(Locale.US); }
    private static String money(double x) { if (x >= 1_000_000) return String.format(Locale.US,"%.2fM",x/1_000_000.0); if (x >= 1000) return String.format(Locale.US,"%.2fK",x/1000.0); return String.format(Locale.US,"%.0f",x); }
    private static String clean(String s) { if (s == null || s.isEmpty()) return "unknown error"; return s.length() > 100 ? s.substring(0,100) + "…" : s; }

    private static final class Transfer { String address="",symbol="",name=""; double amount=0; }
    private static final class TxGroup { String txHash=""; long timestamp=0; double stableIn=0,stableOut=0,baseInUsd=0,baseOutUsd=0; List<Transfer> ins=new ArrayList<>(),outs=new ArrayList<>(); }
    private static final class ChainHistory {
        final String name, blockscoutBase, explorer;
        ChainHistory(String name, String blockscoutBase, String explorer) { this.name=name; this.blockscoutBase=blockscoutBase; this.explorer=explorer; }
    }
}
