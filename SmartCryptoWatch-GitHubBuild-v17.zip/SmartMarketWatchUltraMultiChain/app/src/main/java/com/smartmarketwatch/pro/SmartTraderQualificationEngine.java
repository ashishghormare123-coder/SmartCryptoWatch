package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Smart Trader Qualification Engine.
 *
 * The radar can inspect candidate wallets, but Early Token Watch only publishes/alerts
 * wallets that pass this engine when strict mode is enabled. Qualification combines a
 * dated external performance snapshot with locally observed behavior. The local layer
 * is deliberately conservative: rapid exits are penalized and an unknown wallet needs
 * a meaningful closed-position sample before it can graduate.
 *
 * This class never signs transactions and never needs a private key.
 */
public final class SmartTraderQualificationEngine {
    private static final String PREF = "scw";
    private static final String KEY_PROFILES = "smart_trader_profiles_v1";
    private static final String KEY_POSITIONS = "smart_trader_positions_v1";
    private static final int MAX_PROFILES = 500;
    private static final int MAX_POSITIONS = 1200;

    private SmartTraderQualificationEngine() {}

    public static final class Profile {
        public String chainSlug = "";
        public String name = "";
        public String address = "";
        public String sourceLabel = "";
        public String sourceUrl = "";
        public String sourceNote = "";
        public long sourceAsOf = 0L;

        // Dated external snapshot. These are evidence inputs, not guarantees.
        public double pnlUsd30d = Double.NaN;
        public double roiPct30d = Double.NaN;
        public double winRatePct30d = Double.NaN;
        public int trades30d = 0;
        public double avgHoldHours30d = Double.NaN;
        public double earlyEntryPct30d = Double.NaN;

        // Locally observed behavior from this app.
        public int observedBuys = 0;
        public int observedSells = 0;
        public int observedClosed = 0;
        public int observedWins = 0;
        public int observedFastExits = 0;
        public int observedMoonshots = 0;
        public double observedRealizedPnlUsd = 0;
        public double observedHoldHoursTotal = 0;
        public long lastSeenAt = 0L;

        public int score = 0;
        public String status = "REVIEW";
        public String reason = "Not evaluated";

        public double observedWinRate() {
            return observedClosed <= 0 ? Double.NaN : (100.0 * observedWins / observedClosed);
        }
        public double observedAvgHoldHours() {
            return observedClosed <= 0 ? Double.NaN : observedHoldHoursTotal / observedClosed;
        }
        public double observedFastExitPct() {
            return observedClosed <= 0 ? Double.NaN : (100.0 * observedFastExits / observedClosed);
        }
    }

    public static final class TrackedPosition {
        public String chainSlug = "";
        public String wallet = "";
        public String traderName = "";
        public String token = "";
        public String symbol = "";
        public long firstBuyAt = 0L;
        public long lastBuyAt = 0L;
        public long lastSellAt = 0L;
        public double boughtAmount = 0;
        public double soldAmount = 0;
        public double costUsd = 0;
        public double proceedsUsd = 0;
        public double realizedPnlUsd = 0;
        public double entryPriceUsd = 0;
        public double entryMarketCap = 0;
        public double peakMarketCap = 0;
        public boolean closed = false;
        public boolean moonshotCredited = false;
        public long lastPeakCheckAt = 0L;

        public String key() {
            return SmartTraderQualificationEngine.key(chainSlug, wallet, token);
        }
        public double remainingAmount() {
            return Math.max(0, boughtAmount - soldAmount);
        }
    }

    /** Merge the current research seed into the local store without erasing learned history. */
    public static synchronized void ensureSeedProfiles(Context context) {
        Map<String, Profile> profiles = loadProfiles(context);

        // Current swing-oriented Solana candidates. The first four pass the default gates;
        // the others stay as research examples of why PnL alone is not enough.
        mergeSeed(profiles, seed("solana", "7Sr5 Swing", "7Sr5FKdYmHQq2kcXisHMMBU6jbnaKqFwiC7dAtFU7Ux4",
                "uwuu.ai", "https://uwuu.ai/trader/7Sr5FKdYmHQq2kcXisHMMBU6jbnaKqFwiC7dAtFU7Ux4", "2026-09-25T00:00:00Z",
                61633, 54.0, 50.6, 1926, 72, Double.NaN,
                "30d profitable swing profile; average hold about 3 days."));
        mergeSeed(profiles, seed("solana", "Bsvj Swing", "BsvjGudtAhqR5YyiZ129KwQK2tugm6u78XvgULAJpTic",
                "uwuu.ai", "https://uwuu.ai/trader/BsvjGudtAhqR5YyiZ129KwQK2tugm6u78XvgULAJpTic", "2026-09-25T00:00:00Z",
                25970, 31.3, 67.0, 1056, 72, Double.NaN,
                "30d profitable swing profile; average hold about 3 days."));
        mergeSeed(profiles, seed("solana", "4TS2 Swing", "4TS24wgLBMucbZt7zqhM3KakXwdNTT2ECxDXEpsn5AhZ",
                "uwuu.ai", "https://uwuu.ai/trader/4TS24wgLBMucbZt7zqhM3KakXwdNTT2ECxDXEpsn5AhZ", "2026-09-25T00:00:00Z",
                13645, 76.8, 80.0, 345, 48, Double.NaN,
                "30d profitable swing profile; average hold about 2 days."));
        mergeSeed(profiles, seed("solana", "kreo", "BCnqsPEtA1TkgednYEebRpkmwFRJDCjMQcKZMMtEdArc",
                "uwuu.ai", "https://uwuu.ai/trader/BCnqsPEtA1TkgednYEebRpkmwFRJDCjMQcKZMMtEdArc", "2026-09-24T00:00:00Z",
                5209, 56.6, 71.4, 63, 72, Double.NaN,
                "30d focused swing profile; average hold about 3 days."));

        // These are deliberately NOT expected to pass the default qualification gates.
        mergeSeed(profiles, seed("solana", "9s6e Candidate", "9s6e4f2eYni3hURKfDkqfbPRCJwiXCGsSrjfoUiB9VoS",
                "uwuu.ai", "https://uwuu.ai/trader/9s6e4f2eYni3hURKfDkqfbPRCJwiXCGsSrjfoUiB9VoS", "2026-09-26T00:00:00Z",
                61246, 54.8, 39.2, 1047, 48, Double.NaN,
                "Profitable swing profile, but 30d win rate is below the default accuracy gate."));
        mergeSeed(profiles, seed("solana", "Mitch Candidate", "4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t",
                "uwuu.ai", "https://uwuu.ai/trader/4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t", "2026-09-19T00:00:00Z",
                -7131, -7.8, 57.9, 87, 1872, Double.NaN,
                "Long holding behavior, but the cited 30d snapshot was negative."));
        mergeSeed(profiles, seed("solana", "Kadenox Candidate", "B32QbbdDAyhvUQzjcaM5j6ZVKwjCxAwGH5Xgvb9SJqnC",
                "KOL Explorer", "https://kolexplorer.com/kol/kadenox", "2026-09-27T00:00:00Z",
                100900, Double.NaN, 55.5, 0, 0.25, Double.NaN,
                "Strong realized PnL, but median holding behavior is seconds/minutes, so it fails the hold gate."));
        mergeSeed(profiles, seed("solana", "decu Candidate", "4vw54BmAogeRV3vPKWyFet5yf8DTLcREzdSzx4rw9Ud9",
                "uwuu.ai", "https://uwuu.ai/trader/4vw54BmAogeRV3vPKWyFet5yf8DTLcREzdSzx4rw9Ud9", "2026-09-14T00:00:00Z",
                166949, 179.1, 98.0, 3110, 1.0, Double.NaN,
                "Very strong 30d stats but average holding time is about one hour; excluded by the swing/hold rule."));

        trimProfiles(profiles);
        evaluateAll(context, profiles);
        saveProfiles(context, profiles);
    }

    /** Solana wallets that actually passed qualification and may enter Early Token Watch. */
    public static synchronized List<Profile> qualifiedSolanaProfiles(Context context) {
        ensureSeedProfiles(context);
        SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Map<String, Profile> map = loadProfiles(context);
        evaluateAll(context, map);
        List<Profile> out = new ArrayList<>();
        for (Profile p : map.values()) {
            if ("solana".equals(p.chainSlug) && isQualified(p, prefs)) out.add(p);
        }
        out.sort(Comparator.comparingInt((Profile x) -> x.score).reversed());
        return out;
    }

    /** Register an automatically discovered wallet. Discovery evidence is observational only; no instant trust is granted. */
    public static synchronized Profile ensureDiscoveryCandidate(Context context, String chainSlug, String name, String address, String sourceUrl) {
        ensureSeedProfiles(context);
        Map<String, Profile> map = loadProfiles(context);
        String k = profileKey(chainSlug, address);
        Profile p = map.get(k);
        if (p == null) {
            p = new Profile();
            p.chainSlug = norm(chainSlug);
            p.name = blank(name) ? shortAddress(address) : name;
            p.address = address;
            p.sourceLabel = "GeckoTerminal discovery";
            p.sourceUrl = sourceUrl == null ? "" : sourceUrl;
            p.sourceAsOf = System.currentTimeMillis();
            p.sourceNote = "Automatically discovered from on-chain pool trades. Qualification requires a locally observed profitable closed-position record; discovery alone never qualifies a wallet.";
            map.put(k, p);
        } else {
            if (!blank(name) && (blank(p.name) || p.name.startsWith("Auto "))) p.name = name;
            if ((blank(p.sourceLabel) || "Local observation".equals(p.sourceLabel)) && !blank(sourceUrl)) {
                p.sourceLabel = "GeckoTerminal discovery";
                p.sourceUrl = sourceUrl;
                p.sourceAsOf = System.currentTimeMillis();
            }
        }
        evaluate(context, p);
        trimProfiles(map);
        saveProfiles(context, map);
        return p;
    }

    /** Register a manually supplied EVM wallet as a candidate. It must earn qualification. */
    public static synchronized Profile ensureManualCandidate(Context context, String chainSlug, String name, String address) {
        ensureSeedProfiles(context);
        Map<String, Profile> map = loadProfiles(context);
        String k = profileKey(chainSlug, address);
        Profile p = map.get(k);
        if (p == null) {
            p = new Profile();
            p.chainSlug = norm(chainSlug);
            p.name = blank(name) ? shortAddress(address) : name;
            p.address = address;
            p.sourceLabel = "Local observation";
            p.sourceNote = "Manual candidate; qualification is based on locally observed closed positions.";
            map.put(k, p);
        } else if (!blank(name)) p.name = name;
        evaluate(context, p);
        saveProfiles(context, map);
        return p;
    }

    public static synchronized Profile getProfile(Context context, String chainSlug, String address) {
        ensureSeedProfiles(context);
        Map<String, Profile> map = loadProfiles(context);
        Profile p = map.get(profileKey(chainSlug, address));
        if (p != null) evaluate(context, p);
        return p;
    }

    /**
     * Records an on-chain buy/sell, decorates the event, and returns whether the trader passes
     * the current qualification gate. This is called before EarlyTokenStore publishes an event.
     */
    public static synchronized boolean processEvent(Context context, EarlyTokenStore.Event event) {
        if (event == null || blank(event.traderAddress) || blank(event.chainSlug)) return false;
        Map<String, Profile> profiles = loadProfiles(context);
        String pk = profileKey(event.chainSlug, event.traderAddress);
        Profile p = profiles.get(pk);
        if (p == null) {
            p = new Profile();
            p.chainSlug = norm(event.chainSlug);
            p.address = event.traderAddress;
            p.name = blank(event.trader) ? shortAddress(event.traderAddress) : event.trader;
            boolean discovered = event.confidence != null && event.confidence.startsWith("DISCOVERY");
            p.sourceLabel = discovered ? "GeckoTerminal discovery" : "Local observation";
            p.sourceUrl = discovered ? event.dexUrl : "";
            p.sourceAsOf = discovered ? System.currentTimeMillis() : 0L;
            p.sourceNote = discovered
                    ? "Automatically discovered from on-chain pool trades. Discovery alone never qualifies a wallet; a profitable closed-position record is required."
                    : "Unverified candidate; needs a sufficient local track record before qualification.";
            profiles.put(pk, p);
        }

        Map<String, TrackedPosition> positions = loadPositions(context);
        recordEvent(p, positions, event);
        p.lastSeenAt = Math.max(p.lastSeenAt, event.timestamp > 0 ? event.timestamp : System.currentTimeMillis());
        evaluate(context, p);
        decorate(event, p);
        trimPositions(positions);
        trimProfiles(profiles);
        savePositions(context, positions);
        saveProfiles(context, profiles);

        SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        boolean strict = prefs.getBoolean("smart_only_qualified", true);
        return !strict || isQualified(p, prefs);
    }

    public static synchronized boolean hasOpenPosition(Context context, String chainSlug, String wallet, String token) {
        Map<String, TrackedPosition> positions = loadPositions(context);
        TrackedPosition p = positions.get(key(chainSlug, wallet, token));
        return p != null && !p.closed && p.remainingAmount() > Math.max(1e-12, p.boughtAmount * 0.02);
    }

    public static synchronized List<TrackedPosition> positionsForRefresh(Context context, int limit) {
        Map<String, TrackedPosition> map = loadPositions(context);
        List<TrackedPosition> all = new ArrayList<>();
        for (TrackedPosition p : map.values()) if (!p.closed && p.boughtAmount > 0) all.add(p);
        all.sort(Comparator.comparingLong(x -> x.lastPeakCheckAt));
        if (all.size() > limit) return new ArrayList<>(all.subList(0, Math.max(0, limit)));
        return all;
    }

    public static synchronized void updatePeak(Context context, TrackedPosition incoming, double marketCap) {
        if (incoming == null || marketCap <= 0) return;
        Map<String, TrackedPosition> positions = loadPositions(context);
        TrackedPosition p = positions.get(incoming.key());
        if (p == null) return;
        p.peakMarketCap = Math.max(p.peakMarketCap, marketCap);
        p.lastPeakCheckAt = System.currentTimeMillis();

        Map<String, Profile> profiles = loadProfiles(context);
        Profile trader = profiles.get(profileKey(p.chainSlug, p.wallet));
        if (trader != null && !p.moonshotCredited && p.entryMarketCap > 0 && p.entryMarketCap <= 500_000
                && p.peakMarketCap >= 5_000_000 && p.peakMarketCap / p.entryMarketCap >= 10.0) {
            p.moonshotCredited = true;
            trader.observedMoonshots++;
            evaluate(context, trader);
            saveProfiles(context, profiles);
        }
        positions.put(p.key(), p);
        savePositions(context, positions);
    }

    public static synchronized String statusLine(Context context) {
        ensureSeedProfiles(context);
        Map<String, Profile> map = loadProfiles(context);
        SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        int qualified = 0, review = 0;
        for (Profile p : map.values()) {
            evaluate(context, p);
            if (isQualified(p, prefs)) qualified++; else review++;
        }
        return "Qualification engine: " + qualified + " qualified • " + review + " review/excluded";
    }

    private static void recordEvent(Profile trader, Map<String, TrackedPosition> positions, EarlyTokenStore.Event e) {
        String k = key(e.chainSlug, e.traderAddress, e.tokenAddress);
        TrackedPosition pos = positions.get(k);
        double cap = e.marketCap > 0 ? e.marketCap : e.fdv;
        long ts = e.timestamp > 0 ? e.timestamp : System.currentTimeMillis();

        if ("BUY".equalsIgnoreCase(e.action)) {
            trader.observedBuys++;
            if (pos == null || pos.closed) {
                pos = new TrackedPosition();
                pos.chainSlug = norm(e.chainSlug);
                pos.wallet = e.traderAddress;
                pos.traderName = e.trader;
                pos.token = e.tokenAddress;
                pos.symbol = e.tokenSymbol;
                pos.firstBuyAt = ts;
                pos.entryPriceUsd = e.detectionPriceUsd;
                pos.entryMarketCap = cap;
                pos.peakMarketCap = cap;
            }
            pos.lastBuyAt = ts;
            pos.boughtAmount += Math.max(0, e.tokenAmount);
            pos.costUsd += Math.max(0, e.estimatedSpendUsd);
            if (pos.entryMarketCap <= 0 && cap > 0) pos.entryMarketCap = cap;
            pos.peakMarketCap = Math.max(pos.peakMarketCap, cap);
            positions.put(k, pos);
            return;
        }

        if (!"SELL".equalsIgnoreCase(e.action)) return;
        trader.observedSells++;
        if (pos == null || pos.closed || pos.boughtAmount <= 0) return;

        double sellAmount = Math.min(Math.max(0, e.tokenAmount), Math.max(0, pos.remainingAmount()));
        if (sellAmount <= 0) return;
        double costShare = pos.costUsd > 0 ? pos.costUsd * (sellAmount / Math.max(pos.boughtAmount, 1e-12)) : 0;
        double proceeds = Math.max(0, e.estimatedSpendUsd);
        pos.soldAmount += sellAmount;
        pos.proceedsUsd += proceeds;
        pos.realizedPnlUsd += proceeds - costShare;
        pos.lastSellAt = ts;
        pos.peakMarketCap = Math.max(pos.peakMarketCap, cap);
        e.positionRemaining = pos.remainingAmount();
        if (costShare > 0) e.realizedRoiPct = 100.0 * (proceeds - costShare) / costShare;

        boolean close = pos.remainingAmount() <= Math.max(1e-12, pos.boughtAmount * 0.05)
                || (e.walletTokenBalance >= 0 && e.walletTokenBalance <= Math.max(1e-12, pos.boughtAmount * 0.05));
        if (close) {
            pos.closed = true;
            trader.observedClosed++;
            trader.observedRealizedPnlUsd += pos.realizedPnlUsd;
            if (pos.realizedPnlUsd > 0) trader.observedWins++;
            double holdHours = Math.max(0, ts - pos.firstBuyAt) / 3_600_000.0;
            trader.observedHoldHoursTotal += holdHours;
            if (holdHours < 6.0) trader.observedFastExits++;
            if (!pos.moonshotCredited && pos.entryMarketCap > 0 && pos.entryMarketCap <= 500_000
                    && pos.peakMarketCap >= 5_000_000 && pos.peakMarketCap / pos.entryMarketCap >= 10.0) {
                pos.moonshotCredited = true;
                trader.observedMoonshots++;
            }
        }
        positions.put(k, pos);
    }

    private static void decorate(EarlyTokenStore.Event e, Profile p) {
        e.traderScore = p.score;
        e.traderStatus = p.status;
        e.traderReason = p.reason;
        e.traderSource = p.sourceLabel;
        e.traderSourceUrl = p.sourceUrl;
        e.traderSourceAsOf = p.sourceAsOf;
        e.traderWinRate30d = p.winRatePct30d;
        e.traderPnlUsd30d = p.pnlUsd30d;
        e.traderAvgHoldHours30d = p.avgHoldHours30d;
        e.traderObservedClosed = p.observedClosed;
        e.traderObservedMoonshots = p.observedMoonshots;
    }

    private static void evaluateAll(Context context, Map<String, Profile> profiles) {
        for (Profile p : profiles.values()) evaluate(context, p);
    }

    private static void evaluate(Context context, Profile p) {
        SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        double minWin = prefDouble(prefs, "smart_min_winrate", 45);
        double minHoldHours = prefDouble(prefs, "smart_min_hold_hours", 24);
        double maxFastExit = prefDouble(prefs, "smart_max_fast_exit_pct", 35);
        int minScore = (int) Math.round(prefDouble(prefs, "smart_min_score", 70));

        int score = 0;
        boolean hasExternal = !Double.isNaN(p.pnlUsd30d) || !Double.isNaN(p.winRatePct30d);
        if (hasExternal) {
            if (!Double.isNaN(p.pnlUsd30d) && p.pnlUsd30d > 0) {
                score += 10;
                if (p.pnlUsd30d >= 10_000) score += 5;
                if (p.pnlUsd30d >= 50_000) score += 5;
            }
            if (!Double.isNaN(p.roiPct30d)) {
                if (p.roiPct30d >= 5) score += 5;
                if (p.roiPct30d >= 25) score += 5;
                if (p.roiPct30d >= 50) score += 5;
            }
            if (!Double.isNaN(p.winRatePct30d)) {
                if (p.winRatePct30d >= 45) score += 10;
                if (p.winRatePct30d >= 60) score += 5;
                if (p.winRatePct30d >= 70) score += 5;
            }
            if (p.trades30d >= 30) score += 5;
            if (p.trades30d >= 200) score += 5;
            if (p.trades30d >= 1000) score += 5;
            if (!Double.isNaN(p.avgHoldHours30d)) {
                if (p.avgHoldHours30d >= 24) score += 10;
                if (p.avgHoldHours30d >= 48) score += 5;
                if (p.avgHoldHours30d >= 72) score += 5;
            }
        }

        if (p.observedClosed >= 5) {
            double wr = p.observedWinRate();
            if (wr >= 50) score += 5;
            if (wr >= 65) score += 5;
            if (p.observedRealizedPnlUsd > 0) score += 5;
            double hold = p.observedAvgHoldHours();
            if (!Double.isNaN(hold) && hold >= minHoldHours) score += 5;
        }
        score += Math.min(10, p.observedMoonshots * 2);

        double fast = p.observedFastExitPct();
        if (p.observedClosed >= 10 && !Double.isNaN(fast)) {
            if (fast > maxFastExit) score -= 25;
            else if (fast <= 15) score += 5;
        }
        score = Math.max(0, Math.min(100, score));
        p.score = score;

        boolean externalGate = hasExternal
                && !Double.isNaN(p.pnlUsd30d) && p.pnlUsd30d > 0
                && (Double.isNaN(p.roiPct30d) || p.roiPct30d >= 5)
                && !Double.isNaN(p.winRatePct30d) && p.winRatePct30d >= minWin
                && p.trades30d >= 30
                && !Double.isNaN(p.avgHoldHours30d) && p.avgHoldHours30d >= minHoldHours;

        boolean localGate = p.observedClosed >= 12
                && p.observedRealizedPnlUsd > 0
                && !Double.isNaN(p.observedWinRate()) && p.observedWinRate() >= Math.max(50, minWin)
                && !Double.isNaN(p.observedAvgHoldHours()) && p.observedAvgHoldHours() >= minHoldHours
                && (Double.isNaN(fast) || fast <= maxFastExit);

        boolean rapidDumpFail = p.observedClosed >= 10 && !Double.isNaN(fast) && fast > maxFastExit;
        boolean qualified = score >= minScore && (externalGate || localGate) && !rapidDumpFail;
        p.status = qualified ? "QUALIFIED" : (score >= Math.max(45, minScore - 20) ? "REVIEW" : "EXCLUDED");

        List<String> why = new ArrayList<>();
        if (qualified) {
            why.add("score " + score + "/100");
            if (externalGate) why.add("positive 30d record");
            if (!Double.isNaN(p.avgHoldHours30d)) why.add("avg hold " + holdText(p.avgHoldHours30d));
            if (p.observedMoonshots > 0) why.add(p.observedMoonshots + " observed 10x low-cap runner" + (p.observedMoonshots == 1 ? "" : "s"));
        } else {
            if (hasExternal && !Double.isNaN(p.pnlUsd30d) && p.pnlUsd30d <= 0) why.add("30d PnL not positive");
            if (hasExternal && !Double.isNaN(p.winRatePct30d) && p.winRatePct30d < minWin) why.add("win rate below " + fmt0(minWin) + "%");
            if (hasExternal && !Double.isNaN(p.avgHoldHours30d) && p.avgHoldHours30d < minHoldHours) why.add("holding time below " + holdText(minHoldHours));
            if (p.trades30d > 0 && p.trades30d < 30) why.add("sample too small");
            if (rapidDumpFail) why.add("too many <6h exits locally");
            if (!hasExternal && p.observedClosed < 12) why.add("needs 12 locally observed closed positions");
            why.add("score " + score + "/100");
        }
        p.reason = join(why, " • ");
    }

    private static boolean isQualified(Profile p, SharedPreferences prefs) {
        int minScore = (int) Math.round(prefDouble(prefs, "smart_min_score", 70));
        return p != null && "QUALIFIED".equals(p.status) && p.score >= minScore;
    }

    private static Profile seed(String chain, String name, String address, String source, String url, String asOf,
                                double pnl, double roi, double win, int trades, double holdHours, double earlyEntry,
                                String note) {
        Profile p = new Profile();
        p.chainSlug = chain; p.name = name; p.address = address; p.sourceLabel = source; p.sourceUrl = url;
        p.sourceAsOf = parseInstant(asOf); p.pnlUsd30d = pnl; p.roiPct30d = roi; p.winRatePct30d = win;
        p.trades30d = trades; p.avgHoldHours30d = holdHours; p.earlyEntryPct30d = earlyEntry; p.sourceNote = note;
        return p;
    }

    private static void mergeSeed(Map<String, Profile> map, Profile seed) {
        String k = profileKey(seed.chainSlug, seed.address);
        Profile old = map.get(k);
        if (old == null) { map.put(k, seed); return; }
        if (seed.sourceAsOf >= old.sourceAsOf) {
            old.chainSlug = seed.chainSlug; old.name = seed.name; old.address = seed.address;
            old.sourceLabel = seed.sourceLabel; old.sourceUrl = seed.sourceUrl; old.sourceNote = seed.sourceNote;
            old.sourceAsOf = seed.sourceAsOf; old.pnlUsd30d = seed.pnlUsd30d; old.roiPct30d = seed.roiPct30d;
            old.winRatePct30d = seed.winRatePct30d; old.trades30d = seed.trades30d;
            old.avgHoldHours30d = seed.avgHoldHours30d; old.earlyEntryPct30d = seed.earlyEntryPct30d;
        }
    }

    private static Map<String, Profile> loadProfiles(Context c) {
        Map<String, Profile> out = new LinkedHashMap<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_PROFILES, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                Profile p = profileFromJson(o); if (!blank(p.address)) out.put(profileKey(p.chainSlug, p.address), p);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void saveProfiles(Context c, Map<String, Profile> profiles) {
        JSONArray a = new JSONArray();
        for (Profile p : profiles.values()) a.put(profileToJson(p));
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_PROFILES, a.toString()).apply();
    }

    private static Map<String, TrackedPosition> loadPositions(Context c) {
        Map<String, TrackedPosition> out = new LinkedHashMap<>();
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_POSITIONS, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                TrackedPosition p = positionFromJson(o); if (!blank(p.token) && !blank(p.wallet)) out.put(p.key(), p);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void savePositions(Context c, Map<String, TrackedPosition> positions) {
        JSONArray a = new JSONArray();
        for (TrackedPosition p : positions.values()) a.put(positionToJson(p));
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_POSITIONS, a.toString()).apply();
    }

    private static JSONObject profileToJson(Profile p) {
        JSONObject o = new JSONObject();
        try {
            o.put("chainSlug", p.chainSlug); o.put("name", p.name); o.put("address", p.address);
            o.put("sourceLabel", p.sourceLabel); o.put("sourceUrl", p.sourceUrl); o.put("sourceNote", p.sourceNote); o.put("sourceAsOf", p.sourceAsOf);
            putDouble(o, "pnlUsd30d", p.pnlUsd30d); putDouble(o, "roiPct30d", p.roiPct30d); putDouble(o, "winRatePct30d", p.winRatePct30d);
            o.put("trades30d", p.trades30d); putDouble(o, "avgHoldHours30d", p.avgHoldHours30d); putDouble(o, "earlyEntryPct30d", p.earlyEntryPct30d);
            o.put("observedBuys", p.observedBuys); o.put("observedSells", p.observedSells); o.put("observedClosed", p.observedClosed); o.put("observedWins", p.observedWins);
            o.put("observedFastExits", p.observedFastExits); o.put("observedMoonshots", p.observedMoonshots); o.put("observedRealizedPnlUsd", p.observedRealizedPnlUsd);
            o.put("observedHoldHoursTotal", p.observedHoldHoursTotal); o.put("lastSeenAt", p.lastSeenAt); o.put("score", p.score); o.put("status", p.status); o.put("reason", p.reason);
        } catch (Exception ignored) {}
        return o;
    }

    private static Profile profileFromJson(JSONObject o) {
        Profile p = new Profile();
        p.chainSlug=o.optString("chainSlug","");p.name=o.optString("name","");p.address=o.optString("address","");
        p.sourceLabel=o.optString("sourceLabel","");p.sourceUrl=o.optString("sourceUrl","");p.sourceNote=o.optString("sourceNote","");p.sourceAsOf=o.optLong("sourceAsOf",0);
        p.pnlUsd30d=optDouble(o,"pnlUsd30d");p.roiPct30d=optDouble(o,"roiPct30d");p.winRatePct30d=optDouble(o,"winRatePct30d");p.trades30d=o.optInt("trades30d",0);
        p.avgHoldHours30d=optDouble(o,"avgHoldHours30d");p.earlyEntryPct30d=optDouble(o,"earlyEntryPct30d");
        p.observedBuys=o.optInt("observedBuys",0);p.observedSells=o.optInt("observedSells",0);p.observedClosed=o.optInt("observedClosed",0);p.observedWins=o.optInt("observedWins",0);
        p.observedFastExits=o.optInt("observedFastExits",0);p.observedMoonshots=o.optInt("observedMoonshots",0);p.observedRealizedPnlUsd=o.optDouble("observedRealizedPnlUsd",0);
        p.observedHoldHoursTotal=o.optDouble("observedHoldHoursTotal",0);p.lastSeenAt=o.optLong("lastSeenAt",0);p.score=o.optInt("score",0);p.status=o.optString("status","REVIEW");p.reason=o.optString("reason","");
        return p;
    }

    private static JSONObject positionToJson(TrackedPosition p) {
        JSONObject o = new JSONObject();
        try {
            o.put("chainSlug",p.chainSlug);o.put("wallet",p.wallet);o.put("traderName",p.traderName);o.put("token",p.token);o.put("symbol",p.symbol);
            o.put("firstBuyAt",p.firstBuyAt);o.put("lastBuyAt",p.lastBuyAt);o.put("lastSellAt",p.lastSellAt);o.put("boughtAmount",p.boughtAmount);o.put("soldAmount",p.soldAmount);
            o.put("costUsd",p.costUsd);o.put("proceedsUsd",p.proceedsUsd);o.put("realizedPnlUsd",p.realizedPnlUsd);o.put("entryPriceUsd",p.entryPriceUsd);
            o.put("entryMarketCap",p.entryMarketCap);o.put("peakMarketCap",p.peakMarketCap);o.put("closed",p.closed);o.put("moonshotCredited",p.moonshotCredited);o.put("lastPeakCheckAt",p.lastPeakCheckAt);
        } catch(Exception ignored) {}
        return o;
    }

    private static TrackedPosition positionFromJson(JSONObject o) {
        TrackedPosition p=new TrackedPosition();
        p.chainSlug=o.optString("chainSlug","");p.wallet=o.optString("wallet","");p.traderName=o.optString("traderName","");p.token=o.optString("token","");p.symbol=o.optString("symbol","");
        p.firstBuyAt=o.optLong("firstBuyAt",0);p.lastBuyAt=o.optLong("lastBuyAt",0);p.lastSellAt=o.optLong("lastSellAt",0);p.boughtAmount=o.optDouble("boughtAmount",0);p.soldAmount=o.optDouble("soldAmount",0);
        p.costUsd=o.optDouble("costUsd",0);p.proceedsUsd=o.optDouble("proceedsUsd",0);p.realizedPnlUsd=o.optDouble("realizedPnlUsd",0);p.entryPriceUsd=o.optDouble("entryPriceUsd",0);
        p.entryMarketCap=o.optDouble("entryMarketCap",0);p.peakMarketCap=o.optDouble("peakMarketCap",0);p.closed=o.optBoolean("closed",false);p.moonshotCredited=o.optBoolean("moonshotCredited",false);p.lastPeakCheckAt=o.optLong("lastPeakCheckAt",0);
        return p;
    }

    private static void trimProfiles(Map<String, Profile> m) {
        if (m.size() <= MAX_PROFILES) return;
        List<Profile> all = new ArrayList<>(m.values());
        // Preserve externally researched profiles first, then stronger/active learned profiles.
        all.sort((a,b) -> {
            int ae = (!Double.isNaN(a.pnlUsd30d) || !Double.isNaN(a.winRatePct30d)) ? 1 : 0;
            int be = (!Double.isNaN(b.pnlUsd30d) || !Double.isNaN(b.winRatePct30d)) ? 1 : 0;
            if (ae != be) return Integer.compare(be, ae);
            if (a.score != b.score) return Integer.compare(b.score, a.score);
            if (a.observedClosed != b.observedClosed) return Integer.compare(b.observedClosed, a.observedClosed);
            return Long.compare(b.lastSeenAt, a.lastSeenAt);
        });
        m.clear();
        for (int i=0;i<Math.min(MAX_PROFILES,all.size());i++) { Profile p=all.get(i);m.put(profileKey(p.chainSlug,p.address),p); }
    }

    private static void trimPositions(Map<String, TrackedPosition> m) {
        if (m.size() <= MAX_POSITIONS) return;
        List<TrackedPosition> all = new ArrayList<>(m.values());
        all.sort(Comparator.comparingLong((TrackedPosition x) -> Math.max(x.lastSellAt,x.lastBuyAt)).reversed());
        m.clear();
        for(int i=0;i<Math.min(MAX_POSITIONS,all.size());i++){TrackedPosition p=all.get(i);m.put(p.key(),p);}
    }

    private static void putDouble(JSONObject o,String k,double v)throws Exception{if(Double.isNaN(v)||Double.isInfinite(v))o.put(k,JSONObject.NULL);else o.put(k,v);}
    private static double optDouble(JSONObject o,String k){return o.isNull(k)?Double.NaN:o.optDouble(k,Double.NaN);}
    private static String profileKey(String chain,String address){return norm(chain)+"|"+idNorm(address);}
    private static String key(String chain,String wallet,String token){return norm(chain)+"|"+idNorm(wallet)+"|"+idNorm(token);}
    private static String norm(String s){return s==null?"":s.trim().toLowerCase(Locale.US);}
    /** EVM addresses are case-insensitive; Solana/base58 identifiers are case-sensitive. */
    private static String idNorm(String s){
        if(s==null)return "";
        String x=s.trim();
        return x.startsWith("0x")||x.startsWith("0X")?x.toLowerCase(Locale.US):x;
    }
    private static boolean blank(String s){return s==null||s.trim().isEmpty();}
    private static String shortAddress(String s){if(s==null)return"";return s.length()<=12?s:s.substring(0,6)+"…"+s.substring(s.length()-4);}
    private static long parseInstant(String s){try{return Instant.parse(s).toEpochMilli();}catch(Exception e){return 0;}}
    private static double prefDouble(SharedPreferences p,String key,double d){try{return Double.parseDouble(p.getString(key,String.valueOf(d)));}catch(Exception e){return d;}}
    private static String fmt0(double x){return String.format(Locale.US,"%.0f",x);}
    private static String holdText(double hours){if(hours>=48)return String.format(Locale.US,"%.1f days",hours/24.0);return String.format(Locale.US,"%.0f h",hours);}
    private static String join(List<String> xs,String sep){StringBuilder b=new StringBuilder();for(String x:xs){if(blank(x))continue;if(b.length()>0)b.append(sep);b.append(x);}return b.toString();}
}
