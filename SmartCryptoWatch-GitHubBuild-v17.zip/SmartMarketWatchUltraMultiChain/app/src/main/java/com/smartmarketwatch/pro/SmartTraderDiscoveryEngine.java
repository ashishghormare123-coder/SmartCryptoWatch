package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * v8 rate-aware automatic smart-trader discovery with historical backfill.
 *
 * Uses GeckoTerminal's public on-chain API as a read-only discovery feed:
 * latest pools across networks -> recent pool trades -> tx_from_address candidates.
 * Candidates are NOT trusted immediately. Every unique observed trade is fed into the
 * SmartTraderQualificationEngine, which requires a profitable closed-position history,
 * acceptable win rate/holding behaviour and the configured score before the wallet can
 * publish an Early Token Watch event.
 *
 * The public GeckoTerminal API is intentionally used conservatively (one new-pools call
 * plus at most three pool-trade calls per pass) so the 5-minute radar stays well below
 * normal public rate limits.
 */
public final class SmartTraderDiscoveryEngine {
    private static final String PREF = "scw";
    private static final String GT = "https://api.geckoterminal.com/api/v2";
    private static final String KEY_SEEN = "discovery_seen_trades_v1";
    private static final String KEY_AUTO_EVM = "auto_evm_wallets_v1";
    private static final String KEY_NETWORK_REGISTRY = "gt_network_registry_v8";
    private static final String KEY_NETWORK_REGISTRY_AT = "gt_network_registry_at_v8";
    private static final int MAX_SEEN = 1800;
    private static final int MAX_POOLS_PER_NETWORK = 1;
    private static final int MAX_BACKFILLS_PER_PASS = 2;
    private static final int MAX_TRADES_PER_POOL = 80;
    // GeckoTerminal public API is ~10 calls/minute. v8 deliberately scans only
    // two core networks plus one rotating network per pass (max ~7 calls including
    // a one-page registry refresh), then advances the cursors for the next pass.
    private static final int CORE_NETWORKS_PER_PASS = 2;
    private static final long REGISTRY_PAGE_TTL_MS = 24L * 60L * 60L * 1000L;
    private static final double DISCOVERY_MIN_TRADE_USD = 250.0;
    private static final double DISCOVERY_MIN_LIQ_USD = 5_000.0;
    private static final DiscoveryNetwork[] CORE_NETWORKS = {
            new DiscoveryNetwork("solana", "solana", "Solana"),
            new DiscoveryNetwork("base", "base", "Base"),
            new DiscoveryNetwork("eth", "ethereum", "Ethereum"),
            new DiscoveryNetwork("bsc", "bsc", "BNB Chain"),
            new DiscoveryNetwork("arbitrum", "arbitrum", "Arbitrum")
    };
    private static final DiscoveryNetwork[] ROTATING_NETWORKS = {
            // Fallback IDs confirmed in GeckoTerminal's live registry. Networks not in this
            // static fallback (including brand-new chains) can still enter through the
            // dynamically refreshed network registry.
            new DiscoveryNetwork("optimism", "optimism", "Optimism"),
            new DiscoveryNetwork("polygon_pos", "polygon", "Polygon"),
            new DiscoveryNetwork("avax", "avalanche", "Avalanche"),
            new DiscoveryNetwork("linea", "linea", "Linea"),
            new DiscoveryNetwork("scroll", "scroll", "Scroll"),
            new DiscoveryNetwork("zksync", "zksync", "zkSync"),
            new DiscoveryNetwork("mantle", "mantle", "Mantle"),
            new DiscoveryNetwork("blast", "blast", "Blast"),
            new DiscoveryNetwork("mode", "mode", "Mode"),
            new DiscoveryNetwork("core", "core", "Core"),
            new DiscoveryNetwork("opbnb", "opbnb", "opBNB")
    };

    private SmartTraderDiscoveryEngine() {}

    public static final class Result {
        public int poolsScanned;
        public int tradesObserved;
        public int newCandidateTrades;
        public int qualifiedEvents;
        public int publishedEvents;
        public int networksSeen;
        public int networkErrors;
        public int historyWalletsBackfilled;
        public int historyEventsLearned;
        public int historyGraduated;
        public String error = "";

        public String line() {
            String s = "Auto discovery v8: " + networksSeen + " networks scanned • " + poolsScanned + " new pools • "
                    + newCandidateTrades + " fresh wallet trades • " + publishedEvents + " qualified events published";
            if (historyWalletsBackfilled > 0) s += " • history " + historyWalletsBackfilled + " wallets/" + historyEventsLearned + " trades";
            if (historyGraduated > 0) s += " • " + historyGraduated + " graduated from backfill";
            if (networkErrors > 0) s += " • " + networkErrors + " network feed unavailable" + (networkErrors == 1 ? "" : "s");
            if (!error.isEmpty()) s += " • " + error;
            return s;
        }
    }

    public static Result run(Context context, boolean notifyAllowed) {
        Result result = new Result();
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean("auto_discovery_enabled", true)) {
            result.error = "disabled";
            return result;
        }

        Set<String> seen = loadSeen(p);
        List<String> newlySeen = new ArrayList<>();
        int[] backfillBudget = new int[]{MAX_BACKFILLS_PER_PASS};
        try {
            // Rate-aware schedule: two core chains per pass, round-robin across the five
            // core networks. The 5-minute radar therefore covers every core chain within
            // roughly 15 minutes without triggering GeckoTerminal's public-rate throttling.
            int coreCursor = Math.max(0, p.getInt("discovery_core_cursor_v8", 0));
            for (int i = 0; i < Math.min(CORE_NETWORKS_PER_PASS, CORE_NETWORKS.length); i++) {
                DiscoveryNetwork d = CORE_NETWORKS[(coreCursor + i) % CORE_NETWORKS.length];
                scanNetwork(context, p, d, seen, newlySeen, notifyAllowed, result, backfillBudget);
            }
            p.edit().putInt("discovery_core_cursor_v8", (coreCursor + CORE_NETWORKS_PER_PASS) % CORE_NETWORKS.length).apply();

            // One additional live-registry network rotates each pass. Registry refresh is
            // only one page per pass, so it cannot consume the entire public API budget.
            int secondary = Math.max(0, p.getInt("discovery_secondary_cursor_v8", 0));
            List<DiscoveryNetwork> dynamic = loadNetworkRegistry(p);
            DiscoveryNetwork extra = null;
            if (!dynamic.isEmpty()) {
                for (int tries = 0; tries < dynamic.size(); tries++) {
                    DiscoveryNetwork d = dynamic.get((secondary + tries) % dynamic.size());
                    if (!isCoreGtId(d.gtId)) { extra = d; secondary = (secondary + tries + 1) % dynamic.size(); break; }
                }
            }
            if (extra == null && ROTATING_NETWORKS.length > 0) {
                extra = ROTATING_NETWORKS[secondary % ROTATING_NETWORKS.length];
                secondary = (secondary + 1) % ROTATING_NETWORKS.length;
            }
            if (extra != null) scanNetwork(context, p, extra, seen, newlySeen, notifyAllowed, result, backfillBudget);
            p.edit().putInt("discovery_secondary_cursor_v8", secondary).apply();

            saveSeen(p, seen, newlySeen);
            p.edit()
                    .putLong("discovery_last_scan", System.currentTimeMillis())
                    .putString("discovery_last_status", result.line())
                    .apply();
        } catch (Exception e) {
            result.error = clean(e.getMessage());
            p.edit().putString("discovery_last_status", "Auto discovery v8 error: " + result.error).apply();
        }
        return result;
    }

    private static List<DiscoveryNetwork> loadNetworkRegistry(SharedPreferences p) {
        String raw = p.getString(KEY_NETWORK_REGISTRY, "[]");
        long last = p.getLong(KEY_NETWORK_REGISTRY_AT, 0L);
        int page = Math.max(1, Math.min(3, p.getInt("gt_network_registry_page_v8", 1)));
        boolean stale = last <= 0 || System.currentTimeMillis() - last > REGISTRY_PAGE_TTL_MS;

        // Refresh just ONE registry page per pass. This keeps the discovery pass under the
        // public API budget while still learning new networks over successive radar cycles.
        if (stale || "[]".equals(raw)) {
            try {
                LinkedHashMap<String, DiscoveryNetwork> merged = new LinkedHashMap<>();
                try {
                    JSONArray existing = new JSONArray(raw);
                    for (int i = 0; i < existing.length(); i++) {
                        JSONObject o = existing.optJSONObject(i); if (o == null) continue;
                        String id=o.optString("id",""); if(id.isEmpty()) continue;
                        merged.put(id, new DiscoveryNetwork(id, o.optString("slug", chainSlug(id)), o.optString("name", id)));
                    }
                } catch (Exception ignored) {}

                JSONObject root = getJson(GT + "/networks?page=" + page);
                JSONArray data = root.optJSONArray("data");
                if (data != null) {
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject row = data.optJSONObject(i); if (row == null) continue;
                        String id = row.optString("id", "");
                        JSONObject a = row.optJSONObject("attributes");
                        String name = a == null ? id : a.optString("name", id);
                        if (id.isEmpty() || isCoreGtId(id)) continue;
                        String low = name.toLowerCase(Locale.US);
                        if (low.contains("testnet") || low.contains("devnet")) continue;
                        merged.put(id, new DiscoveryNetwork(id, chainSlug(id), name));
                    }
                }

                JSONArray saved = new JSONArray();
                for (DiscoveryNetwork d : merged.values()) {
                    saved.put(new JSONObject().put("id", d.gtId).put("slug", d.chainSlug).put("name", d.name));
                }
                if (saved.length() > 0) {
                    raw = saved.toString();
                    p.edit()
                            .putString(KEY_NETWORK_REGISTRY, raw)
                            .putLong(KEY_NETWORK_REGISTRY_AT, System.currentTimeMillis())
                            .putInt("gt_network_registry_page_v8", page >= 3 ? 1 : page + 1)
                            .apply();
                }
            } catch (Exception ignored) {}
        }

        List<DiscoveryNetwork> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                String id = o.optString("id", "");
                if (id.isEmpty()) continue;
                out.add(new DiscoveryNetwork(id, o.optString("slug", chainSlug(id)), o.optString("name", id)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static boolean isCoreGtId(String id) {
        if (id == null) return false;
        for (DiscoveryNetwork d : CORE_NETWORKS) if (d.gtId.equals(id)) return true;
        return false;
    }

    private static void scanNetwork(Context context, SharedPreferences prefs, DiscoveryNetwork d,
                                    Set<String> seen, List<String> newlySeen, boolean notifyAllowed,
                                    Result result, int[] backfillBudget) {
        try {
            String url = GT + "/networks/" + enc(d.gtId) + "/new_pools?include=base_token,network,dex&page=1";
            JSONObject payload = getJson(url);
            Map<String, JSONObject> included = indexIncluded(payload.optJSONArray("included"));
            List<Pool> pools = parsePools(payload.optJSONArray("data"), included);
            result.networksSeen++;
            if (pools.isEmpty()) return;
            String ck = "discovery_pool_cursor_v8_" + d.gtId.replace('-', '_');
            int cursor = Math.max(0, prefs.getInt(ck, 0));
            int count = Math.min(MAX_POOLS_PER_NETWORK, pools.size());
            for (int n = 0; n < count; n++) {
                Pool pool = pools.get((cursor + n) % pools.size());
                if (pool.address.isEmpty() || pool.networkId.isEmpty() || pool.tokenAddress.isEmpty()) continue;
                result.poolsScanned++;
                scanPool(context, prefs, pool, seen, newlySeen, notifyAllowed, result, backfillBudget);
            }
            prefs.edit().putInt(ck, (cursor + count) % Math.max(1, pools.size())).apply();
        } catch (Exception e) {
            result.networkErrors++;
        }
    }

    /** Chain-specific auto-qualified EVM wallets; used by the direct RPC scanner after graduation. */
    public static Map<String, String> autoEvmWalletsForChain(Context context, String chainSlug) {
        Map<String, String> out = new LinkedHashMap<>();
        String raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_AUTO_EVM, "{}");
        try {
            JSONObject root = new JSONObject(raw);
            JSONArray a = root.optJSONArray(norm(chainSlug));
            if (a == null) return out;
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                String address = o.optString("address", "").toLowerCase(Locale.US);
                String label = o.optString("label", shortAddress(address));
                if (isEvmAddress(address)) out.put(address, label);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static int autoEvmWalletCount(Context context) {
        int count = 0;
        String raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_AUTO_EVM, "{}");
        try {
            JSONObject root = new JSONObject(raw);
            JSONArray names = root.names();
            if (names == null) return 0;
            for (int i = 0; i < names.length(); i++) {
                JSONArray a = root.optJSONArray(names.optString(i));
                if (a != null) count += a.length();
            }
        } catch (Exception ignored) {}
        return count;
    }

    private static void scanPool(Context context, SharedPreferences prefs, Pool pool, Set<String> seen,
                                 List<String> newlySeen, boolean notifyAllowed, Result result, int[] backfillBudget) throws Exception {
        String endpoint = GT + "/networks/" + enc(pool.networkId) + "/pools/" + enc(pool.address)
                + "/trades?trade_volume_in_usd_greater_than=" + (long) DISCOVERY_MIN_TRADE_USD;
        JSONObject payload = getJson(endpoint);
        JSONArray data = payload.optJSONArray("data");
        if (data == null || data.length() == 0) return;

        // API is newest first; process oldest first so BUY -> SELL position logic stays chronological.
        int start = Math.max(0, data.length() - MAX_TRADES_PER_POOL);
        for (int i = data.length() - 1; i >= start; i--) {
            JSONObject row = data.optJSONObject(i);
            if (row == null) continue;
            result.tradesObserved++;
            String tradeId = row.optString("id", "");
            JSONObject a = row.optJSONObject("attributes");
            if (a == null) continue;
            String txHash = a.optString("tx_hash", "");
            String wallet = a.optString("tx_from_address", "");
            if (tradeId.isEmpty()) tradeId = pool.networkId + "|" + txHash + "|" + wallet;
            if (wallet.isEmpty() || txHash.isEmpty() || seen.contains(tradeId)) continue;
            seen.add(tradeId); newlySeen.add(tradeId); result.newCandidateTrades++;

            double volume = num(a.optString("volume_in_usd", "0"));
            if (volume < DISCOVERY_MIN_TRADE_USD) continue;
            String fromToken = a.optString("from_token_address", "");
            String toToken = a.optString("to_token_address", "");
            String kind = a.optString("kind", "").toLowerCase(Locale.US);

            String action;
            double tokenAmount;
            double tokenPrice;
            if (sameAddress(pool.tokenAddress, toToken)) {
                action = "BUY";
                tokenAmount = num(a.optString("to_token_amount", "0"));
                tokenPrice = num(a.optString("price_to_in_usd", "0"));
            } else if (sameAddress(pool.tokenAddress, fromToken)) {
                action = "SELL";
                tokenAmount = num(a.optString("from_token_amount", "0"));
                tokenPrice = num(a.optString("price_from_in_usd", "0"));
            } else if ("buy".equals(kind)) {
                action = "BUY";
                tokenAmount = num(a.optString("to_token_amount", "0"));
                tokenPrice = num(a.optString("price_to_in_usd", "0"));
            } else if ("sell".equals(kind)) {
                action = "SELL";
                tokenAmount = num(a.optString("from_token_amount", "0"));
                tokenPrice = num(a.optString("price_from_in_usd", "0"));
            } else continue;
            if (tokenAmount <= 0) continue;

            String chainSlug = chainSlug(pool.networkId);
            String traderLabel = "Auto " + shortAddress(wallet);
            String gtUrl = "https://www.geckoterminal.com/" + pool.networkId + "/pools/" + pool.address;
            EarlyTokenStore.Event e = new EarlyTokenStore.Event();
            e.id = "gt|" + tradeId;
            e.chain = pool.networkName;
            e.chainSlug = chainSlug;
            e.trader = traderLabel;
            e.traderAddress = wallet;
            e.action = action;
            e.confidence = "DISCOVERY • GeckoTerminal on-chain pool trade";
            e.tokenName = pool.tokenName;
            e.tokenSymbol = pool.tokenSymbol;
            e.tokenAddress = pool.tokenAddress;
            e.txHash = txHash;
            e.dexId = pool.dexId;
            e.pairAddress = pool.address;
            e.dexUrl = gtUrl;
            e.timestamp = parseTime(a.optString("block_timestamp", ""));
            e.pairCreatedAt = pool.createdAt;
            e.tokenAmount = tokenAmount;
            e.estimatedSpendUsd = volume;
            e.detectionPriceUsd = tokenPrice > 0 ? tokenPrice : pool.priceUsd;
            e.marketCap = pool.marketCap;
            e.fdv = pool.fdv;
            e.liquidityUsd = pool.liquidity;
            e.volume24h = pool.volume24h;
            e.spendLabel = ("BUY".equals(action) ? "Trade size ~$" : "Proceeds ~$") + money(volume);
            e.riskNote = "Auto-discovered candidate; wallet alerts stay locked until qualification passes.";

            SmartTraderQualificationEngine.Profile candidate = SmartTraderQualificationEngine.ensureDiscoveryCandidate(
                    context, chainSlug, traderLabel, wallet, gtUrl);
            if (candidate != null && !"QUALIFIED".equals(candidate.status) && backfillBudget[0] > 0) {
                HistoricalBackfillEngine.Result h = HistoricalBackfillEngine.maybeBackfill(context, chainSlug, wallet, traderLabel);
                if (h.attempted) {
                    backfillBudget[0]--;
                    result.historyWalletsBackfilled++;
                    result.historyEventsLearned += h.eventsLearned;
                    if (h.qualifiedAfter) result.historyGraduated++;
                }
            }

            boolean traderPass = SmartTraderQualificationEngine.processEvent(context, e);
            if (!traderPass) continue;
            result.qualifiedEvents++;
            autoEnrollEvm(context, chainSlug, traderLabel, wallet);

            boolean tokenPass = "SELL".equals(action) || passesAlertFilters(prefs, pool);
            e.qualifying = tokenPass;
            if (tokenPass && EarlyTokenStore.add(context, e)) {
                result.publishedEvents++;
                if (notifyAllowed && prefs.getBoolean("token_notifications", true)) {
                    String sym = pool.tokenSymbol.isEmpty() ? shortAddress(pool.tokenAddress) : pool.tokenSymbol;
                    NotificationHelper.notify(context, "Auto smart-trader " + action + " • " + sym,
                            traderLabel + " • " + pool.networkName + " • ~$" + money(volume)
                                    + " • score " + e.traderScore, notificationId(tradeId));
                }
            }
        }
    }

    private static List<Pool> parsePools(JSONArray data, Map<String, JSONObject> included) {
        List<Pool> out = new ArrayList<>();
        if (data == null) return out;
        for (int i = 0; i < data.length(); i++) {
            JSONObject row = data.optJSONObject(i); if (row == null) continue;
            JSONObject attr = row.optJSONObject("attributes");
            JSONObject rel = row.optJSONObject("relationships");
            if (attr == null || rel == null) continue;
            String networkRef = relId(rel, "network");
            String baseRef = relId(rel, "base_token");
            String dexRef = relId(rel, "dex");
            String networkId = networkRef;
            JSONObject nInc = included.get(networkRef);
            if (nInc != null) {
                JSONObject na = nInc.optJSONObject("attributes");
                if (na != null && !na.optString("identifier", "").isEmpty()) networkId = na.optString("identifier");
            }
            if (networkId.isEmpty()) {
                String id = row.optString("id", "");
                int k = id.indexOf('_'); if (k > 0) networkId = id.substring(0, k);
            }

            JSONObject baseInc = included.get(baseRef);
            JSONObject ba = baseInc == null ? null : baseInc.optJSONObject("attributes");
            String tokenAddress = ba == null ? "" : ba.optString("address", "");
            if (tokenAddress.isEmpty() && !baseRef.isEmpty()) tokenAddress = stripNetworkPrefix(baseRef, networkId);
            String symbol = ba == null ? "" : ba.optString("symbol", "");
            String name = ba == null ? symbol : ba.optString("name", symbol);
            if (isBaseAsset(symbol)) continue;

            Pool p = new Pool();
            p.networkId = networkId;
            p.networkName = prettyNetwork(networkId, nInc);
            p.address = attr.optString("address", "");
            p.tokenAddress = tokenAddress;
            p.tokenSymbol = symbol;
            p.tokenName = name;
            p.dexId = stripNetworkPrefix(dexRef, networkId);
            p.priceUsd = num(attr.optString("base_token_price_usd", "0"));
            p.marketCap = num(attr.optString("market_cap_usd", "0"));
            p.fdv = num(attr.optString("fdv_usd", "0"));
            p.liquidity = num(attr.optString("reserve_in_usd", "0"));
            JSONObject vols = attr.optJSONObject("volume_usd");
            p.volume24h = vols == null ? 0 : num(vols.optString("h24", "0"));
            p.createdAt = parseTime(attr.optString("pool_created_at", ""));
            if (p.liquidity < DISCOVERY_MIN_LIQ_USD || p.tokenAddress.isEmpty()) continue;
            out.add(p);
        }
        return out;
    }

    private static Map<String, JSONObject> indexIncluded(JSONArray a) {
        Map<String, JSONObject> out = new LinkedHashMap<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            String id = o.optString("id", ""); if (!id.isEmpty()) out.put(id, o);
        }
        return out;
    }

    private static void autoEnrollEvm(Context context, String chainSlug, String label, String wallet) {
        if (!isKnownEvmChain(chainSlug) || !isEvmAddress(wallet)) return;
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONObject root = new JSONObject(p.getString(KEY_AUTO_EVM, "{}"));
            JSONArray a = root.optJSONArray(chainSlug);
            if (a == null) a = new JSONArray();
            String addr = wallet.toLowerCase(Locale.US);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && addr.equalsIgnoreCase(o.optString("address", ""))) return;
            }
            // Keep the direct RPC follow-up set intentionally small per chain.
            if (a.length() >= 10) return;
            a.put(new JSONObject().put("address", addr).put("label", label).put("addedAt", System.currentTimeMillis()));
            root.put(chainSlug, a);
            p.edit().putString(KEY_AUTO_EVM, root.toString()).apply();
        } catch (Exception ignored) {}
    }

    private static boolean passesAlertFilters(SharedPreferences p, Pool pool) {
        double minLiq = prefDouble(p, "token_min_liq", 50_000);
        double minVol = prefDouble(p, "token_min_vol", 20_000);
        double minMc = prefDouble(p, "token_min_mc", 100_000);
        double maxMc = prefDouble(p, "token_max_mc", 20_000_000);
        double cap = pool.marketCap > 0 ? pool.marketCap : pool.fdv;
        return pool.liquidity >= minLiq && pool.volume24h >= minVol && cap >= minMc && cap <= maxMc;
    }

    private static Set<String> loadSeen(SharedPreferences p) {
        Set<String> out = new LinkedHashSet<>();
        try {
            JSONArray a = new JSONArray(p.getString(KEY_SEEN, "[]"));
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i, ""); if (!s.isEmpty()) out.add(s);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void saveSeen(SharedPreferences p, Set<String> all, List<String> newOnes) {
        // Preserve recency. Existing LinkedHashSet order is old->new; newlySeen are appended.
        for (String s : newOnes) { all.remove(s); all.add(s); }
        List<String> xs = new ArrayList<>(all);
        if (xs.size() > MAX_SEEN) xs = xs.subList(xs.size() - MAX_SEEN, xs.size());
        JSONArray a = new JSONArray(); for (String s : xs) a.put(s);
        p.edit().putString(KEY_SEEN, a.toString()).apply();
    }

    private static JSONObject getJson(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12_000); c.setReadTimeout(18_000); c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json;version=20230203");
        c.setRequestProperty("User-Agent", "SmartMarketWatchUltra/8.0");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("GeckoTerminal HTTP " + code);
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = r.readLine()) != null) b.append(line);
        r.close(); c.disconnect(); return new JSONObject(b.toString());
    }

    private static String relId(JSONObject rel, String key) {
        JSONObject x = rel.optJSONObject(key); if (x == null) return "";
        JSONObject d = x.optJSONObject("data"); return d == null ? "" : d.optString("id", "");
    }

    private static String stripNetworkPrefix(String id, String network) {
        if (id == null) return "";
        String prefix = network + "_";
        return id.startsWith(prefix) ? id.substring(prefix.length()) : id;
    }

    private static String chainSlug(String gt) {
        String x = norm(gt);
        if ("eth".equals(x)) return "ethereum";
        if ("polygon_pos".equals(x)) return "polygon";
        if ("avax".equals(x) || "avalanche".equals(x)) return "avalanche";
        if ("zksync".equals(x) || "zksync-era".equals(x) || "zksync_era".equals(x)) return "zksync";
        if ("binance-smart-chain".equals(x) || "bnb".equals(x)) return "bsc";
        return x;
    }

    private static String prettyNetwork(String id, JSONObject included) {
        if (included != null) {
            JSONObject a = included.optJSONObject("attributes");
            if (a != null) {
                String n = a.optString("name", ""); if (!n.isEmpty()) return n;
            }
        }
        String x = chainSlug(id);
        if ("ethereum".equals(x)) return "Ethereum"; if ("solana".equals(x)) return "Solana";
        if ("bsc".equals(x)) return "BNB Chain"; if ("base".equals(x)) return "Base";
        if ("arbitrum".equals(x)) return "Arbitrum"; if ("optimism".equals(x)) return "Optimism";
        if ("polygon".equals(x)) return "Polygon"; if ("avalanche".equals(x)) return "Avalanche";
        if (x.isEmpty()) return "Unknown chain";
        return Character.toUpperCase(x.charAt(0)) + x.substring(1).replace('_', ' ');
    }

    private static boolean isKnownEvmChain(String s) {
        String x = norm(s);
        return "ethereum".equals(x)||"base".equals(x)||"arbitrum".equals(x)||"optimism".equals(x)||"bsc".equals(x)
                ||"polygon".equals(x)||"avalanche".equals(x)||"linea".equals(x)||"scroll".equals(x)||"zksync".equals(x)
                ||"mantle".equals(x)||"sonic".equals(x)||"unichain".equals(x)||"berachain".equals(x)||"blast".equals(x)||"robinhood".equals(x);
    }

    private static boolean isBaseAsset(String symbol) {
        if (symbol == null) return false;
        String s = symbol.toUpperCase(Locale.US);
        return "USDC".equals(s)||"USDT".equals(s)||"DAI".equals(s)||"WETH".equals(s)||"ETH".equals(s)
                ||"WSOL".equals(s)||"SOL".equals(s)||"WBNB".equals(s)||"BNB".equals(s)||"WBTC".equals(s);
    }

    private static boolean sameAddress(String a, String b) {
        if (a == null || b == null) return false;
        if (a.startsWith("0x") || b.startsWith("0x")) return a.equalsIgnoreCase(b);
        return a.equals(b);
    }

    private static boolean isEvmAddress(String s) { return s != null && s.matches("(?i)^0x[0-9a-f]{40}$"); }
    private static String norm(String s) { return s == null ? "" : s.trim().toLowerCase(Locale.US); }
    private static double num(String s) { try { return Double.parseDouble(s); } catch (Exception e) { return 0; } }
    private static double prefDouble(SharedPreferences p,String k,double d){try{return Double.parseDouble(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
    private static long parseTime(String s) { try { return Instant.parse(s).toEpochMilli(); } catch (Exception e) { return System.currentTimeMillis(); } }
    private static String shortAddress(String s) { if (s == null) return ""; return s.length() <= 12 ? s : s.substring(0, 6) + "…" + s.substring(s.length()-4); }
    private static String money(double x) { if (x >= 1_000_000) return String.format(Locale.US,"%.2fM",x/1_000_000.0); if (x >= 1000) return String.format(Locale.US,"%.2fK",x/1000.0); return String.format(Locale.US,"%.0f",x); }
    private static int notificationId(String s) { return 40_000 + Math.abs((s == null ? 0 : s.hashCode()) % 20_000); }
    private static String enc(String s){try{return java.net.URLEncoder.encode(s,"UTF-8").replace("+","%20");}catch(Exception e){return s;}}
    private static String clean(String s){if(s==null||s.isEmpty())return"unknown error";return s.length()>120?s.substring(0,120)+"…":s;}

    private static final class DiscoveryNetwork {
        final String gtId, chainSlug, name;
        DiscoveryNetwork(String gtId, String chainSlug, String name) { this.gtId=gtId; this.chainSlug=chainSlug; this.name=name; }
    }

    private static final class Pool {
        String networkId="", networkName="", address="", tokenAddress="", tokenSymbol="", tokenName="", dexId="";
        double priceUsd=0, marketCap=0, fdv=0, liquidity=0, volume24h=0;
        long createdAt=0;
    }
}
