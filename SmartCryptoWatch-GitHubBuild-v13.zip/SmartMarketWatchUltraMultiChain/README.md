# Smart Market Watch Ultra 13

BTC v13: 24-hour actual-fill backfill on first run, up to 15 BTC-active profitable Hyperliquid traders, per-trader gap-safe incremental polling every 60 seconds, and LONG/SHORT/EXIT history. XAU/USD live WebSocket and price-action trade-level engine are retained.

# Smart Market Watch Ultra 5.0 — Qualified Smart Trader + Multi-Chain Early Token Watch

Read-only Android market-intelligence app. It never asks for seed phrases, private keys, exchange logins or trading permissions.

## What changed in 5.0

Early Token Watch now has a **Smart Trader Qualification Engine** in front of the wallet scanner. The app no longer treats every watched wallet as equally trustworthy.

A wallet must pass configurable evidence gates before its activity is published to Early Token Watch. The default profile favors traders that have a positive recent track record, enough trade history, at least a 45% recent win rate, an average holding period of at least 24 hours, and no strong locally observed rapid-dump pattern. The default minimum qualification score is 70/100.

The engine also keeps its own local trade history. Unknown/manual EVM wallets start as candidates and can graduate only after at least 12 locally observed closed positions with positive aggregate realized PnL, sufficient win rate, sufficient holding time and an acceptable rapid-exit rate.

Low-cap performance is learned over time. If the app observes a trader entering at or below roughly $500K market cap and the same tracked position later reaches at least $5M and 10× the entry market cap, the trader receives a runner-history bonus. This is historical evidence only, not a prediction that a future token will do the same.

## Early Token Watch v5

- Qualified-wallet gate before alerts are allowed into the feed.
- BUY **and SELL** history, rather than buy-only wallet tracking.
- Local position accounting: bought amount, sold amount, approximate proceeds/cost, position remaining and approximate realized ROI on detected sells.
- Qualification snapshot on every event: score, status, recent win rate/PnL/holding time where available, reason for qualification/exclusion, source and source date.
- Direct links to DEX Screener, transaction explorer, trader explorer and the public track-record source when available.
- Solana transaction-level parsing using public JSON-RPC.
- Generic EVM scanning for Ethereum, Base, Arbitrum, Optimism, BNB Chain, Polygon, Avalanche, Linea, Scroll, zkSync Era, Mantle, Sonic, Unichain, Berachain, Blast and Robinhood Chain.
- Custom EVM network fields for newly launched EVM-compatible chains.
- DEX Screener enrichment with pair URL, DEX, price, market cap/FDV, liquidity, 24h volume, pair age, 5m/1h/6h/24h price changes and buy/sell counts.
- Solana top-10 concentration where available.
- 5-minute foreground radar and high-priority notifications for qualifying events.
- Local Early Token Watch history expanded to the newest 200 events.

## Default qualification settings

- Publish only qualified traders: ON
- Minimum Smart Trader score: 70/100
- Minimum recent win rate: 45%
- Minimum average hold: 24 hours
- Maximum locally observed exits under 6 hours: 35%

These are user-adjustable in **Trader qualification & chain settings**.

## Seed research behavior

The bundled Solana seed set is intentionally conservative. Dated public on-chain analytics snapshots are used as evidence inputs, not as guarantees. Swing-style profitable profiles can pass the default gates, while examples with negative recent performance, a low win rate or seconds/minutes holding behavior remain REVIEW/EXCLUDED even when their headline PnL is large.

The app preserves locally learned history separately from the source snapshots. Updating a public snapshot does not erase the locally observed buy/sell/holding record.

## Accuracy notes

BUY/SELL classification is inferred from on-chain balance and transfer changes inside the same transaction. Solana can match stablecoin/SOL or another token flow. EVM BUY detection can match native-asset spend or another ERC-20 outflow. EVM SELL detection deliberately requires a corresponding ERC-20 inflow so a normal wallet transfer is not mislabeled as a sale. That conservative rule means a sell paid purely through an internal native ETH/BNB-style transfer can be missed by the generic EVM parser.

Complex aggregators, bridges, airdrops, account migrations, unusual routers and tokens with non-standard transfer behavior can still require manual verification. DEX Screener enrichment is market data, not a contract-security audit. A qualified trader can still lose money or buy a token that later fails or rugs.

## Chain coverage

Wallet-level parsing in this build covers Solana plus the listed EVM-compatible networks and one custom EVM network at a time. A new EVM chain can be added with its RPC/explorer details without changing the qualification logic. Non-EVM chains such as Sui, Aptos, TON and Tron require dedicated transaction parsers before wallet buy/sell amounts can be reported with the same confidence.

## XAU/USD

The existing free 5-minute XAU/USD engine remains included, using completed candles and an optional Twelve Data spot API key.

## v6 automatic smart-trader discovery
- Uses GeckoTerminal public on-chain data read-only.
- Each pass rotates through newly created pools across networks and learns unique wallet BUY/SELL trades.
- Discovered wallets start in REVIEW/EXCLUDED; discovery itself never grants qualification.
- The existing qualification gate still requires score, win-rate/positive PnL, holding-time and rapid-exit rules.
- Qualified Solana wallets automatically join direct Solana RPC tracking.
- Qualified wallets on supported EVM chains are automatically enrolled for chain-specific direct RPC follow-up (capped per chain).
- The public discovery path deliberately limits itself to a few requests per scan; it learns history over time rather than pretending unknown wallets are profitable.


## v7 historical backfill + dynamic multichain discovery

- Solana, Base, Ethereum, BNB Chain and Arbitrum are scanned every discovery pass.
- One extra network is selected from GeckoTerminal's live network registry each pass, so newly supported chains enter rotation without an app rebuild.
- Fresh candidate wallets are backfilled before qualification. Solana replays recent wallet transactions; supported EVM chains use Blockscout ERC-20 history and only learn swap-like transactions with an explicit stablecoin leg.
- Historical evidence updates trader qualification only and never creates old alerts.
- Backfill remains conservative: ambiguous transfers, airdrops and native-only swaps are ignored rather than counted as profit.
