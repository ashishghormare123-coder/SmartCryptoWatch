package com.smartmarketwatch.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout goldSection, cryptoSection, alertsSection, signalCard, earlyTokenContainer;
    private Button tabGold, tabCrypto, tabAlerts, analyzeButton, liveButton, tokenRadarButton;
    private TextView globalStatus, goldPrice, feedLabel, marketBias, signalDirection, confidenceScore, agreementText;
    private TextView liveStatusText, setupStateText, regimeText, mtfText, closedCandleText;
    private TextView entryValue, stopValue, tp1Value, tp2Value, riskRewardText, modelTrend, modelSweep, modelBreakout, contextText, backtestText;
    private TextView btcText, tokenText, alertsText;
    private ProgressBar confidenceBar;
    private CandleChartView chart;
    private volatile boolean goldBusy = false;
    private long lastCryptoUiRefresh = 0L;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable liveUiTicker = new Runnable() {
        @Override public void run() {
            refreshLivePrice();
            long now = System.currentTimeMillis();
            if (cryptoSection != null && cryptoSection.getVisibility() == View.VISIBLE && now - lastCryptoUiRefresh >= 5000L) {
                refreshCrypto();
                lastCryptoUiRefresh = now;
            }
            uiHandler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bind();
        NotificationHelper.ensureChannels(this);
        requestNotifications();
        wire();
        showTab(0);
        refreshCrypto();
        refreshAlerts();
        updateLiveButton();
        analyzeGold(false);
        uiHandler.post(liveUiTicker);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (liveButton != null) updateLiveButton();
        if (btcText != null) refreshCrypto();
        if (alertsText != null) refreshAlerts();
        updateTokenRadarButton();
        refreshLivePrice();
    }

    @Override
    protected void onDestroy() {
        uiHandler.removeCallbacks(liveUiTicker);
        super.onDestroy();
    }

    private void bind() {
        goldSection = findViewById(R.id.goldSection); cryptoSection = findViewById(R.id.cryptoSection); alertsSection = findViewById(R.id.alertsSection);
        signalCard = findViewById(R.id.signalCard);
        tabGold = findViewById(R.id.tabGold); tabCrypto = findViewById(R.id.tabCrypto); tabAlerts = findViewById(R.id.tabAlerts);
        analyzeButton = findViewById(R.id.analyzeNowButton); liveButton = findViewById(R.id.liveMonitorButton);
        globalStatus = findViewById(R.id.globalStatus); goldPrice = findViewById(R.id.goldPrice); feedLabel = findViewById(R.id.feedLabel); marketBias = findViewById(R.id.marketBias);
        signalDirection = findViewById(R.id.signalDirection); confidenceScore = findViewById(R.id.confidenceScore); confidenceBar = findViewById(R.id.confidenceBar); agreementText = findViewById(R.id.agreementText);
        entryValue = findViewById(R.id.entryValue); stopValue = findViewById(R.id.stopValue); tp1Value = findViewById(R.id.tp1Value); tp2Value = findViewById(R.id.tp2Value); riskRewardText = findViewById(R.id.riskRewardText);
        modelTrend = findViewById(R.id.modelTrend); modelSweep = findViewById(R.id.modelSweep); modelBreakout = findViewById(R.id.modelBreakout); contextText = findViewById(R.id.contextText); backtestText = findViewById(R.id.backtestText);
        chart = findViewById(R.id.candleChart);
        liveStatusText = findViewById(R.id.liveStatusText); setupStateText = findViewById(R.id.setupStateText);
        regimeText = findViewById(R.id.regimeText); mtfText = findViewById(R.id.mtfText); closedCandleText = findViewById(R.id.closedCandleText);
        btcText = findViewById(R.id.btcText); tokenText = findViewById(R.id.tokenText); alertsText = findViewById(R.id.alertsText);
        earlyTokenContainer = findViewById(R.id.earlyTokenContainer); tokenRadarButton = findViewById(R.id.tokenRadarButton);
    }

    private void wire() {
        tabGold.setOnClickListener(v -> showTab(0));
        tabCrypto.setOnClickListener(v -> showTab(1));
        tabAlerts.setOnClickListener(v -> { refreshAlerts(); showTab(2); });
        analyzeButton.setOnClickListener(v -> analyzeGold(true));
        liveButton.setOnClickListener(v -> toggleLive());
        findViewById(R.id.goldSettingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.cryptoCheckButton).setOnClickListener(v -> checkCrypto());
        tokenRadarButton.setOnClickListener(v -> toggleTokenRadar());
        findViewById(R.id.tokenSettingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.clearAlertsButton).setOnClickListener(v -> { AlertStore.clear(this); refreshAlerts(); Toast.makeText(this, "Alert history cleared", Toast.LENGTH_SHORT).show(); });
    }

    private void showTab(int which) {
        goldSection.setVisibility(which == 0 ? View.VISIBLE : View.GONE);
        cryptoSection.setVisibility(which == 1 ? View.VISIBLE : View.GONE);
        alertsSection.setVisibility(which == 2 ? View.VISIBLE : View.GONE);
        styleTab(tabGold, which == 0); styleTab(tabCrypto, which == 1); styleTab(tabAlerts, which == 2);
    }

    private void styleTab(Button b, boolean active) {
        b.setBackgroundResource(active ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
        b.setTextColor(getColor(active ? R.color.button_text : R.color.text_primary));
    }

    private void analyzeGold(boolean userTriggered) {
        if (goldBusy) return;
        goldBusy = true;
        analyzeButton.setEnabled(false);
        globalStatus.setText("Analyzing XAUUSD 5-minute market structure…");
        if (userTriggered) Toast.makeText(this, "Running price-action-led XAUUSD analysis", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                GoldEngine.Analysis a = GoldEngine.analyze(getApplicationContext());
                runOnUiThread(() -> renderGold(a));
            } catch (Exception e) {
                String msg = clean(e.getMessage());
                runOnUiThread(() -> {
                    globalStatus.setText("XAUUSD feed error • " + msg);
                    feedLabel.setText("Feed error • open Settings for optional Twelve Data key");
                    Toast.makeText(this, "XAUUSD analysis failed: " + msg, Toast.LENGTH_LONG).show();
                });
            } finally {
                runOnUiThread(() -> { goldBusy = false; analyzeButton.setEnabled(true); });
            }
        }).start();
    }

    private void renderGold(GoldEngine.Analysis a) {
        String time = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(a.analyzedAt));
        globalStatus.setText("Last XAU analysis " + time + " • " + a.session + " • " + (getSharedPreferences("smw", MODE_PRIVATE).getBoolean("gold_live_running", false) ? "LIVE monitor ON" : "manual mode"));
        goldPrice.setText(String.format(Locale.US, "$%,.2f", a.price));
        feedLabel.setText("Feed: " + a.feed + " • " + a.feedQuality);
        setupStateText.setText("STATE • " + a.setupState);
        regimeText.setText("REGIME • " + a.regime);
        mtfText.setText("MTF • " + a.mtfAlignment);
        closedCandleText.setText("Signal candle closed: " + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(a.signalCandleTime)) + " • decisions use completed 5m candles only");
        marketBias.setText("BIAS " + a.bias);

        boolean hasPlan = ("READY".equals(a.setupState) || "WATCH".equals(a.setupState)) && ("LONG".equals(a.direction) || "SHORT".equals(a.direction)) && a.entry > 0 && a.stop > 0 && a.tp1 > 0 && a.tp2 > 0;
        String directionLabel;
        if (a.actionable()) directionLabel = "READY " + a.direction;
        else if (hasPlan && "WATCH".equals(a.setupState)) directionLabel = "WATCH " + a.direction;
        else if (hasPlan) directionLabel = a.setupState + " " + a.direction;
        else directionLabel = a.setupState;
        signalDirection.setText(directionLabel);

        confidenceScore.setText(String.valueOf(a.score));
        confidenceBar.setProgress(a.score);
        agreementText.setText("Price-action setups active: " + a.agreement + "/3 • Primary: " + a.primarySetup + " • " + a.reason);
        modelTrend.setText("Structure Continuation • " + a.trendVote);
        modelSweep.setText("Liquidity Reversal • " + a.sweepVote);
        modelBreakout.setText("Breakout / Retest • " + a.breakoutVote);
        contextText.setText(String.format(Locale.US,
                "Price action leads • Indicators confirm only\nEMA 9/21/50/200: %.2f / %.2f / %.2f / %.2f\nRSI(14): %.1f  •  ATR(14): %.2f  •  ADX(14): %.1f\nExpected move: %.1f pts  •  Required capacity: %.1f pts  •  Session: %s",
                a.ema9, a.ema21, a.ema50, a.ema200, a.rsi, a.atr, a.adx, a.expectedMove / pointSize(), a.requiredCapacity / pointSize(), a.session));
        backtestText.setText(a.backtest.display());

        if (hasPlan) {
            entryValue.setText(price(a.entry));
            stopValue.setText(price(a.stop));
            tp1Value.setText(price(a.tp1));
            tp2Value.setText(price(a.tp2));

            double risk = Math.abs(a.entry - a.stop);
            double riskPts = risk / pointSize();
            double rr1 = risk > 0 ? Math.abs(a.tp1 - a.entry) / risk : 0;
            double rr2 = risk > 0 ? Math.abs(a.tp2 - a.entry) / risk : 0;
            String levelState = a.actionable() ? "READY LEVELS" : "PLANNED LEVELS • NOT READY";
            riskRewardText.setText(String.format(Locale.US,
                    "%s\nEntry %.2f • zone %.2f–%.2f • SL %.2f • TP1 %.2f • TP2 %.2f\nRisk %.1f pts • R:R TP1 %.2f • TP2 %.2f • Capacity %.1f / %.1f pts",
                    levelState, a.entry, Math.min(a.entryLow, a.entryHigh), Math.max(a.entryLow, a.entryHigh), a.stop, a.tp1, a.tp2,
                    riskPts, rr1, rr2, a.expectedMove / pointSize(), a.requiredCapacity / pointSize()));

            if (a.actionable()) {
                if ("LONG".equals(a.direction)) { signalCard.setBackgroundResource(R.drawable.bg_signal_buy); signalDirection.setTextColor(getColor(R.color.buy)); }
                else { signalCard.setBackgroundResource(R.drawable.bg_signal_sell); signalDirection.setTextColor(getColor(R.color.sell)); }
            } else {
                signalCard.setBackgroundResource(R.drawable.bg_signal_wait);
                signalDirection.setTextColor(getColor(R.color.warn));
            }
        } else {
            entryValue.setText("—"); stopValue.setText("—"); tp1Value.setText("—"); tp2Value.setText("—");
            riskRewardText.setText(String.format(Locale.US, "%s • waiting for a directional price-action setup that passes quality, structural SL, MTF, adaptive capacity and R:R gates", a.setupState));
            signalCard.setBackgroundResource(R.drawable.bg_signal_wait);
            signalDirection.setTextColor(getColor(R.color.warn));
        }
        // Planned levels are visible on WATCH as well; the card explicitly marks them NOT READY.
        chart.setData(a.candles, a.entry, a.stop, a.tp1, a.tp2, hasPlan);
    }

    private void toggleLive() {
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        boolean running = p.getBoolean("gold_live_running", false);
        Intent i = new Intent(this, GoldMonitorService.class);
        if (running) {
            stopService(i);
            p.edit().putBoolean("gold_live_running", false).apply();
            Toast.makeText(this, "Live XAU monitor stopped", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            p.edit().putBoolean("gold_live_running", true).apply();
            Toast.makeText(this, "Live XAU monitor started", Toast.LENGTH_SHORT).show();
        }
        updateLiveButton();
    }

    private void updateLiveButton() {
        boolean running = getSharedPreferences("smw", MODE_PRIVATE).getBoolean("gold_live_running", false);
        liveButton.setText(running ? "Stop live XAU monitor" : "Start live XAU monitor");
        liveButton.setBackgroundResource(running ? R.drawable.bg_signal_buy : R.drawable.bg_button_secondary);
    }

    private void checkCrypto() {
        globalStatus.setText("Checking BTC traders and smart wallets…");
        findViewById(R.id.cryptoCheckButton).setEnabled(false);
        new Thread(() -> {
            CryptoEngine.runAll(getApplicationContext());
            runOnUiThread(() -> {
                refreshCrypto();
                globalStatus.setText("Crypto check completed");
                findViewById(R.id.cryptoCheckButton).setEnabled(true);
            });
        }).start();
    }

    private void refreshCrypto() {
        SharedPreferences p = getSharedPreferences("scw", MODE_PRIVATE);
        btcText.setText(p.getString("btc_display", "Tap Scan smart wallets now to load trader positions."));
        tokenText.setText(p.getString("token_display", "Tap Scan smart wallets now. v13 adds a 24h BTC fill backfill, a larger BTC-active profitable trader roster, and 60-second fresh-fill monitoring; XAU/USD v11 trade levels remain intact."));
        renderEarlyTokenEvents();
        updateTokenRadarButton();
    }

    private void toggleTokenRadar() {
        SharedPreferences p = getSharedPreferences("scw", MODE_PRIVATE);
        boolean running = p.getBoolean("token_radar_running", false);
        Intent i = new Intent(this, CryptoMonitorService.class);
        if (running) {
            stopService(i);
            p.edit().putBoolean("token_radar_running", false).apply();
            Toast.makeText(this, "Live crypto radar stopped", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            p.edit().putBoolean("token_radar_running", true).apply();
            Toast.makeText(this, "Live crypto radar started • BTC 60s + tokens 5m", Toast.LENGTH_SHORT).show();
        }
        updateTokenRadarButton();
    }

    private void updateTokenRadarButton() {
        if (tokenRadarButton == null) return;
        boolean running = getSharedPreferences("scw", MODE_PRIVATE).getBoolean("token_radar_running", false);
        tokenRadarButton.setText(running ? "Stop live crypto radar" : "Start live crypto radar");
        tokenRadarButton.setBackgroundResource(running ? R.drawable.bg_signal_buy : R.drawable.bg_button_secondary);
    }

    private void renderEarlyTokenEvents() {
        if (earlyTokenContainer == null) return;
        earlyTokenContainer.removeAllViews();
        java.util.List<EarlyTokenStore.Event> events = EarlyTokenStore.get(this);
        if (events.isEmpty()) {
            TextView empty = makeText("No qualified smart-trader BUY/SELL events stored yet. The qualification engine filters wallets first; accepted trades appear here with amount, time, trader score, transaction and DEX Screener links.", 12, R.color.text_secondary, false);
            earlyTokenContainer.addView(empty);
            return;
        }
        int shown = Math.min(20, events.size());
        for (int i=0;i<shown;i++) earlyTokenContainer.addView(makeEarlyCard(events.get(i)));
    }

    private View makeEarlyCard(EarlyTokenStore.Event e) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackgroundResource(R.drawable.bg_panel2);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(10);
        card.setLayoutParams(cp);

        String symbol = blank(e.tokenSymbol) ? shortAddr(e.tokenAddress) : e.tokenSymbol;
        String title = symbol + "  •  " + e.action + "  •  " + e.chain;
        int headColor = "SELL".equalsIgnoreCase(e.action) ? R.color.sell : (e.qualifying ? R.color.buy : R.color.accent2);
        TextView head = makeText(title, 18, headColor, true);
        card.addView(head);

        String when = e.timestamp > 0
                ? DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(e.timestamp))
                : "time unavailable";
        card.addView(makeText((blank(e.trader) ? shortAddr(e.traderAddress) : e.trader)
                + "  •  " + when + "\n" + e.confidence, 11, R.color.text_secondary, false));

        StringBuilder q = new StringBuilder();
        q.append("SMART TRADER  ").append(e.traderScore).append("/100  •  ").append(blank(e.traderStatus)?"REVIEW":e.traderStatus);
        if (!Double.isNaN(e.traderWinRate30d)) q.append("\n30d win ").append(String.format(Locale.US,"%.1f%%",e.traderWinRate30d));
        if (!Double.isNaN(e.traderPnlUsd30d)) q.append("  •  PnL $").append(formatMoney(e.traderPnlUsd30d));
        if (!Double.isNaN(e.traderAvgHoldHours30d)) q.append("  •  Avg hold ").append(holdTime(e.traderAvgHoldHours30d));
        if (e.traderObservedMoonshots > 0) q.append("\nObserved low-cap 10× runners: ").append(e.traderObservedMoonshots);
        if (!blank(e.traderSource)) {
            q.append("\nSource: ").append(e.traderSource);
            if (e.traderSourceAsOf > 0) q.append(" • as of ").append(DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(e.traderSourceAsOf)));
        }
        if (!blank(e.traderReason)) q.append("\n").append(e.traderReason);
        TextView qText = makeText(q.toString(), 11, R.color.accent2, true);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        qp.topMargin = dp(7); qText.setLayoutParams(qp); card.addView(qText);

        boolean isSell = "SELL".equalsIgnoreCase(e.action);
        StringBuilder trade = new StringBuilder();
        trade.append(isSell ? "Sold: " : "Purchased: ").append(formatAmount(e.tokenAmount)).append(" ").append(symbol);
        if (!blank(e.spendLabel)) trade.append("\n").append(e.spendLabel);
        if (e.estimatedSpendUsd > 0) trade.append("\nApprox tx value: ~$").append(formatMoney(e.estimatedSpendUsd));
        if (e.walletTokenBalance >= 0) trade.append("\nWallet balance after tx: ").append(formatAmount(e.walletTokenBalance)).append(" ").append(symbol);
        if (isSell && !Double.isNaN(e.realizedRoiPct)) trade.append("\nApprox ROI on this sold portion: ").append(String.format(Locale.US,"%+.1f%%",e.realizedRoiPct));
        if (isSell && e.positionRemaining >= 0) trade.append("\nTracked position remaining: ").append(formatAmount(e.positionRemaining)).append(" ").append(symbol);
        TextView tradeText = makeText(trade.toString(), 14, R.color.text_primary, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(8);
        tradeText.setLayoutParams(tp);
        card.addView(tradeText);

        String cap = e.marketCap > 0 ? formatMoney(e.marketCap) : (e.fdv > 0 ? formatMoney(e.fdv) : "—");
        String pairAge = pairAge(e.pairCreatedAt);
        String metrics = "Price $" + priceToken(e.detectionPriceUsd) + "  •  MC/FDV $" + cap
                + "\nLiquidity $" + formatMoney(e.liquidityUsd) + "  •  24h Vol $" + formatMoney(e.volume24h)
                + "\nDEX " + (blank(e.dexId) ? "—" : e.dexId) + "  •  Pair age " + pairAge
                + "\n5m " + pct(e.priceChange5m) + "  •  1h " + pct(e.priceChange1h) + "  •  6h " + pct(e.priceChange6h) + "  •  24h " + pct(e.priceChange24h)
                + "\nTxns 5m B/S " + count(e.buys5m) + "/" + count(e.sells5m) + "  •  1h " + count(e.buys1h) + "/" + count(e.sells1h)
                + (e.top10Pct >= 0 ? "\nTop-10 concentration " + String.format(Locale.US, "%.1f%%", e.top10Pct) : "");
        TextView metricText = makeText(metrics, 12, R.color.text_secondary, false);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mp.topMargin = dp(8);
        metricText.setLayoutParams(mp);
        card.addView(metricText);

        if (!blank(e.riskNote)) {
            TextView risk = makeText(e.riskNote, 11, R.color.warn, false);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.topMargin = dp(7);
            risk.setLayoutParams(rp);
            card.addView(risk);
        }

        TextView contract = makeText("Contract: " + e.tokenAddress + "\nTrader: " + e.traderAddress, 10, R.color.text_secondary, false);
        contract.setTextIsSelectable(true);
        LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        xp.topMargin = dp(7);
        contract.setLayoutParams(xp);
        card.addView(contract);

        LinearLayout links = new LinearLayout(this);
        links.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        links.setLayoutParams(lp);
        if (!blank(e.dexUrl)) links.addView(linkButton("DEX Screener", e.dexUrl));
        if (!blank(e.explorerTxUrl)) links.addView(linkButton("TX", e.explorerTxUrl));
        if (!blank(e.explorerTraderUrl)) links.addView(linkButton("Trader", e.explorerTraderUrl));
        if (!blank(e.traderSourceUrl)) links.addView(linkButton("Track record", e.traderSourceUrl));
        if (links.getChildCount() > 0) card.addView(links);
        return card;
    }

    private Button linkButton(String label, String url) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(11); b.setTextColor(getColor(R.color.text_primary)); b.setBackgroundResource(R.drawable.bg_chip);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1); p.setMargins(dp(3),0,dp(3),0); b.setLayoutParams(p);
        b.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ex) { Toast.makeText(this,"Could not open link",Toast.LENGTH_SHORT).show(); } });
        return b;
    }

    private TextView makeText(String text, int sp, int colorRes, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(sp); t.setTextColor(getColor(colorRes));
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private boolean blank(String s){return s==null||s.trim().isEmpty();}
    private String shortAddr(String s){if(s==null)return"";return s.length()<=12?s:s.substring(0,6)+"…"+s.substring(s.length()-4);}
    private String formatAmount(double v){if(v>=1_000_000)return String.format(Locale.US,"%.2fM",v/1_000_000.0);if(v>=1000)return String.format(Locale.US,"%.2fK",v/1000.0);if(v>=1)return String.format(Locale.US,"%.4f",v);return String.format(Locale.US,"%.8f",v);}
    private String formatMoney(double v){if(v<=0)return"—";if(v>=1_000_000_000)return String.format(Locale.US,"%.2fB",v/1_000_000_000.0);if(v>=1_000_000)return String.format(Locale.US,"%.2fM",v/1_000_000.0);if(v>=1000)return String.format(Locale.US,"%.2fK",v/1000.0);return String.format(Locale.US,"%.2f",v);}
    private String priceToken(double v){if(v<=0)return"—";if(v>=1)return String.format(Locale.US,"%.6f",v);if(v>=0.0001)return String.format(Locale.US,"%.8f",v);return String.format(Locale.US,"%.10f",v);}
    private String pct(double v){return Double.isNaN(v)?"—":String.format(Locale.US,"%+.1f%%",v);}
    private String count(int v){return v<0?"—":String.valueOf(v);}
    private String holdTime(double hours){if(Double.isNaN(hours)||Double.isInfinite(hours))return"—";if(hours>=48)return String.format(Locale.US,"%.1fd",hours/24.0);return String.format(Locale.US,"%.0fh",hours);}
    private String pairAge(long created){if(created<=0)return"—";long ms=Math.max(0,System.currentTimeMillis()-created);long min=ms/60000;if(min<60)return min+"m";long h=min/60;if(h<48)return h+"h";return (h/24)+"d";}

    private void refreshAlerts() { alertsText.setText(AlertStore.get(this)); }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }


    private void refreshLivePrice() {
        if (goldPrice == null || liveStatusText == null) return;
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        long t = p.getLong("live_tick_time", 0);
        double live = Double.longBitsToDouble(p.getLong("live_price_bits", Double.doubleToRawLongBits(0)));
        String state = p.getString("live_feed_state", "REST candle mode");
        long age = t > 0 ? Math.max(0, (System.currentTimeMillis() - t) / 1000L) : -1;
        boolean fresh = live > 0 && age >= 0 && age <= 90;
        if (fresh) goldPrice.setText(String.format(Locale.US, "$%,.2f", live));

        String suffix = "";
        if (fresh && p.getBoolean("gold_last_actionable", false)) {
            double lo = Double.longBitsToDouble(p.getLong("gold_last_entry_low", Double.doubleToRawLongBits(0)));
            double hi = Double.longBitsToDouble(p.getLong("gold_last_entry_high", Double.doubleToRawLongBits(0)));
            double min = Math.min(lo, hi), max = Math.max(lo, hi);
            if (min > 0 && max > 0) {
                if (live >= min && live <= max) suffix = " • ENTRY ZONE";
                else {
                    double distance = live < min ? min - live : live - max;
                    suffix = String.format(Locale.US, " • %.1f pts from zone", distance / pointSize());
                }
            }
        }

        liveStatusText.setText(fresh
                ? ("LIVE XAU/USD • " + age + "s • " + state + suffix)
                : ("FREE 5M ENGINE • " + state));
    }
    private double prefDouble(String key, double d) { try { return Double.parseDouble(getSharedPreferences("smw", MODE_PRIVATE).getString(key, String.valueOf(d))); } catch (Exception e) { return d; } }
    private double pointSize() { return Math.max(0.0001, prefDouble("point_size", 1)); }
    private double tp1Points() { return prefDouble("tp1_points", 10); }
    private double tp2Points() { return prefDouble("tp2_points", 15); }
    private double minScore() { return prefDouble("min_score", 76); }
    private String price(double x) { return String.format(Locale.US, "%.2f", x); }
    private String clean(String s) { if (s == null) return "unknown error"; return s.length() > 150 ? s.substring(0, 150) + "…" : s; }
}
