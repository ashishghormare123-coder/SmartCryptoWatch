package com.smartcryptowatch.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView statusText;
    private TextView btcText;
    private TextView tokenText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        btcText = findViewById(R.id.btcText);
        tokenText = findViewById(R.id.tokenText);
        Button check = findViewById(R.id.checkNowButton);
        Button settings = findViewById(R.id.settingsButton);

        NotificationHelper.ensureChannel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
        JobSchedulerHelper.schedule(this);
        refresh();

        check.setOnClickListener(v -> {
            check.setEnabled(false);
            statusText.setText("Checking public wallet data…");
            new Thread(() -> {
                MonitorEngine.runAll(getApplicationContext());
                runOnUiThread(() -> {
                    check.setEnabled(true);
                    refresh();
                });
            }).start();
        });

        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (btcText != null) refresh();
    }

    private void refresh() {
        SharedPreferences p = getSharedPreferences("scw", MODE_PRIVATE);
        statusText.setText(p.getString("last_status", "Monitoring every ~15 minutes"));
        btcText.setText(p.getString("btc_display", "No checks yet."));
        tokenText.setText(p.getString("token_display", "No checks yet."));
    }
}
