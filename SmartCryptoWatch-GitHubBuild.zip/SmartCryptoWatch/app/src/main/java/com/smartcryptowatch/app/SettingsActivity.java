package com.smartcryptowatch.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        SharedPreferences p = getSharedPreferences("scw", MODE_PRIVATE);
        CheckBox btc = findViewById(R.id.btcNotifications);
        CheckBox token = findViewById(R.id.tokenNotifications);
        EditText rpc = findViewById(R.id.rpcUrl);
        Button save = findViewById(R.id.saveButton);

        btc.setChecked(p.getBoolean("btc_notifications", true));
        token.setChecked(p.getBoolean("token_notifications", true));
        rpc.setText(p.getString("rpc_url", "https://api.mainnet-beta.solana.com"));

        save.setOnClickListener(v -> {
            String rpcValue = rpc.getText().toString().trim();
            if (rpcValue.isEmpty()) rpcValue = "https://api.mainnet-beta.solana.com";
            p.edit()
                    .putBoolean("btc_notifications", btc.isChecked())
                    .putBoolean("token_notifications", token.isChecked())
                    .putString("rpc_url", rpcValue)
                    .apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
