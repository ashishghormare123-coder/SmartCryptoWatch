package com.smartcryptowatch.app;

import android.app.job.JobParameters;
import android.app.job.JobService;

public class MonitorJobService extends JobService {
    @Override
    public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                MonitorEngine.runAll(getApplicationContext());
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
