package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.DateFormat;
import java.util.Date;

public final class AlertStore {
    private AlertStore() {}

    public static synchronized void add(Context context, String title, String body) {
        SharedPreferences p = context.getSharedPreferences("smw", Context.MODE_PRIVATE);
        String old = p.getString("alert_history", "");
        String now = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date());
        String item = now + "\n" + title + "\n" + body.trim();
        String combined = old.isEmpty() ? item : item + "\n\n────────────\n\n" + old;
        if (combined.length() > 12000) combined = combined.substring(0, 12000);
        p.edit().putString("alert_history", combined).apply();
    }

    public static String get(Context context) {
        return context.getSharedPreferences("smw", Context.MODE_PRIVATE).getString("alert_history", "No alerts yet.");
    }

    public static synchronized void removeGold(Context context) {
        SharedPreferences p = context.getSharedPreferences("smw", Context.MODE_PRIVATE);
        String old = p.getString("alert_history", "");
        if (old.isEmpty()) return;
        String[] blocks = old.split("\n\n────────────\n\n");
        StringBuilder keep = new StringBuilder();
        for (String block : blocks) {
            String b = block == null ? "" : block.trim();
            if (b.isEmpty()) continue;
            boolean gold = b.contains("XAU/USD") || b.contains("XAUUSD") || b.contains("XAU USD");
            if (gold) continue;
            if (keep.length() > 0) keep.append("\n\n────────────\n\n");
            keep.append(b);
        }
        SharedPreferences.Editor ed = p.edit();
        if (keep.length() == 0) ed.remove("alert_history"); else ed.putString("alert_history", keep.toString());
        ed.apply();
    }

    public static void clear(Context context) {
        context.getSharedPreferences("smw", Context.MODE_PRIVATE).edit().remove("alert_history").apply();
    }
}
