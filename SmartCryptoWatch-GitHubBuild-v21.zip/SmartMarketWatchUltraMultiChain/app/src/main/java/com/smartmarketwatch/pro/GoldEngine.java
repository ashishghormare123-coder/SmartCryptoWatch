package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public final class GoldEngine {
    private GoldEngine() {}

    public static class Candle {
        public long time;
        public double open, high, low, close, volume;
        Candle(long time, double open, double high, double low, double close, double volume) {
            this.time = time; this.open = open; this.high = high; this.low = low; this.close = close; this.volume = volume;
        }
    }

    public static class Analysis {
        public String feed = "";
        public String feedQuality = "";
        public String direction = "WAIT";
        public String setupState = "WAIT";
        public String bias = "NEUTRAL";
        public String trendVote = "WAIT";
        public String sweepVote = "WAIT";
        public String breakoutVote = "WAIT";
        public String session = "Off-session";
        public String reason = "";
        public String regime = "UNKNOWN";
        public String mtfAlignment = "MIXED";
        public String primarySetup = "NONE";
        public int patternQuality = 0;
        public int score = 0;
        public int agreement = 0;
        public double price = 0;
        public double entry = 0;
        public double entryLow = 0;
        public double entryHigh = 0;
        public double stop = 0;
        public double tp1 = 0;
        public double tp2 = 0;
        public double rr = 0;
        public double ema9 = 0, ema21 = 0, ema50 = 0, ema200 = 0, rsi = 0, atr = 0, adx = 0;
        public double macd = 0, macdSignal = 0, macdHist = 0;
        public double expectedMove = 0;
        public double requiredCapacity = 0;
        public long signalCandleTime = 0;
        public long analyzedAt = 0;
        public List<Candle> candles = new ArrayList<>();
        public BacktestStats backtest = new BacktestStats();
        public boolean actionable() { return "READY".equals(setupState) && ("LONG".equals(direction) || "SHORT".equals(direction)); }
    }

    public static class BacktestStats {
        public int signals, tp1First, tp2First, stopFirst, unresolved, sampleBars;
        public double avgMfePoints, avgMaePoints;
        public String display() {
            if (signals == 0) return "No qualifying READY signals in the recent sample.";
            double p1 = 100.0 * tp1First / signals;
            double p2 = 100.0 * tp2First / signals;
            double sl = 100.0 * stopFirst / signals;
            return String.format(Locale.US,
                    "READY signals: %d  •  TP1 before SL: %.1f%%  •  TP2 before SL: %.1f%%\nStop first: %.1f%%  •  Avg MFE: %.1f pts  •  Avg MAE: %.1f pts\nSample: %d completed 5-minute bars",
                    signals, p1, p2, sl, avgMfePoints, avgMaePoints, sampleBars);
        }
    }

    private static class Indicators {
        double[] ema9, ema21, ema50, ema200, rsi, atr, adx, macd, macdSignal, macdHist;
    }

    private static class SignalEval {
        int trendVote, sweepVote, breakoutVote, direction, score, agreement, patternQuality;
        double entry, entryLow, entryHigh, stop, tp1, tp2, rr, expectedMove, requiredCapacity;
        String bias, session, reason, regime, mtfAlignment, setupState, primarySetup;
        boolean actionable;
    }

    private static class Settings {
        double minScore, pointSize, tp1Pts, tp2Pts, minRr;
        boolean sessionOnly;
        static Settings from(SharedPreferences p) {
            Settings s = new Settings();
            s.minScore = getDouble(p, "min_score", 72);
            s.pointSize = Math.max(0.0001, getDouble(p, "point_size", 1.0));
            s.tp1Pts = Math.max(1, getDouble(p, "tp1_points", 8));
            s.tp2Pts = Math.max(s.tp1Pts, getDouble(p, "tp2_points", 10));
            s.minRr = Math.max(0.7, getDouble(p, "min_rr", 1.0));
            s.sessionOnly = p.getBoolean("session_only", false);
            return s;
        }
    }

    private static class DataPack {
        String feed, quality;
        boolean tradeGrade;
        List<Candle> candles = new ArrayList<>();
    }

    private static void migrateYoutubeStrategy21(Context context, SharedPreferences p) {
        if (p.getInt("gold_strategy_version", 0) >= 21) return;
        SharedPreferences.Editor ed = p.edit().putInt("gold_strategy_version", 21);
        String score = p.getString("min_score", "72");
        String t1 = p.getString("tp1_points", "8");
        String t2 = p.getString("tp2_points", "10");
        String rr = p.getString("min_rr", "1.0");
        if ("78".equals(score) || "76".equals(score)) ed.putString("min_score", "72");
        if ("10".equals(t1) && "15".equals(t2)) { ed.putString("tp1_points", "8"); ed.putString("tp2_points", "10"); }
        if ("1.25".equals(rr)) ed.putString("min_rr", "1.0");
        ed.apply();
        GoldSignalTracker.resetForNewStrategy(context, 21);
    }

    /** Conservative XAU/USD trading-session gate used to avoid weekend/rollover pseudo-quotes. */
    public static boolean isMarketOpenNow() { return isMarketTimestamp(System.currentTimeMillis()); }

    public static String marketStateNow() {
        if (isMarketOpenNow()) return "OPEN";
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int day = c.get(Calendar.DAY_OF_WEEK);
        if (day == Calendar.SATURDAY || day == Calendar.SUNDAY) return "WEEKEND CLOSED";
        return "DAILY ROLLOVER / CLOSED";
    }

    private static boolean isMarketTimestamp(long millis) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTimeInMillis(millis);
        int day = c.get(Calendar.DAY_OF_WEEK);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        if (day == Calendar.SATURDAY) return false;
        // Conservative global spot-metals weekend window. Providers/brokers can vary slightly.
        if (day == Calendar.SUNDAY && hour < 22) return false;
        if (day == Calendar.FRIDAY && hour >= 21) return false;
        // Avoid the common daily metals rollover/maintenance window.
        if (day >= Calendar.MONDAY && day <= Calendar.THURSDAY && hour >= 21 && hour < 22) return false;
        return true;
    }

    public static Analysis analyze(Context context) throws Exception {
        SharedPreferences p = context.getSharedPreferences("smw", Context.MODE_PRIVATE);
        migrateYoutubeStrategy21(context, p);
        String key = p.getString("twelve_key", "").trim();
        DataPack data;
        if (!key.isEmpty()) {
            try { data = fetchTwelve(key); }
            catch (Exception e) {
                data = fetchYahoo();
                data.quality = "FALLBACK • not broker-identical";
                data.feed += " • Twelve Data unavailable";
            }
        } else {
            data = fetchYahoo();
            data.quality = "FALLBACK • add Twelve Data key for live spot feed";
        }

        if (data.candles.size() < 260) throw new Exception("Not enough completed 5-minute XAUUSD candles returned by data feed");

        int i = lastClosedIndex(data.candles, System.currentTimeMillis());
        if (i < 220) throw new Exception("Not enough completed candles for multi-timeframe analysis");
        List<Candle> closed = new ArrayList<>(data.candles.subList(0, i + 1));
        Indicators ind = indicators(closed);
        Settings s = Settings.from(p);
        SignalEval ev = evaluate(closed, ind, closed.size() - 1, s);

        Analysis a = new Analysis();
        a.feed = data.feed;
        a.feedQuality = data.quality;
        a.candles = new ArrayList<>(closed.subList(Math.max(0, closed.size() - 100), closed.size()));
        Candle last = closed.get(closed.size() - 1);
        a.price = last.close;
        long now = System.currentTimeMillis();
        boolean marketOpen = isMarketOpenNow();
        boolean staleWhileOpen = marketOpen && now - last.time > 20 * 60_000L;
        if (!data.tradeGrade) {
            ev.actionable = false;
            ev.setupState = "REFERENCE";
            ev.reason = "Trade alerts are disabled on the fallback/proxy feed. Add a Twelve Data key for exact XAU/USD spot analysis. " + ev.reason;
        } else if (!marketOpen) {
            ev.actionable = false;
            ev.setupState = "MARKET CLOSED";
            ev.session = marketStateNow();
            ev.reason = "XAU/USD is outside the conservative global spot-metals trading window. The app is showing the latest valid completed candle but will not create scalp alerts until the market reopens.";
        } else if (staleWhileOpen) {
            ev.actionable = false;
            ev.setupState = "STALE DATA";
            ev.reason = "The newest completed 5-minute XAU/USD candle is too old for a scalp decision. No trade alert is allowed until fresh data resumes.";
        }
        a.direction = ev.direction > 0 ? "LONG" : ev.direction < 0 ? "SHORT" : "WAIT";
        a.setupState = ev.setupState;
        a.bias = ev.bias;
        a.trendVote = voteName(ev.trendVote);
        a.sweepVote = voteName(ev.sweepVote);
        a.breakoutVote = voteName(ev.breakoutVote);
        a.session = ev.session;
        a.reason = ev.reason;
        a.regime = ev.regime;
        a.mtfAlignment = ev.mtfAlignment;
        a.primarySetup = ev.primarySetup;
        a.patternQuality = ev.patternQuality;
        a.score = ev.score;
        a.agreement = ev.agreement;
        a.entry = ev.entry; a.entryLow = ev.entryLow; a.entryHigh = ev.entryHigh;
        a.stop = ev.stop; a.tp1 = ev.tp1; a.tp2 = ev.tp2; a.rr = ev.rr; a.expectedMove = ev.expectedMove; a.requiredCapacity = ev.requiredCapacity;
        int z = closed.size() - 1;
        a.ema9 = ind.ema9[z]; a.ema21 = ind.ema21[z]; a.ema50 = ind.ema50[z]; a.ema200 = ind.ema200[z];
        a.rsi = ind.rsi[z]; a.atr = ind.atr[z]; a.adx = ind.adx[z];
        a.macd = ind.macd[z]; a.macdSignal = ind.macdSignal[z]; a.macdHist = ind.macdHist[z];
        a.signalCandleTime = last.time;
        a.backtest = backtest(closed, ind, s);
        a.analyzedAt = System.currentTimeMillis();

        p.edit()
                .putString("gold_last_feed", a.feed)
                .putString("gold_last_dir", a.direction)
                .putString("gold_last_state", a.setupState)
                .putInt("gold_last_score", a.score)
                .putLong("gold_last_time", a.analyzedAt)
                .putLong("gold_last_price", Double.doubleToRawLongBits(a.price))
                .putLong("gold_last_candle_time", a.signalCandleTime)
                .putBoolean("gold_last_actionable", a.actionable())
                .putLong("gold_last_entry_low", Double.doubleToRawLongBits(a.entryLow))
                .putLong("gold_last_entry_high", Double.doubleToRawLongBits(a.entryHigh))
                .putLong("gold_last_stop", Double.doubleToRawLongBits(a.stop))
                .putLong("gold_last_tp1", Double.doubleToRawLongBits(a.tp1))
                .putLong("gold_last_tp2", Double.doubleToRawLongBits(a.tp2))
                .apply();
        return a;
    }

    private static int lastClosedIndex(List<Candle> c, long now) {
        int i = c.size() - 1;
        // A five-minute candle is considered closed only after its full 5m window plus a small grace period.
        while (i > 0 && c.get(i).time + 5 * 60_000L + 12_000L > now) i--;
        return i;
    }

    private static SignalEval evaluate(List<Candle> c, Indicators in, int i, Settings s) {
        SignalEval e = new SignalEval();
        e.setupState = "WAIT";
        e.primarySetup = "NONE";
        if (i < 220) { e.bias = "NEUTRAL"; e.session = "Warm-up"; return e; }

        Candle x = c.get(i);
        Candle prev = c.get(i - 1);
        double atr = Math.max(in.atr[i], 0.01);
        double ema50 = in.ema50[i];
        double rsi8 = in.rsi[i];
        double macd = in.macd[i];
        double macdSignal = in.macdSignal[i];
        double hist = in.macdHist[i];
        double range = Math.max(x.high - x.low, 0.0001);
        double body = Math.max(Math.abs(x.close - x.open), 0.0001);
        double bodyPct = body / range;
        double closeLoc = (x.close - x.low) / range;

        // v21 follows one specific YouTube setup from RSI Pro:
        // "XAUUSD Scalping Strategy: RSI + MACD for 1 & 5 Minute Charts".
        // Publicly described core rules: EMA50 trend, RSI(8) pullback/momentum,
        // MACD confirmation, then a directional confirmation candle.
        // TP1/TP2 are adapted to the user's requested 8/10 point scalp targets.
        boolean emaRising = ema50 > in.ema50[Math.max(0, i - 3)];
        boolean emaFalling = ema50 < in.ema50[Math.max(0, i - 3)];
        int trendDir = x.close > ema50 && emaRising ? 1 : x.close < ema50 && emaFalling ? -1 : 0;
        e.trendVote = trendDir;
        e.bias = trendDir > 0 ? "BULLISH" : trendDir < 0 ? "BEARISH" : "NEUTRAL";
        e.mtfAlignment = trendDir > 0 ? "EMA50 UP" : trendDir < 0 ? "EMA50 DOWN" : "EMA50 FLAT";

        int utcHour = utcHour(x.time);
        if (utcHour >= 12 && utcHour < 16) e.session = "London/NY overlap";
        else if (utcHour >= 7 && utcHour < 12) e.session = "London";
        else if (utcHour >= 16 && utcHour < 20) e.session = "New York";
        else e.session = "Off-session";

        // Pullback evidence: RSI crossed back through 50 recently OR price recently
        // corrected toward EMA50. This avoids taking a mature/chased trend leg.
        boolean recentRsiBelow50 = false, recentRsiAbove50 = false;
        boolean recentNearEma50 = false;
        for (int k = Math.max(1, i - 4); k < i; k++) {
            if (in.rsi[k] <= 50) recentRsiBelow50 = true;
            if (in.rsi[k] >= 50) recentRsiAbove50 = true;
            if (Math.abs(c.get(k).close - in.ema50[k]) <= Math.max(in.atr[k], 0.01) * 0.75) recentNearEma50 = true;
        }
        boolean pullbackLong = recentRsiBelow50 || recentNearEma50;
        boolean pullbackShort = recentRsiAbove50 || recentNearEma50;

        boolean rsiLong = rsi8 > 50 && rsi8 < 72 && pullbackLong;
        boolean rsiShort = rsi8 < 50 && rsi8 > 28 && pullbackShort;
        e.sweepVote = rsiLong ? 1 : rsiShort ? -1 : 0;

        boolean macdCrossLongRecent = false, macdCrossShortRecent = false;
        for (int k = Math.max(1, i - 3); k <= i; k++) {
            if (in.macd[k] > in.macdSignal[k] && in.macd[k - 1] <= in.macdSignal[k - 1]) macdCrossLongRecent = true;
            if (in.macd[k] < in.macdSignal[k] && in.macd[k - 1] >= in.macdSignal[k - 1]) macdCrossShortRecent = true;
        }
        boolean macdLong = macd > macdSignal && hist > 0 && (macdCrossLongRecent || hist > in.macdHist[i - 1]);
        boolean macdShort = macd < macdSignal && hist < 0 && (macdCrossShortRecent || hist < in.macdHist[i - 1]);
        e.breakoutVote = macdLong ? 1 : macdShort ? -1 : 0;

        boolean bullishCandle = x.close > x.open && body >= atr * 0.20 && closeLoc >= 0.58 && x.close > prev.close;
        boolean bearishCandle = x.close < x.open && body >= atr * 0.20 && closeLoc <= 0.42 && x.close < prev.close;

        int longAgree = (trendDir > 0 ? 1 : 0) + (rsiLong ? 1 : 0) + (macdLong ? 1 : 0);
        int shortAgree = (trendDir < 0 ? 1 : 0) + (rsiShort ? 1 : 0) + (macdShort ? 1 : 0);
        e.agreement = Math.max(longAgree, shortAgree);
        if (trendDir > 0 && longAgree >= 2) e.direction = 1;
        else if (trendDir < 0 && shortAgree >= 2) e.direction = -1;
        else e.direction = 0;

        e.primarySetup = e.direction == 0 ? "NONE" : "RSI PRO YOUTUBE SETUP";
        int score = 0;
        if (e.direction != 0) score += 25;                         // EMA50 trend
        if ((e.direction > 0 && pullbackLong) || (e.direction < 0 && pullbackShort)) score += 10;
        if ((e.direction > 0 && rsiLong) || (e.direction < 0 && rsiShort)) score += 20;
        if ((e.direction > 0 && macdLong) || (e.direction < 0 && macdShort)) score += 20;
        boolean candleOk = e.direction > 0 ? bullishCandle : e.direction < 0 && bearishCandle;
        if (candleOk) score += 15;
        if ("London/NY overlap".equals(e.session)) score += 6;
        else if ("London".equals(e.session) || "New York".equals(e.session)) score += 3;
        if (bodyPct >= 0.48) score += 3;
        e.score = Math.max(0, Math.min(99, score));
        e.patternQuality = e.score;

        e.regime = trendDir == 0 ? "TRANSITION" : Math.abs(hist) >= atr * 0.015 ? "TRENDING" : "MOMENTUM BUILDING";

        e.entry = x.close;
        e.entryLow = e.direction > 0 ? x.close - atr * 0.04 : x.close - atr * 0.02;
        e.entryHigh = e.direction > 0 ? x.close + atr * 0.02 : x.close + atr * 0.04;

        double tp1Dist = s.tp1Pts * s.pointSize;
        double tp2Dist = s.tp2Pts * s.pointSize;
        double minStop = Math.max(2.5 * s.pointSize, atr * 0.28);
        if (e.direction > 0) {
            double invalidation = minLow(c, i - 4, i) - atr * 0.04;
            double stopDist = Math.max(minStop, e.entry - invalidation);
            e.stop = e.entry - stopDist;
            e.tp1 = e.entry + tp1Dist;
            e.tp2 = e.entry + tp2Dist;
        } else if (e.direction < 0) {
            double invalidation = maxHigh(c, i - 4, i) + atr * 0.04;
            double stopDist = Math.max(minStop, invalidation - e.entry);
            e.stop = e.entry + stopDist;
            e.tp1 = e.entry - tp1Dist;
            e.tp2 = e.entry - tp2Dist;
        }

        double risk = Math.abs(e.entry - e.stop);
        double rr1 = risk > 0 ? tp1Dist / risk : 0;
        e.rr = risk > 0 ? tp2Dist / risk : 0;
        boolean structuralStopPass = e.direction == 0 || risk <= tp1Dist; // >= 1:1 to TP1
        boolean rrPass = e.direction == 0 || rr1 >= s.minRr;

        double recentRange = maxHigh(c, i - 10, i) - minLow(c, i - 10, i);
        e.expectedMove = Math.max(atr * 1.35, recentRange * 0.42);
        e.requiredCapacity = tp1Dist;
        boolean capacity = e.direction == 0 || e.expectedMove >= tp1Dist;
        boolean antiChase = e.direction == 0 || Math.abs(x.close - ema50) <= atr * 1.65;
        boolean scorePass = e.score >= s.minScore;
        boolean coreRules = e.direction > 0 ? (trendDir > 0 && rsiLong && macdLong && bullishCandle)
                : e.direction < 0 && trendDir < 0 && rsiShort && macdShort && bearishCandle;
        boolean sessionPass = !s.sessionOnly || !"Off-session".equals(e.session);

        e.actionable = e.direction != 0 && coreRules && scorePass && rrPass && structuralStopPass && capacity && antiChase && sessionPass;
        if (e.actionable) e.setupState = "READY";
        else if (e.direction != 0 && e.agreement >= 2 && e.score >= 55) e.setupState = "WATCH";
        else e.setupState = "WAIT";

        StringBuilder reason = new StringBuilder();
        if (e.direction == 0) reason.append("Waiting for EMA50 trend + RSI(8) + MACD alignment. ");
        else reason.append("RSI Pro YouTube setup • EMA50 trend, RSI(8), MACD and confirmation candle. ");
        if (e.direction != 0 && !candleOk) reason.append("Directional confirmation candle not closed yet. ");
        if (e.direction != 0 && !scorePass) reason.append("Confidence is below the configured threshold. ");
        if (e.direction != 0 && !antiChase) reason.append("Price is too extended from EMA50; do not chase. ");
        if (e.direction != 0 && !capacity) reason.append(String.format(Locale.US, "Estimated room %.1f pts is below the %.1f-point TP1 requirement. ", e.expectedMove / s.pointSize, tp1Dist / s.pointSize));
        if (e.direction != 0 && !rrPass) reason.append("Structural stop gives less than the configured minimum R:R to TP1. ");
        if (e.direction != 0 && !structuralStopPass) reason.append("Structural stop is wider than the TP1 distance; skip the scalp. ");
        if (!sessionPass) reason.append("Outside the selected trading session. ");
        if (e.actionable) reason.append("All video-strategy conditions passed on the completed 5m candle.");
        e.reason = reason.toString().trim();
        return e;
    }

    private static int higherTimeframeBias(List<Candle> five, int throughIndex, int minutes) {
        List<Candle> h = aggregate(five.subList(0, throughIndex + 1), minutes);
        if (h.size() < 16) return 0;
        int i = h.size() - 1;
        int structure = structureBias(h, i, 5, 5);
        if (structure != 0) return structure;
        // Fallback only: current close escaping the prior structural range.
        double priorHigh = maxHigh(h, i - 10, i - 2);
        double priorLow = minLow(h, i - 10, i - 2);
        if (h.get(i).close > priorHigh) return 1;
        if (h.get(i).close < priorLow) return -1;
        return 0;
    }

    private static int structureBias(List<Candle> c, int end, int recentBars, int priorBars) {
        if (end < recentBars + priorBars) return 0;
        int recentStart = end - recentBars + 1;
        int priorEnd = recentStart - 1;
        int priorStart = priorEnd - priorBars + 1;
        double rh = maxHigh(c, recentStart, end), rl = minLow(c, recentStart, end);
        double ph = maxHigh(c, priorStart, priorEnd), pl = minLow(c, priorStart, priorEnd);
        double eps = Math.max(0.0001, (ph - pl) * 0.025);
        boolean up = rh > ph + eps && rl > pl + eps;
        boolean dn = rh < ph - eps && rl < pl - eps;
        if (up) return 1;
        if (dn) return -1;
        return 0;
    }

    private static double maxHigh(List<Candle> c, int from, int to) {
        int a = Math.max(0, from), b = Math.min(c.size() - 1, to);
        double v = -Double.MAX_VALUE;
        for (int k = a; k <= b; k++) v = Math.max(v, c.get(k).high);
        return v == -Double.MAX_VALUE ? 0 : v;
    }

    private static double minLow(List<Candle> c, int from, int to) {
        int a = Math.max(0, from), b = Math.min(c.size() - 1, to);
        double v = Double.MAX_VALUE;
        for (int k = a; k <= b; k++) v = Math.min(v, c.get(k).low);
        return v == Double.MAX_VALUE ? 0 : v;
    }

    private static List<Candle> aggregate(List<Candle> src, int minutes) {
        List<Candle> out = new ArrayList<>();
        long bucketMs = minutes * 60_000L;
        Candle cur = null; long bucket = Long.MIN_VALUE;
        for (Candle x : src) {
            long b = (x.time / bucketMs) * bucketMs;
            if (cur == null || b != bucket) {
                if (cur != null) out.add(cur);
                bucket = b; cur = new Candle(b, x.open, x.high, x.low, x.close, x.volume);
            } else {
                cur.high = Math.max(cur.high, x.high); cur.low = Math.min(cur.low, x.low); cur.close = x.close; cur.volume += x.volume;
            }
        }
        if (cur != null) out.add(cur);
        return out;
    }

    private static BacktestStats backtest(List<Candle> c, Indicators ind, Settings s) {
        BacktestStats b = new BacktestStats();
        int start = Math.max(220, c.size() - 1800);
        int end = c.size() - 25;
        b.sampleBars = Math.max(0, end - start);
        double mfeSum = 0, maeSum = 0;
        int nextAllowed = start;
        for (int i = start; i < end; i++) {
            if (i < nextAllowed) continue;
            SignalEval e = evaluate(c, ind, i, s);
            if (!e.actionable) continue;
            b.signals++;
            boolean p1 = false, p2 = false, stopped = false;
            double mfe = 0, mae = 0;
            for (int j = i + 1; j <= Math.min(i + 24, c.size() - 1); j++) {
                Candle x = c.get(j);
                if (e.direction > 0) {
                    mfe = Math.max(mfe, x.high - e.entry); mae = Math.max(mae, e.entry - x.low);
                    boolean sl = x.low <= e.stop, t1 = x.high >= e.tp1, t2 = x.high >= e.tp2;
                    if (sl && (t1 || t2)) { stopped = true; break; }
                    if (sl) { stopped = true; break; }
                    if (t1) p1 = true; if (t2) { p2 = true; break; }
                } else {
                    mfe = Math.max(mfe, e.entry - x.low); mae = Math.max(mae, x.high - e.entry);
                    boolean sl = x.high >= e.stop, t1 = x.low <= e.tp1, t2 = x.low <= e.tp2;
                    if (sl && (t1 || t2)) { stopped = true; break; }
                    if (sl) { stopped = true; break; }
                    if (t1) p1 = true; if (t2) { p2 = true; break; }
                }
            }
            if (p1 && !stopped) b.tp1First++;
            if (p2 && !stopped) b.tp2First++;
            if (stopped) b.stopFirst++;
            if (!p1 && !p2 && !stopped) b.unresolved++;
            mfeSum += mfe / s.pointSize; maeSum += mae / s.pointSize;
            nextAllowed = i + 6;
        }
        if (b.signals > 0) { b.avgMfePoints = mfeSum / b.signals; b.avgMaePoints = maeSum / b.signals; }
        return b;
    }

    private static Indicators indicators(List<Candle> c) {
        Indicators in = new Indicators();
        in.ema9 = ema(c, 8);
        in.ema21 = ema(c, 14);
        in.ema50 = ema(c, 50);
        in.ema200 = ema(c, 200);
        in.rsi = rsi(c, 8);
        in.atr = atr(c, 14);
        in.adx = adx(c, 14);
        double[] e12 = ema(c, 12), e26 = ema(c, 26);
        in.macd = new double[c.size()];
        for (int i = 0; i < c.size(); i++) in.macd[i] = e12[i] - e26[i];
        in.macdSignal = emaSeries(in.macd, 9);
        in.macdHist = new double[c.size()];
        for (int i = 0; i < c.size(); i++) in.macdHist[i] = in.macd[i] - in.macdSignal[i];
        return in;
    }

    private static double[] ema(List<Candle> c, int p) {
        double[] out = new double[c.size()]; double k = 2.0 / (p + 1.0); out[0] = c.get(0).close;
        for (int i=1;i<c.size();i++) out[i] = c.get(i).close*k + out[i-1]*(1-k); return out;
    }

    private static double[] emaSeries(double[] src, int p) {
        double[] out = new double[src.length];
        if (src.length == 0) return out;
        double k = 2.0 / (p + 1.0);
        out[0] = src[0];
        for (int i = 1; i < src.length; i++) out[i] = src[i] * k + out[i - 1] * (1 - k);
        return out;
    }

    private static double[] rsi(List<Candle> c, int p) {
        int n=c.size(); double[] out=new double[n]; double gain=0,loss=0;
        for(int i=1;i<n;i++){double ch=c.get(i).close-c.get(i-1).close,g=Math.max(0,ch),l=Math.max(0,-ch);
            if(i<=p){gain+=g;loss+=l;if(i==p){gain/=p;loss/=p;}}else{gain=(gain*(p-1)+g)/p;loss=(loss*(p-1)+l)/p;}
            out[i]=i>=p?(loss==0?100:100-100/(1+gain/loss)):50;} return out;
    }

    private static double[] atr(List<Candle> c, int p) {
        int n=c.size(); double[] out=new double[n]; double a=0;
        for(int i=0;i<n;i++){Candle x=c.get(i);double tr=i==0?x.high-x.low:Math.max(x.high-x.low,Math.max(Math.abs(x.high-c.get(i-1).close),Math.abs(x.low-c.get(i-1).close)));
            if(i<p){a+=tr;out[i]=tr;if(i==p-1){a/=p;out[i]=a;}}else{a=(a*(p-1)+tr)/p;out[i]=a;}} return out;
    }

    private static double[] adx(List<Candle> c, int p) {
        int n=c.size(); double[] out=new double[n]; if(n<2) return out;
        double smTr=0, smPlus=0, smMinus=0, adx=0;
        double[] dx=new double[n];
        for(int i=1;i<n;i++){
            Candle x=c.get(i), prev=c.get(i-1);
            double up=x.high-prev.high, down=prev.low-x.low;
            double plus=up>down&&up>0?up:0, minus=down>up&&down>0?down:0;
            double tr=Math.max(x.high-x.low,Math.max(Math.abs(x.high-prev.close),Math.abs(x.low-prev.close)));
            if(i<=p){smTr+=tr;smPlus+=plus;smMinus+=minus;}
            else{smTr=smTr-smTr/p+tr;smPlus=smPlus-smPlus/p+plus;smMinus=smMinus-smMinus/p+minus;}
            if(i>=p){double pdi=smTr==0?0:100*smPlus/smTr, mdi=smTr==0?0:100*smMinus/smTr;dx[i]=(pdi+mdi)==0?0:100*Math.abs(pdi-mdi)/(pdi+mdi);}
            if(i==2*p-1){double sum=0;for(int k=p;k<=i;k++)sum+=dx[k];adx=sum/p;out[i]=adx;}
            else if(i>=2*p){adx=(adx*(p-1)+dx[i])/p;out[i]=adx;}
            else out[i]=0;
        }
        return out;
    }

    private static String voteName(int v) { return v>0?"LONG":v<0?"SHORT":"WAIT"; }
    private static double clamp(double x,double lo,double hi){return Math.max(lo,Math.min(hi,x));}
    private static double getDouble(SharedPreferences p,String k,double d){try{return Double.parseDouble(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
    private static int utcHour(long millis){SimpleDateFormat f=new SimpleDateFormat("H",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));try{return Integer.parseInt(f.format(new Date(millis)));}catch(Exception e){return 0;}}

    private static DataPack fetchTwelve(String key) throws Exception {
        String u="https://api.twelvedata.com/time_series?symbol="+URLEncoder.encode("XAU/USD","UTF-8")+"&interval=5min&outputsize=1800&order=asc&timezone=UTC&apikey="+URLEncoder.encode(key,"UTF-8");
        JSONObject root=getJson(u); if("error".equalsIgnoreCase(root.optString("status"))) throw new Exception(root.optString("message","Twelve Data error"));
        JSONArray vals=root.optJSONArray("values"); if(vals==null||vals.length()<50) throw new Exception("Twelve Data returned no usable XAU/USD series");
        DataPack d=new DataPack(); d.feed="Twelve Data • XAU/USD spot"; d.quality="PRIMARY • exact symbol • completed 5m candles"; d.tradeGrade=true;
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
        for(int i=0;i<vals.length();i++){
            JSONObject v=vals.optJSONObject(i); if(v==null) continue;
            try {
                long t=f.parse(v.optString("datetime")).getTime();
                double o=num(v,"open"),h=num(v,"high"),l=num(v,"low"),cc=num(v,"close"),vol=num(v,"volume");
                boolean valid=o>0&&h>0&&l>0&&cc>0&&h>=Math.max(o,cc)&&l<=Math.min(o,cc)&&h>=l;
                if(valid && isMarketTimestamp(t)) d.candles.add(new Candle(t,o,h,l,cc,vol));
            } catch(Exception ignored){}
        }
        if(d.candles.size()>1&&d.candles.get(0).time>d.candles.get(d.candles.size()-1).time)Collections.reverse(d.candles);
        if(d.candles.size()<260) throw new Exception("Not enough valid market-session XAU/USD candles returned by Twelve Data");
        return d;
    }

    private static DataPack fetchYahoo() throws Exception {
        Exception first=null;String[] symbols={"XAUUSD=X","GC=F"};String[] labels={"Yahoo • XAUUSD spot","Yahoo • GC=F futures proxy"};
        for(int s=0;s<symbols.length;s++){try{String sym=URLEncoder.encode(symbols[s],"UTF-8");String u="https://query2.finance.yahoo.com/v8/finance/chart/"+sym+"?interval=5m&range=1mo&includePrePost=true";JSONObject root=getJson(u);JSONObject chart=root.optJSONObject("chart");JSONArray results=chart==null?null:chart.optJSONArray("result");if(results==null||results.length()==0)throw new Exception("Yahoo returned no result");JSONObject r=results.optJSONObject(0);JSONArray ts=r.optJSONArray("timestamp");JSONObject indicators=r.optJSONObject("indicators");JSONArray quotes=indicators==null?null:indicators.optJSONArray("quote");JSONObject q=quotes==null?null:quotes.optJSONObject(0);if(ts==null||q==null)throw new Exception("Yahoo series malformed");JSONArray opens=q.optJSONArray("open"),highs=q.optJSONArray("high"),lows=q.optJSONArray("low"),closes=q.optJSONArray("close"),vols=q.optJSONArray("volume");DataPack d=new DataPack();d.feed=labels[s];d.quality="REFERENCE ONLY • delayed/proxy • alerts disabled";d.tradeGrade=false;for(int i=0;i<ts.length();i++){if(isNull(closes,i)||isNull(opens,i)||isNull(highs,i)||isNull(lows,i))continue;long t=ts.optLong(i,0)*1000L;double o=opens.optDouble(i,0),h=highs.optDouble(i,0),l=lows.optDouble(i,0),cc=closes.optDouble(i,0),v=isNull(vols,i)?0:vols.optDouble(i,0);if(t>0&&o>0&&h>0&&l>0&&cc>0)d.candles.add(new Candle(t,o,h,l,cc,v));}if(d.candles.size()>=260)return d;throw new Exception("Not enough Yahoo candles");}catch(Exception e){if(first==null)first=e;}}
        throw first==null?new Exception("No XAUUSD feed available"):first;
    }

    private static boolean isNull(JSONArray a,int i){return a==null||i>=a.length()||a.isNull(i);} private static double num(JSONObject o,String k){try{return Double.parseDouble(o.optString(k,"0"));}catch(Exception e){return 0;}}
    private static JSONObject getJson(String endpoint)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) SmartMarketWatchUltra/3.0");c.setRequestProperty("Accept","application/json,text/plain,*/*");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();if(in==null)throw new Exception("HTTP "+code);StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}if(code<200||code>=300)throw new Exception("HTTP "+code+": "+trim(sb.toString(),120));return new JSONObject(sb.toString());}
    private static String trim(String s,int n){return s==null?"":s.length()<=n?s:s.substring(0,n)+"…";}
}
