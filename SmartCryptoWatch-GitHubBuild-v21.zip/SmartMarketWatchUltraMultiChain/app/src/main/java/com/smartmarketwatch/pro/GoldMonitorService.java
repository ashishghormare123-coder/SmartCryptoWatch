package com.smartmarketwatch.pro;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import org.json.JSONObject;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * XAU/USD monitor.
 *
 * Signal decisions continue to use completed 5-minute candles only. When a Twelve
 * Data API key is configured, this service also opens Twelve Data's price WebSocket
 * for XAU/USD and writes live ticks to SharedPreferences for the UI. If the account
 * cannot stream XAU/USD, the 5-minute REST signal engine remains active and the UI
 * explicitly reports that the WebSocket is unavailable.
 */
public class GoldMonitorService extends Service {
    public static final int LIVE_NOTIFICATION_ID = 21001;
    private ScheduledExecutorService scheduler;
    private volatile long lastStructureBucket = -1;
    private volatile boolean firstStructureScan = true;

    private OkHttpClient wsClient;
    private volatile WebSocket ws;
    private volatile long lastWsMessageMs = 0;
    private volatile long lastWsAttemptMs = 0;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannels(this);
        startForeground(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, "XAU/USD monitor starting…"));
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        p.edit().putBoolean("gold_live_running", true)
                .putString("live_feed_state", "Twelve Data WS connecting • 5m REST signals")
                .apply();

        wsClient = new OkHttpClient.Builder()
                .pingInterval(20, TimeUnit.SECONDS)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .build();

        scheduler = Executors.newScheduledThreadPool(2);
        scheduler.scheduleWithFixedDelay(this::runStructureScan, 0, 15, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(this::maintainLivePrice, 0, 10, TimeUnit.SECONDS);
    }

    private void maintainLivePrice() {
        try {
            SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
            String key = p.getString("twelve_key", "").trim();
            if (key.isEmpty()) {
                p.edit().putString("live_feed_state", "5m REST • add Twelve Data key for live ticks").apply();
                closeWebSocket();
                return;
            }

            if (!GoldEngine.isMarketOpenNow()) {
                p.edit().putString("live_feed_state", "Twelve Data WS • market closed").apply();
                closeWebSocket();
                return;
            }

            long now = System.currentTimeMillis();
            WebSocket active = ws;
            if (active != null && lastWsMessageMs > 0 && now - lastWsMessageMs <= 45_000L) {
                active.send("{\"action\":\"heartbeat\"}");
                return;
            }

            if (active != null && lastWsMessageMs > 0 && now - lastWsMessageMs > 60_000L) {
                active.cancel();
                ws = null;
            }

            if (ws == null && now - lastWsAttemptMs >= 20_000L) {
                lastWsAttemptMs = now;
                connectWebSocket(key);
            }
        } catch (Exception e) {
            getSharedPreferences("smw", MODE_PRIVATE).edit()
                    .putString("live_feed_state", "WS error • 5m REST active")
                    .apply();
        }
    }

    private synchronized void connectWebSocket(String key) {
        if (ws != null || wsClient == null) return;
        String url = "wss://ws.twelvedata.com/v1/quotes/price?apikey=" + key;
        Request request = new Request.Builder().url(url).build();
        getSharedPreferences("smw", MODE_PRIVATE).edit()
                .putString("live_feed_state", "Twelve Data WS • connecting XAU/USD")
                .apply();

        ws = wsClient.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                webSocket.send("{\"action\":\"subscribe\",\"params\":{\"symbols\":\"XAU/USD\"}}");
                getSharedPreferences("smw", MODE_PRIVATE).edit()
                        .putString("live_feed_state", "Twelve Data WS • subscribed XAU/USD")
                        .apply();
            }

            @Override public void onMessage(WebSocket webSocket, String text) {
                try {
                    JSONObject j = new JSONObject(text);
                    String event = j.optString("event", "");
                    if ("price".equalsIgnoreCase(event) || j.has("price")) {
                        double px = j.optDouble("price", 0);
                        if (px > 0) {
                            long now = System.currentTimeMillis();
                            lastWsMessageMs = now;
                            getSharedPreferences("smw", MODE_PRIVATE).edit()
                                    .putLong("live_price_bits", Double.doubleToRawLongBits(px))
                                    .putLong("live_tick_time", now)
                                    .putString("live_feed_state", "Twelve Data WebSocket • XAU/USD spot")
                                    .apply();
                            GoldSignalTracker.onPrice(getApplicationContext(), px, now);
                        }
                    } else if ("subscribe-status".equalsIgnoreCase(event)) {
                        String status = j.optString("status", "");
                        if (!status.isEmpty() && !"ok".equalsIgnoreCase(status)) {
                            getSharedPreferences("smw", MODE_PRIVATE).edit()
                                    .putString("live_feed_state", "Twelve Data WS subscription: " + status + " • 5m REST active")
                                    .apply();
                        }
                    }
                } catch (Exception ignored) { }
            }

            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                if (ws == webSocket) ws = null;
                getSharedPreferences("smw", MODE_PRIVATE).edit()
                        .putString("live_feed_state", "WS closed • reconnecting • 5m REST active")
                        .apply();
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (ws == webSocket) ws = null;
                String msg = t == null || t.getMessage() == null ? "unavailable" : clean(t.getMessage());
                getSharedPreferences("smw", MODE_PRIVATE).edit()
                        .putString("live_feed_state", "WS unavailable (" + msg + ") • 5m REST active")
                        .apply();
            }
        });
    }

    private synchronized void closeWebSocket() {
        WebSocket x = ws;
        ws = null;
        if (x != null) {
            try { x.close(1000, "monitor pause"); } catch (Exception ignored) { }
        }
        lastWsMessageMs = 0;
    }

    private void runStructureScan() {
        try {
            SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
            if (!GoldEngine.isMarketOpenNow()) {
                String status = "MARKET CLOSED • " + GoldEngine.marketStateNow() + " • monitor sleeping";
                p.edit().putString("gold_live_status", status).apply();
                NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                nm.notify(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, status));
                return;
            }

            long now=System.currentTimeMillis();
            long bucket=now/(5*60_000L);
            long intoBucket=now%(5*60_000L);
            if(!firstStructureScan){
                if(bucket==lastStructureBucket) return;
                if(intoBucket<12_000L) return;
            }
            firstStructureScan=false; lastStructureBucket=bucket;

            GoldEngine.Analysis a=GoldEngine.analyze(getApplicationContext());
            GoldSignalTracker.onPrice(getApplicationContext(), a.price, now);
            boolean planned=("WATCH".equals(a.setupState)) && ("LONG".equals(a.direction)||"SHORT".equals(a.direction));
            String status=a.actionable()
                    ? String.format(Locale.US,"READY %s %d%% • XAU %.2f • zone %.2f–%.2f",a.direction,a.score,a.price,a.entryLow,a.entryHigh)
                    : planned
                        ? String.format(Locale.US,"WATCH %s %d%% • Entry %.2f • SL %.2f • TP1 %.2f",a.direction,a.score,a.entry,a.stop,a.tp1)
                        : String.format(Locale.US,"%s %d%% • XAU %.2f • %s",a.setupState,a.score,a.price,a.regime);
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this,status));

            if(a.actionable()){
                String fingerprint="READY|"+a.direction+"|"+a.signalCandleTime;
                String last=p.getString("gold_last_ready_fingerprint","");
                if(!fingerprint.equals(last)){
                    String body=String.format(Locale.US,
                            "%s • %d/100 • %s • Trend %s\nEntry zone %.2f–%.2f • SL %.2f • TP1 %.2f • TP2 %.2f • R:R %.2f\n%s",
                            a.direction,a.score,a.session,a.mtfAlignment,a.entryLow,a.entryHigh,a.stop,a.tp1,a.tp2,a.rr,a.reason);
                    if(p.getBoolean("gold_alerts",true)) NotificationHelper.notify(this,"XAU/USD setup READY",body,notificationId("ready",a.signalCandleTime));
                    AlertStore.add(this,"XAU/USD READY "+a.direction+" • "+a.score+"/100",body);
                    GoldSignalTracker.registerReady(this, a, fingerprint);
                    p.edit().putString("gold_last_ready_fingerprint",fingerprint).apply();
                }
            }
            p.edit().putString("gold_live_status",status).apply();
        } catch(Exception e){
            String msg="Feed check failed: "+clean(e.getMessage());
            getSharedPreferences("smw",MODE_PRIVATE).edit().putString("gold_live_status",msg).apply();
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(LIVE_NOTIFICATION_ID,NotificationHelper.liveNotification(this,msg));
        }
    }

    private int notificationId(String tag,long candleTime){long x=candleTime^tag.hashCode();return(int)(x&0x7fffffff);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){
        if(scheduler!=null)scheduler.shutdownNow();
        closeWebSocket();
        if(wsClient!=null) wsClient.dispatcher().executorService().shutdown();
        getSharedPreferences("smw",MODE_PRIVATE).edit().putBoolean("gold_live_running",false).apply();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
    private String clean(String s){if(s==null)return"unknown error";return s.length()>90?s.substring(0,90)+"…":s;}
}
