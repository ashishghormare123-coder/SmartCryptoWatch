# Smart Market Watch Ultra 21

BTC v15: wider Hyperliquid leaderboard discovery, dynamic rotation toward recently BTC-active profitable traders, target 18 active traders (max 20), 24-hour actual-fill backfill, 60-second incremental fill monitoring, strict scalp freshness buckets (0-5m / 5-15m / 15-30m / history), entry-first display ordering, last-good BTC midpoint fallback, and LONG/SHORT/EXIT alerts. XAU/USD live WebSocket and price-action trade-level engine are retained.


## v18 qualification tiers
- QUALIFIED = proven trader tier (external validated snapshot or >=6 profitable local closes).
- PROMISING = clearly labelled smaller-sample tier with positive realized PnL, strong win/hold behavior, and no rapid-dump pattern.
- REVIEW/EXCLUDED never publish when strict trader filtering is enabled.
- Solana historical qualification replay increased to 60 recent signatures; discovery can backfill 3 candidate wallets per pass.


## v21 Gold strategy
Gold now follows the RSI Pro YouTube 5-minute XAUUSD setup: EMA50 trend filter, RSI(8), MACD(12,26,9), and a closed confirmation candle. TP1/TP2 remain adapted to 8/10 points. On first v21 analysis, prior Gold signal record and XAU alert history are cleared while BTC/Solana history is preserved.
