# Smart Market Watch Ultra 3.1

Native Android read-only market monitor focused on XAU/USD scalping plus the existing BTC/Solana monitoring.

## What changed in Ultra
- exact XAU/USD spot candles from Twelve Data for trade-grade analysis
- live XAU/USD WebSocket price streaming when the API plan supports it
- fallback/proxy data is **reference only** and can never create a READY/ENTRY alert
- completed 5-minute candle decisions only (reduces repainting)
- 5m + 15m + 1h directional alignment
- EMA 9/21/50/200, RSI(14), ATR(14), ADX(14), session and volatility regime filters
- 3 independent setup models: trend pullback, liquidity sweep/rejection, breakout continuation
- READY / WATCH / WAIT / REFERENCE states instead of forcing a trade
- configurable 10-point TP1 and 15-point TP2, structure-aware stop and minimum R:R gate
- live entry-zone watcher checks streaming price every ~2 seconds and sends a separate ENTRY ZONE HIT alert
- deduplicated alerts per completed 5-minute signal candle
- recent walk-forward-style simulation summary (not a promise of future performance)
- foreground monitoring plus the existing Hyperliquid BTC and Solana smart-wallet tools

## Important
This app does not place trades. It is a signal/monitoring tool, not a guarantee of profitability. XAU/USD quotes can differ between data vendors and brokers, so execute only against the price shown by your own broker.

A Twelve Data API key is strongly recommended. Their WebSocket availability depends on the account/plan.
