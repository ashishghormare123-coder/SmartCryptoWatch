# Intentionally minimal: no shrinking in this personal build.
