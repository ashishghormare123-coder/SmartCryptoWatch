package com.smartmarketwatch.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout goldSection, cryptoSection, alertsSection, signalCard;
    private Button tabGold, tabCrypto, tabAlerts, analyzeButton, liveButton;
    private TextView globalStatus, goldPrice, feedLabel, marketBias, signalDirection, confidenceScore, agreementText;
    private TextView liveStatusText, setupStateText, regimeText, mtfText, closedCandleText;
    private TextView entryValue, stopValue, tp1Value, tp2Value, riskRewardText, modelTrend, modelSweep, modelBreakout, contextText, backtestText;
    private TextView btcText, tokenText, alertsText;
    private ProgressBar confidenceBar;
    private CandleChartView chart;
    private volatile boolean goldBusy = false;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable liveUiTicker = new Runnable() {
        @Override public void run() { refreshLivePrice(); uiHandler.postDelayed(this, 1000); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bind();
        NotificationHelper.ensureChannels(this);
        requestNotifications();
        wire();
        showTab(0);
        refreshCrypto();
        refreshAlerts();
        updateLiveButton();
        analyzeGold(false);
        uiHandler.post(liveUiTicker);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (liveButton != null) updateLiveButton();
        if (btcText != null) refreshCrypto();
        if (alertsText != null) refreshAlerts();
        refreshLivePrice();
    }

    @Override
    protected void onDestroy() {
        uiHandler.removeCallbacks(liveUiTicker);
        super.onDestroy();
    }

    private void bind() {
        goldSection = findViewById(R.id.goldSection); cryptoSection = findViewById(R.id.cryptoSection); alertsSection = findViewById(R.id.alertsSection);
        signalCard = findViewById(R.id.signalCard);
        tabGold = findViewById(R.id.tabGold); tabCrypto = findViewById(R.id.tabCrypto); tabAlerts = findViewById(R.id.tabAlerts);
        analyzeButton = findViewById(R.id.analyzeNowButton); liveButton = findViewById(R.id.liveMonitorButton);
        globalStatus = findViewById(R.id.globalStatus); goldPrice = findViewById(R.id.goldPrice); feedLabel = findViewById(R.id.feedLabel); marketBias = findViewById(R.id.marketBias);
        signalDirection = findViewById(R.id.signalDirection); confidenceScore = findViewById(R.id.confidenceScore); confidenceBar = findViewById(R.id.confidenceBar); agreementText = findViewById(R.id.agreementText);
        entryValue = findViewById(R.id.entryValue); stopValue = findViewById(R.id.stopValue); tp1Value = findViewById(R.id.tp1Value); tp2Value = findViewById(R.id.tp2Value); riskRewardText = findViewById(R.id.riskRewardText);
        modelTrend = findViewById(R.id.modelTrend); modelSweep = findViewById(R.id.modelSweep); modelBreakout = findViewById(R.id.modelBreakout); contextText = findViewById(R.id.contextText); backtestText = findViewById(R.id.backtestText);
        chart = findViewById(R.id.candleChart);
        liveStatusText = findViewById(R.id.liveStatusText); setupStateText = findViewById(R.id.setupStateText);
        regimeText = findViewById(R.id.regimeText); mtfText = findViewById(R.id.mtfText); closedCandleText = findViewById(R.id.closedCandleText);
        btcText = findViewById(R.id.btcText); tokenText = findViewById(R.id.tokenText); alertsText = findViewById(R.id.alertsText);
    }

    private void wire() {
        tabGold.setOnClickListener(v -> showTab(0));
        tabCrypto.setOnClickListener(v -> showTab(1));
        tabAlerts.setOnClickListener(v -> { refreshAlerts(); showTab(2); });
        analyzeButton.setOnClickListener(v -> analyzeGold(true));
        liveButton.setOnClickListener(v -> toggleLive());
        findViewById(R.id.goldSettingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.cryptoCheckButton).setOnClickListener(v -> checkCrypto());
        findViewById(R.id.clearAlertsButton).setOnClickListener(v -> { AlertStore.clear(this); refreshAlerts(); Toast.makeText(this, "Alert history cleared", Toast.LENGTH_SHORT).show(); });
    }

    private void showTab(int which) {
        goldSection.setVisibility(which == 0 ? View.VISIBLE : View.GONE);
        cryptoSection.setVisibility(which == 1 ? View.VISIBLE : View.GONE);
        alertsSection.setVisibility(which == 2 ? View.VISIBLE : View.GONE);
        styleTab(tabGold, which == 0); styleTab(tabCrypto, which == 1); styleTab(tabAlerts, which == 2);
    }

    private void styleTab(Button b, boolean active) {
        b.setBackgroundResource(active ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
        b.setTextColor(getColor(active ? R.color.button_text : R.color.text_primary));
    }

    private void analyzeGold(boolean userTriggered) {
        if (goldBusy) return;
        goldBusy = true;
        analyzeButton.setEnabled(false);
        globalStatus.setText("Analyzing XAUUSD 5-minute market structure…");
        if (userTriggered) Toast.makeText(this, "Running 3-model XAUUSD analysis", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                GoldEngine.Analysis a = GoldEngine.analyze(getApplicationContext());
                runOnUiThread(() -> renderGold(a));
            } catch (Exception e) {
                String msg = clean(e.getMessage());
                runOnUiThread(() -> {
                    globalStatus.setText("XAUUSD feed error • " + msg);
                    feedLabel.setText("Feed error • open Settings for optional Twelve Data key");
                    Toast.makeText(this, "XAUUSD analysis failed: " + msg, Toast.LENGTH_LONG).show();
                });
            } finally {
                runOnUiThread(() -> { goldBusy = false; analyzeButton.setEnabled(true); });
            }
        }).start();
    }

    private void renderGold(GoldEngine.Analysis a) {
        String time = DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(a.analyzedAt));
        globalStatus.setText("Last XAU analysis " + time + " • " + a.session + " • " + (getSharedPreferences("smw", MODE_PRIVATE).getBoolean("gold_live_running", false) ? "LIVE monitor ON" : "manual mode"));
        goldPrice.setText(String.format(Locale.US, "$%,.2f", a.price));
        feedLabel.setText("Feed: " + a.feed + " • " + a.feedQuality);
        setupStateText.setText("STATE • " + a.setupState);
        regimeText.setText("REGIME • " + a.regime);
        mtfText.setText("MTF • " + a.mtfAlignment);
        closedCandleText.setText("Signal candle closed: " + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(a.signalCandleTime)) + " • decisions use completed 5m candles only");
        marketBias.setText("BIAS " + a.bias);
        signalDirection.setText(a.direction);
        confidenceScore.setText(String.valueOf(a.score));
        confidenceBar.setProgress(a.score);
        agreementText.setText("Models agreeing: " + a.agreement + "/3 • " + a.reason);
        modelTrend.setText("Trend Pullback • " + a.trendVote);
        modelSweep.setText("Liquidity Sweep • " + a.sweepVote);
        modelBreakout.setText("Breakout Continuation • " + a.breakoutVote);
        contextText.setText(String.format(Locale.US,
                "EMA 9/21/50/200: %.2f / %.2f / %.2f / %.2f\nRSI(14): %.1f  •  ATR(14): %.2f  •  ADX(14): %.1f\nExpected move: %.1f pts  •  Session: %s",
                a.ema9, a.ema21, a.ema50, a.ema200, a.rsi, a.atr, a.adx, a.expectedMove / pointSize(), a.session));
        backtestText.setText(a.backtest.display());

        if (a.actionable()) {
            entryValue.setText(price(a.entry)); stopValue.setText(price(a.stop)); tp1Value.setText(price(a.tp1)); tp2Value.setText(price(a.tp2));
            riskRewardText.setText(String.format(Locale.US, "Entry zone %.2f–%.2f • Target %.0f / %.0f pts • R:R %.2f • Capacity %.1f pts", a.entryLow, a.entryHigh, tp1Points(), tp2Points(), a.rr, a.expectedMove / pointSize()));
            if ("LONG".equals(a.direction)) { signalCard.setBackgroundResource(R.drawable.bg_signal_buy); signalDirection.setTextColor(getColor(R.color.buy)); }
            else { signalCard.setBackgroundResource(R.drawable.bg_signal_sell); signalDirection.setTextColor(getColor(R.color.sell)); }
        } else {
            entryValue.setText("—"); stopValue.setText("—"); tp1Value.setText("—"); tp2Value.setText("—");
            riskRewardText.setText(String.format(Locale.US, "%s • requires ≥%.0f score, 2/3 agreement, MTF/volatility/R:R gates and %.0f+ point capacity", a.setupState, minScore(), tp1Points()));
            signalCard.setBackgroundResource(R.drawable.bg_signal_wait); signalDirection.setTextColor(getColor(R.color.warn));
        }
        chart.setData(a.candles, a.entry, a.stop, a.tp1, a.tp2, a.actionable());
    }

    private void toggleLive() {
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        boolean running = p.getBoolean("gold_live_running", false);
        Intent i = new Intent(this, GoldMonitorService.class);
        if (running) {
            stopService(i);
            p.edit().putBoolean("gold_live_running", false).apply();
            Toast.makeText(this, "Live XAU monitor stopped", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            p.edit().putBoolean("gold_live_running", true).apply();
            Toast.makeText(this, "Live XAU monitor started", Toast.LENGTH_SHORT).show();
        }
        updateLiveButton();
    }

    private void updateLiveButton() {
        boolean running = getSharedPreferences("smw", MODE_PRIVATE).getBoolean("gold_live_running", false);
        liveButton.setText(running ? "Stop live monitor" : "Start live monitor");
        liveButton.setBackgroundResource(running ? R.drawable.bg_signal_buy : R.drawable.bg_button_secondary);
    }

    private void checkCrypto() {
        globalStatus.setText("Checking BTC traders and smart wallets…");
        findViewById(R.id.cryptoCheckButton).setEnabled(false);
        new Thread(() -> {
            CryptoEngine.runAll(getApplicationContext());
            runOnUiThread(() -> {
                refreshCrypto();
                globalStatus.setText("Crypto check completed");
                findViewById(R.id.cryptoCheckButton).setEnabled(true);
            });
        }).start();
    }

    private void refreshCrypto() {
        SharedPreferences p = getSharedPreferences("scw", MODE_PRIVATE);
        btcText.setText(p.getString("btc_display", "Tap Check crypto now to load trader positions."));
        tokenText.setText(p.getString("token_display", "Tap Check crypto now to scan smart wallets."));
    }

    private void refreshAlerts() { alertsText.setText(AlertStore.get(this)); }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }


    private void refreshLivePrice() {
        if (goldPrice == null || liveStatusText == null) return;
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        long t = p.getLong("live_tick_time", 0);
        double live = Double.longBitsToDouble(p.getLong("live_price_bits", Double.doubleToRawLongBits(0)));
        String state = p.getString("live_feed_state", "REST candle mode");
        long age = t > 0 ? Math.max(0, (System.currentTimeMillis() - t) / 1000L) : -1;
        boolean fresh = live > 0 && age >= 0 && age <= 90;
        if (fresh) goldPrice.setText(String.format(Locale.US, "$%,.2f", live));

        String suffix = "";
        if (fresh && p.getBoolean("gold_last_actionable", false)) {
            double lo = Double.longBitsToDouble(p.getLong("gold_last_entry_low", Double.doubleToRawLongBits(0)));
            double hi = Double.longBitsToDouble(p.getLong("gold_last_entry_high", Double.doubleToRawLongBits(0)));
            double min = Math.min(lo, hi), max = Math.max(lo, hi);
            if (min > 0 && max > 0) {
                if (live >= min && live <= max) suffix = " • ENTRY ZONE";
                else {
                    double distance = live < min ? min - live : live - max;
                    suffix = String.format(Locale.US, " • %.1f pts from zone", distance / pointSize());
                }
            }
        }

        liveStatusText.setText(fresh
                ? ("LIVE XAU/USD • " + age + "s • " + state + suffix)
                : ("PRICE STREAM • " + state));
    }
    private double prefDouble(String key, double d) { try { return Double.parseDouble(getSharedPreferences("smw", MODE_PRIVATE).getString(key, String.valueOf(d))); } catch (Exception e) { return d; } }
    private double pointSize() { return Math.max(0.0001, prefDouble("point_size", 1)); }
    private double tp1Points() { return prefDouble("tp1_points", 10); }
    private double tp2Points() { return prefDouble("tp2_points", 15); }
    private double minScore() { return prefDouble("min_score", 76); }
    private String price(double x) { return String.format(Locale.US, "%.2f", x); }
    private String clean(String s) { if (s == null) return "unknown error"; return s.length() > 150 ? s.substring(0, 150) + "…" : s; }
}
