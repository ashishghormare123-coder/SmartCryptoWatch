package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class CryptoEngine {
    private static final String[] HL_WALLETS = {
            "0x5e13d5cedbddd7237f659947ce64bec1294e2607",
            "0xb6dca3c627fd9fb0e865c4c8fb5c2584ac8237e5"
    };
    private static final String[] HL_NAMES = {"Primary", "Confirmation"};

    private static final String[] SOL_WALLETS = {
            "4Be9CvxqHW6BYiRAxW9Q3xu1ycTMWaL5z8NX4HR3ha7t",
            "6HJetMbdHBuk3mLUainxAPpBpWzDgYbHGTS2TqDAUSX2",
            "GKQgm9PkGd4UZCXTpHbndQLVUv1y7qcDjh9roQA7BSUn",
            "B32QbbdDAyhvUQzjcaM5j6ZVKwjCxAwGH5Xgvb9SJqnC"
    };
    private static final String[] SOL_NAMES = {"Mitch", "LJC", "GKQ", "Kadenox"};

    public static void runAll(Context context) {
        SharedPreferences p = context.getSharedPreferences("scw", Context.MODE_PRIVATE);
        StringBuilder btcDisplay = new StringBuilder();
        StringBuilder tokenDisplay = new StringBuilder();
        boolean btcOk = false;
        boolean solOk = false;
        try {
            checkHyperliquid(context, p, btcDisplay);
            btcOk = true;
        } catch (Exception e) {
            btcDisplay.append("BTC check error: ").append(clean(e.getMessage()));
        }
        try {
            checkSolana(context, p, tokenDisplay);
            solOk = true;
        } catch (Exception e) {
            tokenDisplay.append("Token check error: ").append(clean(e.getMessage()));
        }
        String time = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date());
        String status = "Last check: " + time + " • BTC " + (btcOk ? "OK" : "error") + " • Tokens " + (solOk ? "OK" : "error");
        p.edit().putString("last_status", status)
                .putString("btc_display", btcDisplay.length() == 0 ? "No BTC position found." : btcDisplay.toString())
                .putString("token_display", tokenDisplay.length() == 0 ? "No new qualifying token buys." : tokenDisplay.toString())
                .apply();
    }

    private static void checkHyperliquid(Context context, SharedPreferences p, StringBuilder out) throws Exception {
        JSONObject mids = postJson("https://api.hyperliquid.xyz/info", new JSONObject().put("type", "allMids"));
        double btcMid = parseDouble(mids.optString("BTC", "0"));
        List<Double> directions = new ArrayList<>();

        for (int i = 0; i < HL_WALLETS.length; i++) {
            JSONObject req = new JSONObject().put("type", "clearinghouseState").put("user", HL_WALLETS[i]);
            JSONObject state = postJson("https://api.hyperliquid.xyz/info", req);
            JSONArray positions = state.optJSONArray("assetPositions");
            JSONObject btcPos = null;
            if (positions != null) {
                for (int j = 0; j < positions.length(); j++) {
                    JSONObject wrap = positions.optJSONObject(j);
                    JSONObject pos = wrap == null ? null : wrap.optJSONObject("position");
                    if (pos != null && "BTC".equalsIgnoreCase(pos.optString("coin"))) {
                        btcPos = pos;
                        break;
                    }
                }
            }

            double newSize = btcPos == null ? 0.0 : parseDouble(btcPos.optString("szi", "0"));
            double oldSize = Double.longBitsToDouble(p.getLong("hl_size_" + i, Double.doubleToLongBits(0.0)));
            boolean initialized = p.getBoolean("hl_init_" + i, false);
            directions.add(Math.signum(newSize));

            String side = newSize > 0 ? "LONG" : newSize < 0 ? "SHORT" : "FLAT";
            String entry = btcPos == null ? "—" : btcPos.optString("entryPx", "—");
            String value = btcPos == null ? "—" : btcPos.optString("positionValue", "—");
            String liq = btcPos == null ? "—" : btcPos.optString("liquidationPx", "—");
            String lev = "—";
            if (btcPos != null) {
                JSONObject leverage = btcPos.optJSONObject("leverage");
                if (leverage != null) lev = leverage.optString("value", leverage.optString("type", "—"));
            }

            if (out.length() > 0) out.append("\n\n");
            out.append(HL_NAMES[i]).append(": ").append(side)
                    .append("\nSize: ").append(fmt(Math.abs(newSize))).append(" BTC")
                    .append("\nEntry: $").append(entry)
                    .append("\nNotional: $").append(value)
                    .append("\nLeverage: ").append(lev)
                    .append("\nLiquidation: $").append(liq);

            if (initialized) {
                String change = classifyPositionChange(oldSize, newSize);
                if (change != null && p.getBoolean("btc_notifications", true)) {
                    NotificationHelper.notify(context, "BTC trader alert • " + HL_NAMES[i], change + " • " + side + " • BTC $" + fmt(btcMid), 700 + i);
                }
            }
            p.edit().putLong("hl_size_" + i, Double.doubleToRawLongBits(newSize)).putBoolean("hl_init_" + i, true).apply();
        }
        if (directions.size() == 2) {
            boolean agree = directions.get(0) != 0 && directions.get(0).equals(directions.get(1));
            out.append("\n\nBTC mid: $").append(fmt(btcMid)).append("\nTrader agreement: ").append(agree ? "YES" : "NO");
        }
    }

    private static String classifyPositionChange(double oldSize, double newSize) {
        double eps = 1e-9;
        if (Math.abs(oldSize) < eps && Math.abs(newSize) >= eps) return "Opened BTC position";
        if (Math.abs(oldSize) >= eps && Math.abs(newSize) < eps) return "Closed BTC position";
        if (Math.signum(oldSize) != Math.signum(newSize) && Math.abs(oldSize) >= eps && Math.abs(newSize) >= eps) return "Flipped BTC direction";
        if (Math.signum(oldSize) == Math.signum(newSize) && Math.abs(newSize) > Math.abs(oldSize) * 1.01) return "Added to BTC position";
        if (Math.signum(oldSize) == Math.signum(newSize) && Math.abs(newSize) < Math.abs(oldSize) * 0.99) return "Reduced BTC position";
        return null;
    }

    private static void checkSolana(Context context, SharedPreferences p, StringBuilder out) throws Exception {
        String rpc = p.getString("rpc_url", "https://api.mainnet-beta.solana.com");
        int alertId = 900;
        for (int wi = 0; wi < SOL_WALLETS.length; wi++) {
            Map<String, Double> current = fetchTokenBalances(rpc, SOL_WALLETS[wi]);
            boolean initialized = p.getBoolean("sol_init_" + wi, false);
            int qualifying = 0;

            for (Map.Entry<String, Double> e : current.entrySet()) {
                String mint = e.getKey();
                double now = e.getValue();
                double prev = Double.longBitsToDouble(p.getLong("sol_bal_" + wi + "_" + mint, Double.doubleToLongBits(0.0)));
                boolean meaningfulIncrease = initialized && now > prev && (prev == 0.0 || now > prev * 1.02);
                if (meaningfulIncrease) {
                    TokenMetrics m = fetchDexMetrics(mint);
                    double delta = now - prev;
                    double approxBuyUsd = delta * m.priceUsd;
                    boolean passes = m.liquidityUsd >= 50000 && m.volume24h >= 20000 && m.marketCap >= 100000 && m.marketCap <= 20000000;
                    if (passes) {
                        double top10Pct = fetchTop10Pct(rpc, mint);
                        qualifying++;
                        if (out.length() > 0) out.append("\n\n");
                        out.append(SOL_NAMES[wi]).append(" bought ").append(m.symbol.isEmpty() ? "token" : m.symbol)
                                .append("\nContract: ").append(mint)
                                .append("\nApprox buy: $").append(fmt(approxBuyUsd))
                                .append("\nMarket cap: $").append(fmt(m.marketCap))
                                .append("\nLiquidity: $").append(fmt(m.liquidityUsd))
                                .append("\n24h volume: $").append(fmt(m.volume24h))
                                .append("\nTop-10 concentration: ").append(top10Pct < 0 ? "Unavailable" : fmt(top10Pct) + "%")
                                .append("\nRisk: verify contract/socials before trading");
                        if (p.getBoolean("token_notifications", true)) {
                            NotificationHelper.notify(context, "Early-token alert • " + SOL_NAMES[wi], (m.symbol.isEmpty() ? shortMint(mint) : m.symbol) + " • MC $" + fmt(m.marketCap) + " • Liq $" + fmt(m.liquidityUsd), alertId++);
                        }
                    }
                }
                p.edit().putLong("sol_bal_" + wi + "_" + mint, Double.doubleToRawLongBits(now)).apply();
            }
            p.edit().putBoolean("sol_init_" + wi, true).apply();
            if (initialized && qualifying == 0 && out.length() == 0) {
                out.append("No new qualifying smart-wallet buys detected.");
            }
        }
    }

    private static Map<String, Double> fetchTokenBalances(String rpc, String owner) throws Exception {
        JSONObject paramsConfig = new JSONObject().put("encoding", "jsonParsed");
        JSONArray params = new JSONArray().put(owner).put(new JSONObject().put("programId", "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")).put(paramsConfig);
        JSONObject req = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getTokenAccountsByOwner").put("params", params);
        JSONObject res = postJson(rpc, req);
        Map<String, Double> map = new HashMap<>();
        JSONObject result = res.optJSONObject("result");
        JSONArray value = result == null ? null : result.optJSONArray("value");
        if (value == null) return map;
        for (int i = 0; i < value.length(); i++) {
            JSONObject account = value.optJSONObject(i);
            JSONObject parsed = account == null ? null : account.optJSONObject("account");
            parsed = parsed == null ? null : parsed.optJSONObject("data");
            parsed = parsed == null ? null : parsed.optJSONObject("parsed");
            JSONObject info = parsed == null ? null : parsed.optJSONObject("info");
            if (info == null) continue;
            String mint = info.optString("mint", "");
            JSONObject tokenAmount = info.optJSONObject("tokenAmount");
            double uiAmount = tokenAmount == null ? 0.0 : tokenAmount.optDouble("uiAmount", 0.0);
            if (!mint.isEmpty() && uiAmount > 0) map.put(mint, map.getOrDefault(mint, 0.0) + uiAmount);
        }
        return map;
    }

    private static TokenMetrics fetchDexMetrics(String mint) throws Exception {
        JSONObject res = getJson("https://api.dexscreener.com/latest/dex/tokens/" + mint);
        JSONArray pairs = res.optJSONArray("pairs");
        TokenMetrics best = new TokenMetrics();
        if (pairs == null) return best;
        for (int i = 0; i < pairs.length(); i++) {
            JSONObject pair = pairs.optJSONObject(i);
            if (pair == null || !"solana".equalsIgnoreCase(pair.optString("chainId"))) continue;
            double liq = pair.optJSONObject("liquidity") == null ? 0 : pair.optJSONObject("liquidity").optDouble("usd", 0);
            if (liq >= best.liquidityUsd) {
                best.liquidityUsd = liq;
                best.volume24h = pair.optJSONObject("volume") == null ? 0 : pair.optJSONObject("volume").optDouble("h24", 0);
                best.marketCap = pair.optDouble("marketCap", pair.optDouble("fdv", 0));
                best.priceUsd = parseDouble(pair.optString("priceUsd", "0"));
                JSONObject base = pair.optJSONObject("baseToken");
                best.symbol = base == null ? "" : base.optString("symbol", "");
            }
        }
        return best;
    }

    private static double fetchTop10Pct(String rpc, String mint) {
        try {
            JSONObject supplyReq = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getTokenSupply").put("params", new JSONArray().put(mint));
            JSONObject supplyRes = postJson(rpc, supplyReq);
            JSONObject value = supplyRes.optJSONObject("result") == null ? null : supplyRes.optJSONObject("result").optJSONObject("value");
            double supply = value == null ? 0 : value.optDouble("uiAmount", 0);
            if (supply <= 0) return -1;
            JSONObject largestReq = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getTokenLargestAccounts").put("params", new JSONArray().put(mint));
            JSONObject largestRes = postJson(rpc, largestReq);
            JSONArray vals = largestRes.optJSONObject("result") == null ? null : largestRes.optJSONObject("result").optJSONArray("value");
            if (vals == null) return -1;
            double sum = 0;
            for (int i = 0; i < Math.min(10, vals.length()); i++) sum += vals.optJSONObject(i).optDouble("uiAmount", 0);
            return 100.0 * sum / supply;
        } catch (Exception ignored) {
            return -1;
        }
    }

    private static JSONObject postJson(String endpoint, JSONObject body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("User-Agent", "SmartCryptoWatch/1.0");
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        return new JSONObject(readResponse(c));
    }

    private static JSONObject getJson(String endpoint) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent", "SmartCryptoWatch/1.0");
        return new JSONObject(readResponse(c));
    }

    private static String readResponse(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        if (is == null) throw new Exception("HTTP " + code);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + sb);
        return sb.toString();
    }

    private static double parseDouble(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0.0; }
    }

    private static String fmt(double v) {
        if (Math.abs(v) >= 1000000) return String.format(Locale.US, "%.2fM", v / 1000000.0);
        if (Math.abs(v) >= 1000) return String.format(Locale.US, "%.2fK", v / 1000.0);
        if (Math.abs(v) >= 1) return String.format(Locale.US, "%.2f", v);
        return String.format(Locale.US, "%.6f", v);
    }

    private static String shortMint(String mint) {
        return mint.length() <= 10 ? mint : mint.substring(0, 5) + "…" + mint.substring(mint.length() - 4);
    }

    private static String clean(String s) {
        if (s == null || s.isEmpty()) return "unknown error";
        return s.length() > 180 ? s.substring(0, 180) : s;
    }

    private static class TokenMetrics {
        String symbol = "";
        double priceUsd = 0;
        double marketCap = 0;
        double liquidityUsd = 0;
        double volume24h = 0;
    }
}
