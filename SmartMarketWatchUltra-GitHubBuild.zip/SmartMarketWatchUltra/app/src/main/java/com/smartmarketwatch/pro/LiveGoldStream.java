package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/** Live XAU/USD price stream. Analysis still uses completed 5-minute OHLC candles. */
public final class LiveGoldStream {
    private final Context context;
    private final SharedPreferences prefs;
    private final OkHttpClient client;
    private WebSocket socket;

    public LiveGoldStream(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences("smw", Context.MODE_PRIVATE);
        this.client = new OkHttpClient.Builder()
                .pingInterval(15, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
    }

    public boolean start() {
        String key = prefs.getString("twelve_key", "").trim();
        if (key.isEmpty()) {
            prefs.edit().putString("live_feed_state", "REST fallback • API key required for streaming").apply();
            return false;
        }
        stop();
        String url = "wss://ws.twelvedata.com/v1/quotes/price?apikey=" + key;
        Request request = new Request.Builder().url(url).build();
        socket = client.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                prefs.edit().putString("live_feed_state", "LIVE WebSocket connected").apply();
                webSocket.send("{\"action\":\"subscribe\",\"params\":{\"symbols\":\"XAU/USD\"}}");
            }

            @Override public void onMessage(WebSocket webSocket, String text) {
                try {
                    JSONObject o = new JSONObject(text);
                    if ("price".equalsIgnoreCase(o.optString("event")) || o.has("price")) {
                        double price = o.optDouble("price", 0);
                        long ts = o.optLong("timestamp", 0);
                        if (price > 0) {
                            long time = ts > 10_000_000_000L ? ts : ts * 1000L;
                            if (time <= 0) time = System.currentTimeMillis();
                            prefs.edit()
                                    .putLong("live_price_bits", Double.doubleToRawLongBits(price))
                                    .putLong("live_tick_time", time)
                                    .putString("live_feed_state", "LIVE WebSocket")
                                    .apply();
                        }
                    } else if ("subscribe-status".equalsIgnoreCase(o.optString("event"))) {
                        String status = o.optString("status", "");
                        String message = o.optString("message", "");
                        prefs.edit().putString("live_feed_state", "WebSocket " + status + (message.isEmpty() ? "" : " • " + message)).apply();
                    }
                } catch (Exception ignored) { }
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                String msg = t == null ? "stream error" : t.getMessage();
                if (msg == null) msg = "stream error";
                prefs.edit().putString("live_feed_state", "WebSocket offline • " + trim(msg)).apply();
            }

            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                prefs.edit().putString("live_feed_state", "WebSocket closed").apply();
            }
        });
        return true;
    }

    public void stop() {
        if (socket != null) {
            try { socket.close(1000, "stop"); } catch (Exception ignored) { }
            socket = null;
        }
    }

    private String trim(String s) { return s.length() > 90 ? s.substring(0, 90) + "…" : s; }
}
