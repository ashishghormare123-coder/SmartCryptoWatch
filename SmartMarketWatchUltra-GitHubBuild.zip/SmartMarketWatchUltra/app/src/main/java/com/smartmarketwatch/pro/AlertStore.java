package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.DateFormat;
import java.util.Date;

public final class AlertStore {
    private AlertStore() {}

    public static synchronized void add(Context context, String title, String body) {
        SharedPreferences p = context.getSharedPreferences("smw", Context.MODE_PRIVATE);
        String old = p.getString("alert_history", "");
        String now = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date());
        String item = now + "\n" + title + "\n" + body.trim();
        String combined = old.isEmpty() ? item : item + "\n\n────────────\n\n" + old;
        if (combined.length() > 12000) combined = combined.substring(0, 12000);
        p.edit().putString("alert_history", combined).apply();
    }

    public static String get(Context context) {
        return context.getSharedPreferences("smw", Context.MODE_PRIVATE).getString("alert_history", "No alerts yet.");
    }

    public static void clear(Context context) {
        context.getSharedPreferences("smw", Context.MODE_PRIVATE).edit().remove("alert_history").apply();
    }
}
