package com.smartmarketwatch.pro;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private EditText apiKey, minScore, pointSize, tp1, tp2, minRr;
    private CheckBox sessionOnly, goldAlerts, cryptoAlerts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        apiKey = findViewById(R.id.apiKeyInput);
        minScore = findViewById(R.id.minScoreInput);
        pointSize = findViewById(R.id.pointSizeInput);
        tp1 = findViewById(R.id.tp1Input);
        tp2 = findViewById(R.id.tp2Input);
        minRr = findViewById(R.id.minRrInput);
        sessionOnly = findViewById(R.id.sessionOnlyCheck);
        goldAlerts = findViewById(R.id.goldAlertsCheck);
        cryptoAlerts = findViewById(R.id.cryptoAlertsCheck);
        Button save = findViewById(R.id.saveSettingsButton);
        Button back = findViewById(R.id.backButton);

        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        apiKey.setText(p.getString("twelve_key", ""));
        minScore.setText(p.getString("min_score", "78"));
        pointSize.setText(p.getString("point_size", "1.0"));
        tp1.setText(p.getString("tp1_points", "10"));
        tp2.setText(p.getString("tp2_points", "15"));
        minRr.setText(p.getString("min_rr", "1.25"));
        sessionOnly.setChecked(p.getBoolean("session_only", false));
        goldAlerts.setChecked(p.getBoolean("gold_alerts", true));

        SharedPreferences cp = getSharedPreferences("scw", MODE_PRIVATE);
        cryptoAlerts.setChecked(cp.getBoolean("btc_notifications", true) && cp.getBoolean("token_notifications", true));

        save.setOnClickListener(v -> save());
        back.setOnClickListener(v -> finish());
    }

    private void save() {
        double score = number(minScore.getText().toString(), 78);
        double ps = number(pointSize.getText().toString(), 1);
        double t1 = number(tp1.getText().toString(), 10);
        double t2 = number(tp2.getText().toString(), 15);
        double rr = number(minRr.getText().toString(), 1.25);

        if (score < 55 || score > 95) {
            Toast.makeText(this, "Use a confidence threshold between 55 and 95", Toast.LENGTH_LONG).show();
            return;
        }
        if (ps <= 0 || t1 <= 0 || t2 < t1) {
            Toast.makeText(this, "Check point size and targets", Toast.LENGTH_LONG).show();
            return;
        }
        if (rr < 0.7 || rr > 5.0) {
            Toast.makeText(this, "Use a minimum R:R between 0.7 and 5.0", Toast.LENGTH_LONG).show();
            return;
        }

        getSharedPreferences("smw", MODE_PRIVATE).edit()
                .putString("twelve_key", apiKey.getText().toString().trim())
                .putString("min_score", cleanNum(score))
                .putString("point_size", cleanNum(ps))
                .putString("tp1_points", cleanNum(t1))
                .putString("tp2_points", cleanNum(t2))
                .putString("min_rr", cleanNum(rr))
                .putBoolean("session_only", sessionOnly.isChecked())
                .putBoolean("gold_alerts", goldAlerts.isChecked())
                .putString("live_feed_state", "reconnect requested")
                .apply();

        getSharedPreferences("scw", MODE_PRIVATE).edit()
                .putBoolean("btc_notifications", cryptoAlerts.isChecked())
                .putBoolean("token_notifications", cryptoAlerts.isChecked())
                .apply();

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private double number(String s, double d) {
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return d; }
    }

    private String cleanNum(double x) {
        return x == Math.rint(x) ? String.valueOf((long) x) : String.valueOf(x);
    }
}
