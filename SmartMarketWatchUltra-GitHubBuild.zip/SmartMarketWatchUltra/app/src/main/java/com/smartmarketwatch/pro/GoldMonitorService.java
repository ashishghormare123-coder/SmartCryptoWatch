package com.smartmarketwatch.pro;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Foreground XAU/USD monitor.
 *
 * Structure is recalculated from completed 5-minute candles. A separate fast loop
 * watches the streaming price for an entry-zone touch so alerts are not tied to
 * a 45-second polling interval.
 */
public class GoldMonitorService extends Service {
    public static final int LIVE_NOTIFICATION_ID = 21001;
    private ScheduledExecutorService scheduler;
    private LiveGoldStream liveStream;
    private volatile GoldEngine.Analysis latestAnalysis;
    private volatile long lastStructureBucket = -1;
    private volatile boolean firstStructureScan = true;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannels(this);
        startForeground(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, "Starting XAU/USD live engine…"));
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        p.edit().putBoolean("gold_live_running", true).apply();

        liveStream = new LiveGoldStream(this);
        liveStream.start();

        scheduler = Executors.newScheduledThreadPool(2);
        scheduler.scheduleWithFixedDelay(this::runStructureScan, 0, 15, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(this::runEntryWatcher, 2, 2, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(this::ensureStream, 90, 90, TimeUnit.SECONDS);
    }

    private void runStructureScan() {
        try {
            long now = System.currentTimeMillis();
            long bucket = now / (5 * 60_000L);
            long intoBucket = now % (5 * 60_000L);
            if (!firstStructureScan) {
                if (bucket == lastStructureBucket) return;
                // Wait a few seconds after the 5-minute boundary so the provider has
                // finalized the just-closed candle before requesting it.
                if (intoBucket < 12_000L) return;
            }
            firstStructureScan = false;
            lastStructureBucket = bucket;

            GoldEngine.Analysis a = GoldEngine.analyze(getApplicationContext());
            latestAnalysis = a;
            SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
            double live = currentLivePrice(p, a.price);

            String status = a.actionable()
                    ? String.format(Locale.US, "READY %s %d%% • XAU %.2f • zone %.2f–%.2f", a.direction, a.score, live, a.entryLow, a.entryHigh)
                    : String.format(Locale.US, "%s %d%% • XAU %.2f • %s", a.setupState, a.score, live, a.regime);

            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, status));

            if (a.actionable() && p.getBoolean("gold_alerts", true)) {
                String fingerprint = "READY|" + a.direction + "|" + a.signalCandleTime;
                String last = p.getString("gold_last_ready_fingerprint", "");
                if (!fingerprint.equals(last)) {
                    String body = String.format(Locale.US,
                            "%s • %d/100 • %s • MTF %s\nEntry zone %.2f–%.2f • SL %.2f • TP1 %.2f • TP2 %.2f • R:R %.2f\n%s",
                            a.direction, a.score, a.session, a.mtfAlignment,
                            a.entryLow, a.entryHigh, a.stop, a.tp1, a.tp2, a.rr, a.reason);
                    NotificationHelper.notify(this, "XAU/USD setup READY", body, notificationId("ready", a.signalCandleTime));
                    AlertStore.add(this, "XAU/USD READY " + a.direction + " • " + a.score + "/100", body);
                    p.edit().putString("gold_last_ready_fingerprint", fingerprint).apply();
                }
            }

            p.edit().putString("gold_live_status", status).apply();
        } catch (Exception e) {
            String msg = "Feed check failed: " + clean(e.getMessage());
            getSharedPreferences("smw", MODE_PRIVATE).edit().putString("gold_live_status", msg).apply();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, msg));
        }
    }

    private void runEntryWatcher() {
        try {
            GoldEngine.Analysis a = latestAnalysis;
            if (a == null || !a.actionable()) return;
            // Scalp setups are intentionally short-lived. Do not alert on a stale
            // entry zone long after the candle that created the setup.
            if (System.currentTimeMillis() - a.signalCandleTime > 12 * 60_000L) return;

            SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
            if (!p.getBoolean("gold_alerts", true)) return;

            long tickTime = p.getLong("live_tick_time", 0);
            if (tickTime <= 0 || System.currentTimeMillis() - tickTime > 30_000L) return;
            double live = Double.longBitsToDouble(p.getLong("live_price_bits", Double.doubleToRawLongBits(0)));
            if (live <= 0) return;

            double lo = Math.min(a.entryLow, a.entryHigh);
            double hi = Math.max(a.entryLow, a.entryHigh);

            // If price has already travelled through TP1 before a first entry-zone touch,
            // do not issue a late chase alert.
            boolean alreadyExtended = "LONG".equals(a.direction) ? live >= a.tp1 : live <= a.tp1;
            boolean alreadyInvalid = "LONG".equals(a.direction) ? live <= a.stop : live >= a.stop;
            if (alreadyExtended || alreadyInvalid) return;

            if (live >= lo && live <= hi) {
                String fingerprint = "ENTRY|" + a.direction + "|" + a.signalCandleTime;
                String last = p.getString("gold_last_entry_fingerprint", "");
                if (!fingerprint.equals(last)) {
                    String body = String.format(Locale.US,
                            "Live XAU/USD %.2f is inside the %.2f–%.2f entry zone.\n%s %d/100 • SL %.2f • TP1 %.2f • TP2 %.2f • R:R %.2f",
                            live, lo, hi, a.direction, a.score, a.stop, a.tp1, a.tp2, a.rr);
                    NotificationHelper.notify(this, "XAU/USD ENTRY ZONE HIT", body, notificationId("entry", a.signalCandleTime));
                    AlertStore.add(this, "XAU/USD ENTRY " + a.direction + " • " + String.format(Locale.US, "%.2f", live), body);
                    p.edit().putString("gold_last_entry_fingerprint", fingerprint).apply();
                }
            }
        } catch (Exception ignored) { }
    }

    private void ensureStream() {
        try {
            SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
            String key = p.getString("twelve_key", "").trim();
            if (key.isEmpty()) return;
            long tick = p.getLong("live_tick_time", 0);
            String state = p.getString("live_feed_state", "");
            boolean stale = tick <= 0 || System.currentTimeMillis() - tick > 180_000L;
            boolean broken = state.contains("offline") || state.contains("closed") || state.contains("failure") || state.contains("required") || state.contains("reconnect");
            if (stale && broken && liveStream != null) liveStream.start();
        } catch (Exception ignored) { }
    }

    private double currentLivePrice(SharedPreferences p, double fallback) {
        long tick = p.getLong("live_tick_time", 0);
        double live = Double.longBitsToDouble(p.getLong("live_price_bits", Double.doubleToRawLongBits(0)));
        if (live > 0 && tick > 0 && System.currentTimeMillis() - tick <= 90_000L) return live;
        return fallback;
    }

    private int notificationId(String tag, long candleTime) {
        long x = candleTime ^ tag.hashCode();
        return (int) (x & 0x7fffffff);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        if (liveStream != null) liveStream.stop();
        getSharedPreferences("smw", MODE_PRIVATE).edit().putBoolean("gold_live_running", false).apply();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private String clean(String s) {
        if (s == null) return "unknown error";
        return s.length() > 120 ? s.substring(0, 120) + "…" : s;
    }
}
