package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public final class GoldEngine {
    private GoldEngine() {}

    public static class Candle {
        public long time;
        public double open, high, low, close, volume;
        Candle(long time, double open, double high, double low, double close, double volume) {
            this.time = time; this.open = open; this.high = high; this.low = low; this.close = close; this.volume = volume;
        }
    }

    public static class Analysis {
        public String feed = "";
        public String feedQuality = "";
        public String direction = "WAIT";
        public String setupState = "WAIT";
        public String bias = "NEUTRAL";
        public String trendVote = "WAIT";
        public String sweepVote = "WAIT";
        public String breakoutVote = "WAIT";
        public String session = "Off-session";
        public String reason = "";
        public String regime = "UNKNOWN";
        public String mtfAlignment = "MIXED";
        public int score = 0;
        public int agreement = 0;
        public double price = 0;
        public double entry = 0;
        public double entryLow = 0;
        public double entryHigh = 0;
        public double stop = 0;
        public double tp1 = 0;
        public double tp2 = 0;
        public double rr = 0;
        public double ema9 = 0, ema21 = 0, ema50 = 0, ema200 = 0, rsi = 0, atr = 0, adx = 0;
        public double expectedMove = 0;
        public long signalCandleTime = 0;
        public long analyzedAt = 0;
        public List<Candle> candles = new ArrayList<>();
        public BacktestStats backtest = new BacktestStats();
        public boolean actionable() { return "LONG".equals(direction) || "SHORT".equals(direction); }
    }

    public static class BacktestStats {
        public int signals, tp1First, tp2First, stopFirst, unresolved, sampleBars;
        public double avgMfePoints, avgMaePoints;
        public String display() {
            if (signals == 0) return "No qualifying READY signals in the recent sample.";
            double p1 = 100.0 * tp1First / signals;
            double p2 = 100.0 * tp2First / signals;
            double sl = 100.0 * stopFirst / signals;
            return String.format(Locale.US,
                    "READY signals: %d  •  TP1 before SL: %.1f%%  •  TP2 before SL: %.1f%%\nStop first: %.1f%%  •  Avg MFE: %.1f pts  •  Avg MAE: %.1f pts\nSample: %d completed 5-minute bars",
                    signals, p1, p2, sl, avgMfePoints, avgMaePoints, sampleBars);
        }
    }

    private static class Indicators {
        double[] ema9, ema21, ema50, ema200, rsi, atr, adx;
    }

    private static class SignalEval {
        int trendVote, sweepVote, breakoutVote, direction, score, agreement;
        double entry, entryLow, entryHigh, stop, tp1, tp2, rr, expectedMove;
        String bias, session, reason, regime, mtfAlignment, setupState;
        boolean actionable;
    }

    private static class Settings {
        double minScore, pointSize, tp1Pts, tp2Pts, minRr;
        boolean sessionOnly;
        static Settings from(SharedPreferences p) {
            Settings s = new Settings();
            s.minScore = getDouble(p, "min_score", 76);
            s.pointSize = Math.max(0.0001, getDouble(p, "point_size", 1.0));
            s.tp1Pts = Math.max(1, getDouble(p, "tp1_points", 10));
            s.tp2Pts = Math.max(s.tp1Pts, getDouble(p, "tp2_points", 15));
            s.minRr = Math.max(0.7, getDouble(p, "min_rr", 1.25));
            s.sessionOnly = p.getBoolean("session_only", false);
            return s;
        }
    }

    private static class DataPack {
        String feed, quality;
        boolean tradeGrade;
        List<Candle> candles = new ArrayList<>();
    }

    /** Conservative XAU/USD trading-session gate used to avoid weekend/rollover pseudo-quotes. */
    public static boolean isMarketOpenNow() { return isMarketTimestamp(System.currentTimeMillis()); }

    public static String marketStateNow() {
        if (isMarketOpenNow()) return "OPEN";
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int day = c.get(Calendar.DAY_OF_WEEK);
        if (day == Calendar.SATURDAY || day == Calendar.SUNDAY) return "WEEKEND CLOSED";
        return "DAILY ROLLOVER / CLOSED";
    }

    private static boolean isMarketTimestamp(long millis) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTimeInMillis(millis);
        int day = c.get(Calendar.DAY_OF_WEEK);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        if (day == Calendar.SATURDAY) return false;
        // Conservative global spot-metals weekend window. Providers/brokers can vary slightly.
        if (day == Calendar.SUNDAY && hour < 22) return false;
        if (day == Calendar.FRIDAY && hour >= 21) return false;
        // Avoid the common daily metals rollover/maintenance window.
        if (day >= Calendar.MONDAY && day <= Calendar.THURSDAY && hour >= 21 && hour < 22) return false;
        return true;
    }

    public static Analysis analyze(Context context) throws Exception {
        SharedPreferences p = context.getSharedPreferences("smw", Context.MODE_PRIVATE);
        String key = p.getString("twelve_key", "").trim();
        DataPack data;
        if (!key.isEmpty()) {
            try { data = fetchTwelve(key); }
            catch (Exception e) {
                data = fetchYahoo();
                data.quality = "FALLBACK • not broker-identical";
                data.feed += " • Twelve Data unavailable";
            }
        } else {
            data = fetchYahoo();
            data.quality = "FALLBACK • add Twelve Data key for live spot feed";
        }

        if (data.candles.size() < 260) throw new Exception("Not enough completed 5-minute XAUUSD candles returned by data feed");

        int i = lastClosedIndex(data.candles, System.currentTimeMillis());
        if (i < 220) throw new Exception("Not enough completed candles for multi-timeframe analysis");
        List<Candle> closed = new ArrayList<>(data.candles.subList(0, i + 1));
        Indicators ind = indicators(closed);
        Settings s = Settings.from(p);
        SignalEval ev = evaluate(closed, ind, closed.size() - 1, s);

        Analysis a = new Analysis();
        a.feed = data.feed;
        a.feedQuality = data.quality;
        a.candles = new ArrayList<>(closed.subList(Math.max(0, closed.size() - 100), closed.size()));
        Candle last = closed.get(closed.size() - 1);
        a.price = last.close;
        long now = System.currentTimeMillis();
        boolean marketOpen = isMarketOpenNow();
        boolean staleWhileOpen = marketOpen && now - last.time > 20 * 60_000L;
        if (!data.tradeGrade) {
            ev.actionable = false;
            ev.setupState = "REFERENCE";
            ev.reason = "Trade alerts are disabled on the fallback/proxy feed. Add a Twelve Data key for exact XAU/USD spot analysis. " + ev.reason;
        } else if (!marketOpen) {
            ev.actionable = false;
            ev.setupState = "MARKET CLOSED";
            ev.session = marketStateNow();
            ev.reason = "XAU/USD is outside the conservative global spot-metals trading window. The app is showing the latest valid completed candle but will not create scalp alerts until the market reopens.";
        } else if (staleWhileOpen) {
            ev.actionable = false;
            ev.setupState = "STALE DATA";
            ev.reason = "The newest completed 5-minute XAU/USD candle is too old for a scalp decision. No trade alert is allowed until fresh data resumes.";
        }
        a.direction = ev.actionable ? (ev.direction > 0 ? "LONG" : "SHORT") : "WAIT";
        a.setupState = ev.setupState;
        a.bias = ev.bias;
        a.trendVote = voteName(ev.trendVote);
        a.sweepVote = voteName(ev.sweepVote);
        a.breakoutVote = voteName(ev.breakoutVote);
        a.session = ev.session;
        a.reason = ev.reason;
        a.regime = ev.regime;
        a.mtfAlignment = ev.mtfAlignment;
        a.score = ev.score;
        a.agreement = ev.agreement;
        a.entry = ev.entry; a.entryLow = ev.entryLow; a.entryHigh = ev.entryHigh;
        a.stop = ev.stop; a.tp1 = ev.tp1; a.tp2 = ev.tp2; a.rr = ev.rr; a.expectedMove = ev.expectedMove;
        int z = closed.size() - 1;
        a.ema9 = ind.ema9[z]; a.ema21 = ind.ema21[z]; a.ema50 = ind.ema50[z]; a.ema200 = ind.ema200[z];
        a.rsi = ind.rsi[z]; a.atr = ind.atr[z]; a.adx = ind.adx[z];
        a.signalCandleTime = last.time;
        a.backtest = backtest(closed, ind, s);
        a.analyzedAt = System.currentTimeMillis();

        p.edit()
                .putString("gold_last_feed", a.feed)
                .putString("gold_last_dir", a.direction)
                .putString("gold_last_state", a.setupState)
                .putInt("gold_last_score", a.score)
                .putLong("gold_last_time", a.analyzedAt)
                .putLong("gold_last_price", Double.doubleToRawLongBits(a.price))
                .putLong("gold_last_candle_time", a.signalCandleTime)
                .putBoolean("gold_last_actionable", a.actionable())
                .putLong("gold_last_entry_low", Double.doubleToRawLongBits(a.entryLow))
                .putLong("gold_last_entry_high", Double.doubleToRawLongBits(a.entryHigh))
                .putLong("gold_last_stop", Double.doubleToRawLongBits(a.stop))
                .putLong("gold_last_tp1", Double.doubleToRawLongBits(a.tp1))
                .putLong("gold_last_tp2", Double.doubleToRawLongBits(a.tp2))
                .apply();
        return a;
    }

    private static int lastClosedIndex(List<Candle> c, long now) {
        int i = c.size() - 1;
        // A five-minute candle is considered closed only after its full 5m window plus a small grace period.
        while (i > 0 && c.get(i).time + 5 * 60_000L + 12_000L > now) i--;
        return i;
    }

    private static SignalEval evaluate(List<Candle> c, Indicators in, int i, Settings s) {
        SignalEval e = new SignalEval();
        e.setupState = "WAIT";
        if (i < 220) { e.bias = "NEUTRAL"; e.session = "Warm-up"; return e; }
        Candle x = c.get(i);
        double atr = Math.max(in.atr[i], 0.01);
        double rsi = in.rsi[i];
        double adx = in.adx[i];

        boolean trendUp = in.ema9[i] > in.ema21[i] && in.ema21[i] > in.ema50[i] && in.ema21[i] > in.ema21[i - 3];
        boolean trendDn = in.ema9[i] < in.ema21[i] && in.ema21[i] < in.ema50[i] && in.ema21[i] < in.ema21[i - 3];
        boolean htfUp = in.ema50[i] > in.ema200[i];
        boolean htfDn = in.ema50[i] < in.ema200[i];
        e.bias = (trendUp && htfUp) ? "BULLISH" : (trendDn && htfDn) ? "BEARISH" : htfUp ? "BULLISH-MIXED" : htfDn ? "BEARISH-MIXED" : "NEUTRAL";

        int mtf15 = higherTimeframeBias(c, i, 15);
        int mtf60 = higherTimeframeBias(c, i, 60);
        if (mtf15 > 0 && mtf60 > 0) e.mtfAlignment = "BULLISH";
        else if (mtf15 < 0 && mtf60 < 0) e.mtfAlignment = "BEARISH";
        else e.mtfAlignment = "MIXED";

        double emaSep = Math.abs(in.ema9[i] - in.ema21[i]) / atr;
        if (adx >= 24 && emaSep >= 0.18) e.regime = "TRENDING";
        else if (adx <= 18 && emaSep < 0.15) e.regime = "RANGING";
        else e.regime = "TRANSITION";

        // Model 1 — trend continuation after a controlled pullback.
        boolean touched21 = x.low <= in.ema21[i] + atr * 0.22 && x.high >= in.ema21[i] - atr * 0.22;
        boolean notExtendedLong = x.close - in.ema21[i] <= atr * 0.85;
        boolean notExtendedShort = in.ema21[i] - x.close <= atr * 0.85;
        if (trendUp && htfUp && x.close >= in.ema21[i] && rsi >= 50 && rsi <= 69 && notExtendedLong && (touched21 || x.low <= in.ema9[i])) e.trendVote = 1;
        else if (trendDn && htfDn && x.close <= in.ema21[i] && rsi <= 50 && rsi >= 31 && notExtendedShort && (touched21 || x.high >= in.ema9[i])) e.trendVote = -1;

        // Model 2 — sweep of recent liquidity followed by a reclaim/rejection close.
        double prevMin = Double.MAX_VALUE, prevMax = -Double.MAX_VALUE;
        for (int k = i - 16; k < i; k++) { prevMin = Math.min(prevMin, c.get(k).low); prevMax = Math.max(prevMax, c.get(k).high); }
        double body = Math.max(Math.abs(x.close - x.open), 0.0001);
        double range = Math.max(x.high - x.low, 0.0001);
        double lowerWick = Math.min(x.open, x.close) - x.low;
        double upperWick = x.high - Math.max(x.open, x.close);
        if (x.low < prevMin - atr * 0.04 && x.close > prevMin && lowerWick >= body * 1.15 && x.close >= x.low + range * 0.58) e.sweepVote = 1;
        else if (x.high > prevMax + atr * 0.04 && x.close < prevMax && upperWick >= body * 1.15 && x.close <= x.low + range * 0.42) e.sweepVote = -1;

        // Model 3 — breakout/continuation: close through 20-bar structure with enough body quality.
        double high20 = -Double.MAX_VALUE, low20 = Double.MAX_VALUE;
        for (int k = i - 20; k < i; k++) { high20 = Math.max(high20, c.get(k).high); low20 = Math.min(low20, c.get(k).low); }
        double bodyPct = body / range;
        if (x.close > high20 + atr * 0.04 && bodyPct >= 0.58 && rsi >= 55 && rsi <= 75 && adx >= 19) e.breakoutVote = 1;
        else if (x.close < low20 - atr * 0.04 && bodyPct >= 0.58 && rsi <= 45 && rsi >= 25 && adx >= 19) e.breakoutVote = -1;

        int longVotes = (e.trendVote > 0 ? 1 : 0) + (e.sweepVote > 0 ? 1 : 0) + (e.breakoutVote > 0 ? 1 : 0);
        int shortVotes = (e.trendVote < 0 ? 1 : 0) + (e.sweepVote < 0 ? 1 : 0) + (e.breakoutVote < 0 ? 1 : 0);
        e.direction = longVotes > shortVotes ? 1 : shortVotes > longVotes ? -1 : 0;
        e.agreement = Math.max(longVotes, shortVotes);

        int utcHour = utcHour(x.time);
        if (utcHour >= 12 && utcHour < 16) e.session = "London/NY overlap";
        else if (utcHour >= 7 && utcHour < 12) e.session = "London";
        else if (utcHour >= 16 && utcHour < 21) e.session = "New York";
        else e.session = "Off-session";

        int score = 8;
        if (e.agreement == 2) score += 38;
        else if (e.agreement == 3) score += 54;
        if (e.direction > 0 && trendUp) score += 7;
        if (e.direction < 0 && trendDn) score += 7;
        if (e.direction > 0 && htfUp) score += 5;
        if (e.direction < 0 && htfDn) score += 5;
        if (e.direction > 0 && "BULLISH".equals(e.mtfAlignment)) score += 10;
        if (e.direction < 0 && "BEARISH".equals(e.mtfAlignment)) score += 10;
        if ("London/NY overlap".equals(e.session)) score += 7;
        else if (!"Off-session".equals(e.session)) score += 4;
        if (adx >= 22 && e.trendVote == e.direction) score += 5;
        if ((e.direction > 0 && rsi >= 52 && rsi <= 66) || (e.direction < 0 && rsi <= 48 && rsi >= 34)) score += 4;
        if ("RANGING".equals(e.regime) && e.breakoutVote == e.direction) score -= 8;
        if ("MIXED".equals(e.mtfAlignment)) score -= 5;
        e.score = Math.max(0, Math.min(99, score));

        e.entry = x.close;
        e.entryLow = e.direction > 0 ? x.close - atr * 0.10 : x.close - atr * 0.04;
        e.entryHigh = e.direction > 0 ? x.close + atr * 0.04 : x.close + atr * 0.10;
        double recentSwingLow = Double.MAX_VALUE, recentSwingHigh = -Double.MAX_VALUE;
        for (int k = Math.max(0, i - 8); k <= i; k++) { recentSwingLow = Math.min(recentSwingLow, c.get(k).low); recentSwingHigh = Math.max(recentSwingHigh, c.get(k).high); }
        double tp1Dist = s.tp1Pts * s.pointSize, tp2Dist = s.tp2Pts * s.pointSize;
        double minStop = Math.max(atr * 0.48, 2.5 * s.pointSize);
        double maxStop = Math.max(atr * 1.25, 8.0 * s.pointSize);
        if (e.direction > 0) {
            double structural = Math.max(0.01, e.entry - (recentSwingLow - atr * 0.06));
            double stopDist = clamp(structural, minStop, maxStop);
            e.stop = e.entry - stopDist; e.tp1 = e.entry + tp1Dist; e.tp2 = e.entry + tp2Dist;
        } else if (e.direction < 0) {
            double structural = Math.max(0.01, (recentSwingHigh + atr * 0.06) - e.entry);
            double stopDist = clamp(structural, minStop, maxStop);
            e.stop = e.entry + stopDist; e.tp1 = e.entry - tp1Dist; e.tp2 = e.entry - tp2Dist;
        }
        e.expectedMove = Math.max(atr * 1.25, atr + Math.abs(in.ema9[i] - in.ema21[i]) * 1.8);
        double risk = Math.abs(e.entry - e.stop);
        e.rr = risk > 0 ? tp2Dist / risk : 0;

        boolean mtfNotOpposed = e.direction > 0 ? !"BEARISH".equals(e.mtfAlignment) : e.direction < 0 && !"BULLISH".equals(e.mtfAlignment);
        boolean sessionPass = !s.sessionOnly || !"Off-session".equals(e.session);
        boolean capacity = e.expectedMove >= tp1Dist;
        boolean rrPass = e.rr >= s.minRr;
        boolean scorePass = e.score >= s.minScore;
        boolean votesPass = e.agreement >= 2;
        boolean regimePass = !("RANGING".equals(e.regime) && e.sweepVote == 0);

        e.actionable = e.direction != 0 && votesPass && scorePass && capacity && rrPass && mtfNotOpposed && sessionPass && regimePass;
        if (e.actionable) e.setupState = "READY";
        else if (e.direction != 0 && e.agreement >= 2 && e.score >= s.minScore - 10) e.setupState = "WATCH";
        else e.setupState = "WAIT";

        StringBuilder reason = new StringBuilder();
        if (e.direction == 0) reason.append("No clean directional agreement. ");
        if (!votesPass) reason.append("Need 2/3 model agreement. ");
        if (!scorePass) reason.append("Confidence below threshold. ");
        if (!capacity) reason.append("ATR/structure does not support the minimum target. ");
        if (!rrPass && e.direction != 0) reason.append("R:R below minimum. ");
        if (!mtfNotOpposed && e.direction != 0) reason.append("15m/1h trend is opposing the 5m setup. ");
        if (!sessionPass) reason.append("Outside selected trading sessions. ");
        if (!regimePass) reason.append("Range regime blocks low-quality breakout trades. ");
        if (reason.length() == 0) reason.append("Closed-candle trigger, 2/3 model agreement, multi-timeframe, volatility and R:R gates passed.");
        e.reason = reason.toString().trim();
        return e;
    }

    private static int higherTimeframeBias(List<Candle> five, int throughIndex, int minutes) {
        List<Candle> h = aggregate(five.subList(0, throughIndex + 1), minutes);
        if (h.size() < 55) return 0;
        Indicators in = indicators(h);
        int i = h.size() - 1;
        boolean up = in.ema9[i] > in.ema21[i] && in.ema21[i] > in.ema50[i] && h.get(i).close > in.ema21[i];
        boolean dn = in.ema9[i] < in.ema21[i] && in.ema21[i] < in.ema50[i] && h.get(i).close < in.ema21[i];
        return up ? 1 : dn ? -1 : 0;
    }

    private static List<Candle> aggregate(List<Candle> src, int minutes) {
        List<Candle> out = new ArrayList<>();
        long bucketMs = minutes * 60_000L;
        Candle cur = null; long bucket = Long.MIN_VALUE;
        for (Candle x : src) {
            long b = (x.time / bucketMs) * bucketMs;
            if (cur == null || b != bucket) {
                if (cur != null) out.add(cur);
                bucket = b; cur = new Candle(b, x.open, x.high, x.low, x.close, x.volume);
            } else {
                cur.high = Math.max(cur.high, x.high); cur.low = Math.min(cur.low, x.low); cur.close = x.close; cur.volume += x.volume;
            }
        }
        if (cur != null) out.add(cur);
        return out;
    }

    private static BacktestStats backtest(List<Candle> c, Indicators ind, Settings s) {
        BacktestStats b = new BacktestStats();
        int start = Math.max(220, c.size() - 1800);
        int end = c.size() - 25;
        b.sampleBars = Math.max(0, end - start);
        double mfeSum = 0, maeSum = 0;
        int nextAllowed = start;
        for (int i = start; i < end; i++) {
            if (i < nextAllowed) continue;
            SignalEval e = evaluate(c, ind, i, s);
            if (!e.actionable) continue;
            b.signals++;
            boolean p1 = false, p2 = false, stopped = false;
            double mfe = 0, mae = 0;
            for (int j = i + 1; j <= Math.min(i + 24, c.size() - 1); j++) {
                Candle x = c.get(j);
                if (e.direction > 0) {
                    mfe = Math.max(mfe, x.high - e.entry); mae = Math.max(mae, e.entry - x.low);
                    boolean sl = x.low <= e.stop, t1 = x.high >= e.tp1, t2 = x.high >= e.tp2;
                    if (sl && (t1 || t2)) { stopped = true; break; }
                    if (sl) { stopped = true; break; }
                    if (t1) p1 = true; if (t2) { p2 = true; break; }
                } else {
                    mfe = Math.max(mfe, e.entry - x.low); mae = Math.max(mae, x.high - e.entry);
                    boolean sl = x.high >= e.stop, t1 = x.low <= e.tp1, t2 = x.low <= e.tp2;
                    if (sl && (t1 || t2)) { stopped = true; break; }
                    if (sl) { stopped = true; break; }
                    if (t1) p1 = true; if (t2) { p2 = true; break; }
                }
            }
            if (p1 && !stopped) b.tp1First++;
            if (p2 && !stopped) b.tp2First++;
            if (stopped) b.stopFirst++;
            if (!p1 && !p2 && !stopped) b.unresolved++;
            mfeSum += mfe / s.pointSize; maeSum += mae / s.pointSize;
            nextAllowed = i + 6;
        }
        if (b.signals > 0) { b.avgMfePoints = mfeSum / b.signals; b.avgMaePoints = maeSum / b.signals; }
        return b;
    }

    private static Indicators indicators(List<Candle> c) {
        Indicators in = new Indicators();
        in.ema9 = ema(c, 9); in.ema21 = ema(c, 21); in.ema50 = ema(c, 50); in.ema200 = ema(c, 200);
        in.rsi = rsi(c, 14); in.atr = atr(c, 14); in.adx = adx(c, 14); return in;
    }

    private static double[] ema(List<Candle> c, int p) {
        double[] out = new double[c.size()]; double k = 2.0 / (p + 1.0); out[0] = c.get(0).close;
        for (int i=1;i<c.size();i++) out[i] = c.get(i).close*k + out[i-1]*(1-k); return out;
    }

    private static double[] rsi(List<Candle> c, int p) {
        int n=c.size(); double[] out=new double[n]; double gain=0,loss=0;
        for(int i=1;i<n;i++){double ch=c.get(i).close-c.get(i-1).close,g=Math.max(0,ch),l=Math.max(0,-ch);
            if(i<=p){gain+=g;loss+=l;if(i==p){gain/=p;loss/=p;}}else{gain=(gain*(p-1)+g)/p;loss=(loss*(p-1)+l)/p;}
            out[i]=i>=p?(loss==0?100:100-100/(1+gain/loss)):50;} return out;
    }

    private static double[] atr(List<Candle> c, int p) {
        int n=c.size(); double[] out=new double[n]; double a=0;
        for(int i=0;i<n;i++){Candle x=c.get(i);double tr=i==0?x.high-x.low:Math.max(x.high-x.low,Math.max(Math.abs(x.high-c.get(i-1).close),Math.abs(x.low-c.get(i-1).close)));
            if(i<p){a+=tr;out[i]=tr;if(i==p-1){a/=p;out[i]=a;}}else{a=(a*(p-1)+tr)/p;out[i]=a;}} return out;
    }

    private static double[] adx(List<Candle> c, int p) {
        int n=c.size(); double[] out=new double[n]; if(n<2) return out;
        double smTr=0, smPlus=0, smMinus=0, adx=0;
        double[] dx=new double[n];
        for(int i=1;i<n;i++){
            Candle x=c.get(i), prev=c.get(i-1);
            double up=x.high-prev.high, down=prev.low-x.low;
            double plus=up>down&&up>0?up:0, minus=down>up&&down>0?down:0;
            double tr=Math.max(x.high-x.low,Math.max(Math.abs(x.high-prev.close),Math.abs(x.low-prev.close)));
            if(i<=p){smTr+=tr;smPlus+=plus;smMinus+=minus;}
            else{smTr=smTr-smTr/p+tr;smPlus=smPlus-smPlus/p+plus;smMinus=smMinus-smMinus/p+minus;}
            if(i>=p){double pdi=smTr==0?0:100*smPlus/smTr, mdi=smTr==0?0:100*smMinus/smTr;dx[i]=(pdi+mdi)==0?0:100*Math.abs(pdi-mdi)/(pdi+mdi);}
            if(i==2*p-1){double sum=0;for(int k=p;k<=i;k++)sum+=dx[k];adx=sum/p;out[i]=adx;}
            else if(i>=2*p){adx=(adx*(p-1)+dx[i])/p;out[i]=adx;}
            else out[i]=0;
        }
        return out;
    }

    private static String voteName(int v) { return v>0?"LONG":v<0?"SHORT":"WAIT"; }
    private static double clamp(double x,double lo,double hi){return Math.max(lo,Math.min(hi,x));}
    private static double getDouble(SharedPreferences p,String k,double d){try{return Double.parseDouble(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
    private static int utcHour(long millis){SimpleDateFormat f=new SimpleDateFormat("H",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));try{return Integer.parseInt(f.format(new Date(millis)));}catch(Exception e){return 0;}}

    private static DataPack fetchTwelve(String key) throws Exception {
        String u="https://api.twelvedata.com/time_series?symbol="+URLEncoder.encode("XAU/USD","UTF-8")+"&interval=5min&outputsize=1800&order=asc&timezone=UTC&apikey="+URLEncoder.encode(key,"UTF-8");
        JSONObject root=getJson(u); if("error".equalsIgnoreCase(root.optString("status"))) throw new Exception(root.optString("message","Twelve Data error"));
        JSONArray vals=root.optJSONArray("values"); if(vals==null||vals.length()<50) throw new Exception("Twelve Data returned no usable XAU/USD series");
        DataPack d=new DataPack(); d.feed="Twelve Data • XAU/USD spot"; d.quality="PRIMARY • exact symbol • completed 5m candles"; d.tradeGrade=true;
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));
        for(int i=0;i<vals.length();i++){
            JSONObject v=vals.optJSONObject(i); if(v==null) continue;
            try {
                long t=f.parse(v.optString("datetime")).getTime();
                double o=num(v,"open"),h=num(v,"high"),l=num(v,"low"),cc=num(v,"close"),vol=num(v,"volume");
                boolean valid=o>0&&h>0&&l>0&&cc>0&&h>=Math.max(o,cc)&&l<=Math.min(o,cc)&&h>=l;
                if(valid && isMarketTimestamp(t)) d.candles.add(new Candle(t,o,h,l,cc,vol));
            } catch(Exception ignored){}
        }
        if(d.candles.size()>1&&d.candles.get(0).time>d.candles.get(d.candles.size()-1).time)Collections.reverse(d.candles);
        if(d.candles.size()<260) throw new Exception("Not enough valid market-session XAU/USD candles returned by Twelve Data");
        return d;
    }

    private static DataPack fetchYahoo() throws Exception {
        Exception first=null;String[] symbols={"XAUUSD=X","GC=F"};String[] labels={"Yahoo • XAUUSD spot","Yahoo • GC=F futures proxy"};
        for(int s=0;s<symbols.length;s++){try{String sym=URLEncoder.encode(symbols[s],"UTF-8");String u="https://query2.finance.yahoo.com/v8/finance/chart/"+sym+"?interval=5m&range=1mo&includePrePost=true";JSONObject root=getJson(u);JSONObject chart=root.optJSONObject("chart");JSONArray results=chart==null?null:chart.optJSONArray("result");if(results==null||results.length()==0)throw new Exception("Yahoo returned no result");JSONObject r=results.optJSONObject(0);JSONArray ts=r.optJSONArray("timestamp");JSONObject indicators=r.optJSONObject("indicators");JSONArray quotes=indicators==null?null:indicators.optJSONArray("quote");JSONObject q=quotes==null?null:quotes.optJSONObject(0);if(ts==null||q==null)throw new Exception("Yahoo series malformed");JSONArray opens=q.optJSONArray("open"),highs=q.optJSONArray("high"),lows=q.optJSONArray("low"),closes=q.optJSONArray("close"),vols=q.optJSONArray("volume");DataPack d=new DataPack();d.feed=labels[s];d.quality="REFERENCE ONLY • delayed/proxy • alerts disabled";d.tradeGrade=false;for(int i=0;i<ts.length();i++){if(isNull(closes,i)||isNull(opens,i)||isNull(highs,i)||isNull(lows,i))continue;long t=ts.optLong(i,0)*1000L;double o=opens.optDouble(i,0),h=highs.optDouble(i,0),l=lows.optDouble(i,0),cc=closes.optDouble(i,0),v=isNull(vols,i)?0:vols.optDouble(i,0);if(t>0&&o>0&&h>0&&l>0&&cc>0)d.candles.add(new Candle(t,o,h,l,cc,v));}if(d.candles.size()>=260)return d;throw new Exception("Not enough Yahoo candles");}catch(Exception e){if(first==null)first=e;}}
        throw first==null?new Exception("No XAUUSD feed available"):first;
    }

    private static boolean isNull(JSONArray a,int i){return a==null||i>=a.length()||a.isNull(i);} private static double num(JSONObject o,String k){try{return Double.parseDouble(o.optString(k,"0"));}catch(Exception e){return 0;}}
    private static JSONObject getJson(String endpoint)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) SmartMarketWatchUltra/3.0");c.setRequestProperty("Accept","application/json,text/plain,*/*");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();if(in==null)throw new Exception("HTTP "+code);StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}if(code<200||code>=300)throw new Exception("HTTP "+code+": "+trim(sb.toString(),120));return new JSONObject(sb.toString());}
    private static String trim(String s,int n){return s==null?"":s.length()<=n?s:s.substring(0,n)+"…";}
}
