package com.smartmarketwatch.pro;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Free XAU/USD monitor.
 * Uses one REST structure refresh per completed 5-minute candle and never requires
 * a paid WebSocket subscription. Indicators are calculated locally on-device.
 */
public class GoldMonitorService extends Service {
    public static final int LIVE_NOTIFICATION_ID = 21001;
    private ScheduledExecutorService scheduler;
    private volatile long lastStructureBucket = -1;
    private volatile boolean firstStructureScan = true;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannels(this);
        startForeground(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, "Free XAU/USD 5-minute monitor starting…"));
        SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
        p.edit().putBoolean("gold_live_running", true)
                .putString("live_feed_state", "FREE REST • completed 5m candle scans")
                .apply();
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleWithFixedDelay(this::runStructureScan, 0, 15, TimeUnit.SECONDS);
    }

    private void runStructureScan() {
        try {
            SharedPreferences p = getSharedPreferences("smw", MODE_PRIVATE);
            if (!GoldEngine.isMarketOpenNow()) {
                String status = "MARKET CLOSED • " + GoldEngine.marketStateNow() + " • free monitor sleeping";
                p.edit().putString("gold_live_status", status)
                        .putString("live_feed_state", "FREE REST • market closed • no credits used by monitor")
                        .apply();
                NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                nm.notify(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this, status));
                return;
            }

            long now=System.currentTimeMillis();
            long bucket=now/(5*60_000L);
            long intoBucket=now%(5*60_000L);
            if(!firstStructureScan){
                if(bucket==lastStructureBucket) return;
                if(intoBucket<12_000L) return;
            }
            firstStructureScan=false; lastStructureBucket=bucket;

            GoldEngine.Analysis a=GoldEngine.analyze(getApplicationContext());
            String status=a.actionable()
                    ? String.format(Locale.US,"READY %s %d%% • XAU %.2f • zone %.2f–%.2f",a.direction,a.score,a.price,a.entryLow,a.entryHigh)
                    : String.format(Locale.US,"%s %d%% • XAU %.2f • %s",a.setupState,a.score,a.price,a.regime);
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(LIVE_NOTIFICATION_ID, NotificationHelper.liveNotification(this,status));

            if(a.actionable()&&p.getBoolean("gold_alerts",true)){
                String fingerprint="READY|"+a.direction+"|"+a.signalCandleTime;
                String last=p.getString("gold_last_ready_fingerprint","");
                if(!fingerprint.equals(last)){
                    String body=String.format(Locale.US,
                            "%s • %d/100 • %s • MTF %s\nEntry zone %.2f–%.2f • SL %.2f • TP1 %.2f • TP2 %.2f • R:R %.2f\n%s",
                            a.direction,a.score,a.session,a.mtfAlignment,a.entryLow,a.entryHigh,a.stop,a.tp1,a.tp2,a.rr,a.reason);
                    NotificationHelper.notify(this,"XAU/USD setup READY",body,notificationId("ready",a.signalCandleTime));
                    AlertStore.add(this,"XAU/USD READY "+a.direction+" • "+a.score+"/100",body);
                    p.edit().putString("gold_last_ready_fingerprint",fingerprint).apply();
                }
            }
            p.edit().putString("gold_live_status",status)
                    .putString("live_feed_state","FREE REST • last completed 5m candle analyzed")
                    .apply();
        } catch(Exception e){
            String msg="Feed check failed: "+clean(e.getMessage());
            getSharedPreferences("smw",MODE_PRIVATE).edit().putString("gold_live_status",msg).apply();
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(LIVE_NOTIFICATION_ID,NotificationHelper.liveNotification(this,msg));
        }
    }

    private int notificationId(String tag,long candleTime){long x=candleTime^tag.hashCode();return(int)(x&0x7fffffff);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){
        if(scheduler!=null)scheduler.shutdownNow();
        getSharedPreferences("smw",MODE_PRIVATE).edit().putBoolean("gold_live_running",false).apply();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
    private String clean(String s){if(s==null)return"unknown error";return s.length()>120?s.substring(0,120)+"…":s;}
}
