package com.smartmarketwatch.pro;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Free read-only 5-minute multi-chain smart-wallet monitor. */
public class CryptoMonitorService extends Service {
    public static final int NOTIFICATION_ID = 21002;
    private ScheduledExecutorService scheduler;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannels(this);
        startForeground(NOTIFICATION_ID, NotificationHelper.persistentNotification(this,"Multi-chain token radar","Starting Solana + EVM smart-wallet monitor…"));
        getSharedPreferences("scw",MODE_PRIVATE).edit().putBoolean("token_radar_running",true).apply();
        scheduler=Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleWithFixedDelay(this::scan,0,5,TimeUnit.MINUTES);
    }

    private void scan(){
        try{
            StringBuilder summary=new StringBuilder();
            CryptoEngine.runEarlyTokenWatch(getApplicationContext(),true,summary);
            String text=summary.toString().replace('\n',' ');
            if(text.length()>160)text=text.substring(0,160)+"…";
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID,NotificationHelper.persistentNotification(this,"Multi-chain token radar",text));
        }catch(Exception e){
            String msg=e.getMessage()==null?"scan failed":e.getMessage();
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID,NotificationHelper.persistentNotification(this,"Multi-chain token radar","Scan error • "+msg));
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){
        if(scheduler!=null)scheduler.shutdownNow();
        getSharedPreferences("scw",MODE_PRIVATE).edit().putBoolean("token_radar_running",false).apply();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
