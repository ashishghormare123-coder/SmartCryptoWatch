# Smart Market Watch Ultra 14

BTC v14: up to 24 recently BTC-active profitable Hyperliquid traders, 24-hour actual-fill backfill, 60-second incremental fill monitoring, scalp freshness buckets (0-5m / 5-15m / 15-30m / history), entry-first display ordering, null-label fallback, and LONG/SHORT/EXIT alerts. XAU/USD live WebSocket and price-action trade-level engine are retained.
