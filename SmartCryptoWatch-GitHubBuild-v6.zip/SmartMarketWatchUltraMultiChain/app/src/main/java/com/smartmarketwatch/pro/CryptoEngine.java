package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Read-only crypto intelligence engine.
 *
 * Early Token Watch v5:
 * - Solana: transaction-level wallet deltas using public JSON-RPC.
 * - EVM: generic ERC-20 Transfer log scanner on built-in chains + one custom EVM chain.
 * - DEX Screener: pair URL, DEX, price, liquidity, volume, FDV/market cap, age,
 *   price changes and buy/sell counts.
 *
 * No private keys, wallet connection, signing or trading permissions are used.
 */
public final class CryptoEngine {
    private static final String[] HL_WALLETS = {
            "0x5e13d5cedbddd7237f659947ce64bec1294e2607",
            "0xb6dca3c627fd9fb0e865c4c8fb5c2584ac8237e5"
    };
    private static final String[] HL_NAMES = {"Primary", "Confirmation"};

    private static final String SOL_USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
    private static final String SOL_USDT = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB";
    private static final String SOL_WSOL = "So11111111111111111111111111111111111111112";

    private static final String TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";

    private static final EvmNetwork[] EVM_NETWORKS = {
            new EvmNetwork("ethereum","Ethereum","https://ethereum.publicnode.com","https://etherscan.io","ETH"),
            new EvmNetwork("base","Base","https://mainnet.base.org","https://basescan.org","ETH"),
            new EvmNetwork("arbitrum","Arbitrum","https://arb1.arbitrum.io/rpc","https://arbiscan.io","ETH"),
            new EvmNetwork("optimism","Optimism","https://mainnet.optimism.io","https://optimistic.etherscan.io","ETH"),
            new EvmNetwork("bsc","BNB Chain","https://bsc-dataseed.binance.org","https://bscscan.com","BNB"),
            new EvmNetwork("polygon","Polygon","https://polygon-rpc.com","https://polygonscan.com","POL"),
            new EvmNetwork("avalanche","Avalanche","https://api.avax.network/ext/bc/C/rpc","https://snowtrace.io","AVAX"),
            new EvmNetwork("linea","Linea","https://rpc.linea.build","https://lineascan.build","ETH"),
            new EvmNetwork("scroll","Scroll","https://rpc.scroll.io","https://scrollscan.com","ETH"),
            new EvmNetwork("zksync","zkSync Era","https://mainnet.era.zksync.io","https://explorer.zksync.io","ETH"),
            new EvmNetwork("mantle","Mantle","https://rpc.mantle.xyz","https://explorer.mantle.xyz","MNT"),
            new EvmNetwork("sonic","Sonic","https://rpc.soniclabs.com","https://sonicscan.org","S"),
            new EvmNetwork("unichain","Unichain","https://mainnet.unichain.org","https://uniscan.xyz","ETH"),
            new EvmNetwork("berachain","Berachain","https://rpc.berachain.com","https://berascan.com","BERA"),
            new EvmNetwork("blast","Blast","https://rpc.blast.io","https://blastscan.io","ETH"),
            new EvmNetwork("robinhood","Robinhood Chain","https://rpc.mainnet.chain.robinhood.com","https://robinhoodchain.blockscout.com","ETH")
    };

    private CryptoEngine() {}

    public static void runAll(Context context) {
        SharedPreferences p = context.getSharedPreferences("scw", Context.MODE_PRIVATE);
        StringBuilder btcDisplay = new StringBuilder();
        StringBuilder tokenDisplay = new StringBuilder();
        boolean btcOk = false;
        boolean tokenOk = false;
        try {
            checkHyperliquid(context, p, btcDisplay);
            btcOk = true;
        } catch (Exception e) {
            btcDisplay.append("BTC check error: ").append(clean(e.getMessage()));
        }
        try {
            runEarlyTokenWatch(context, false, tokenDisplay);
            tokenOk = true;
        } catch (Exception e) {
            tokenDisplay.append("Token radar error: ").append(clean(e.getMessage()));
        }
        String time = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date());
        String status = "Last check: " + time + " • BTC " + (btcOk ? "OK" : "error") + " • Token Radar " + (tokenOk ? "OK" : "error");
        p.edit().putString("last_status", status)
                .putString("btc_display", btcDisplay.length() == 0 ? "No BTC position found." : btcDisplay.toString())
                .putString("token_display", tokenDisplay.length() == 0 ? "No new qualified smart-trader BUY/SELL events detected." : tokenDisplay.toString())
                .apply();
    }

    public static void runEarlyTokenWatch(Context context, boolean background, StringBuilder summary) {
        SharedPreferences p = context.getSharedPreferences("scw", Context.MODE_PRIVATE);
        SmartTraderQualificationEngine.ensureSeedProfiles(context);
        int before = EarlyTokenStore.get(context).size();
        StringBuilder notes = new StringBuilder();

        try {
            SmartTraderDiscoveryEngine.Result discovery = SmartTraderDiscoveryEngine.run(context, background);
            appendNote(notes, discovery.line());
        } catch (Exception e) { appendNote(notes, "Auto discovery: " + clean(e.getMessage())); }

        try { checkSolanaTransactions(context, p, background, notes); }
        catch (Exception e) { appendNote(notes, "Solana: " + clean(e.getMessage())); }

        try { checkEvmTransactions(context, p, background, notes); }
        catch (Exception e) { appendNote(notes, "EVM: " + clean(e.getMessage())); }

        try { refreshTrackedPositionPeaks(context); }
        catch (Exception ignored) {}
        appendNote(notes, SmartTraderQualificationEngine.statusLine(context));

        int after = EarlyTokenStore.get(context).size();
        int added = Math.max(0, after - before);
        if (summary != null) {
            summary.append("MULTI-CHAIN TOKEN RADAR\n")
                    .append("New events: ").append(added)
                    .append(" • Stored: ").append(after)
                    .append("\nQualified-trader gate • BUY + SELL history • DEX Screener enrichment");
            if (notes.length() > 0) summary.append("\n\n").append(notes);
            if (added == 0) summary.append("\n\nNo new qualified-trader buy/sell events this scan.");
        }
        p.edit().putLong("token_last_scan", System.currentTimeMillis()).apply();
    }

    // ---------------- BTC / HYPERLIQUID ----------------

    private static void checkHyperliquid(Context context, SharedPreferences p, StringBuilder out) throws Exception {
        JSONObject mids = postJson("https://api.hyperliquid.xyz/info", new JSONObject().put("type", "allMids"));
        double btcMid = parseDouble(mids.optString("BTC", "0"));
        List<Double> directions = new ArrayList<>();

        for (int i = 0; i < HL_WALLETS.length; i++) {
            JSONObject req = new JSONObject().put("type", "clearinghouseState").put("user", HL_WALLETS[i]);
            JSONObject state = postJson("https://api.hyperliquid.xyz/info", req);
            JSONArray positions = state.optJSONArray("assetPositions");
            JSONObject btcPos = null;
            if (positions != null) {
                for (int j = 0; j < positions.length(); j++) {
                    JSONObject wrap = positions.optJSONObject(j);
                    JSONObject pos = wrap == null ? null : wrap.optJSONObject("position");
                    if (pos != null && "BTC".equalsIgnoreCase(pos.optString("coin"))) { btcPos = pos; break; }
                }
            }

            double newSize = btcPos == null ? 0.0 : parseDouble(btcPos.optString("szi", "0"));
            double oldSize = Double.longBitsToDouble(p.getLong("hl_size_" + i, Double.doubleToLongBits(0.0)));
            boolean initialized = p.getBoolean("hl_init_" + i, false);
            directions.add(Math.signum(newSize));

            String side = newSize > 0 ? "LONG" : newSize < 0 ? "SHORT" : "FLAT";
            String entry = btcPos == null ? "—" : btcPos.optString("entryPx", "—");
            String value = btcPos == null ? "—" : btcPos.optString("positionValue", "—");
            String liq = btcPos == null ? "—" : btcPos.optString("liquidationPx", "—");
            String lev = "—";
            if (btcPos != null) {
                JSONObject leverage = btcPos.optJSONObject("leverage");
                if (leverage != null) lev = leverage.optString("value", leverage.optString("type", "—"));
            }

            if (out.length() > 0) out.append("\n\n");
            out.append(HL_NAMES[i]).append(": ").append(side)
                    .append("\nSize: ").append(fmt(Math.abs(newSize))).append(" BTC")
                    .append("\nEntry: $").append(entry)
                    .append("\nNotional: $").append(value)
                    .append("\nLeverage: ").append(lev)
                    .append("\nLiquidation: $").append(liq);

            if (initialized) {
                String change = classifyPositionChange(oldSize, newSize);
                if (change != null && p.getBoolean("btc_notifications", true)) {
                    NotificationHelper.notify(context, "BTC trader alert • " + HL_NAMES[i], change + " • " + side + " • BTC $" + fmt(btcMid), 700 + i);
                }
            }
            p.edit().putLong("hl_size_" + i, Double.doubleToRawLongBits(newSize)).putBoolean("hl_init_" + i, true).apply();
        }
        if (directions.size() == 2) {
            boolean agree = directions.get(0) != 0 && directions.get(0).equals(directions.get(1));
            out.append("\n\nBTC mid: $").append(fmt(btcMid)).append("\nTrader agreement: ").append(agree ? "YES" : "NO");
        }
    }

    private static String classifyPositionChange(double oldSize, double newSize) {
        double eps = 1e-9;
        if (Math.abs(oldSize) < eps && Math.abs(newSize) >= eps) return "Opened BTC position";
        if (Math.abs(oldSize) >= eps && Math.abs(newSize) < eps) return "Closed BTC position";
        if (Math.signum(oldSize) != Math.signum(newSize) && Math.abs(oldSize) >= eps && Math.abs(newSize) >= eps) return "Flipped BTC direction";
        if (Math.signum(oldSize) == Math.signum(newSize) && Math.abs(newSize) > Math.abs(oldSize) * 1.01) return "Added to BTC position";
        if (Math.signum(oldSize) == Math.signum(newSize) && Math.abs(newSize) < Math.abs(oldSize) * 0.99) return "Reduced BTC position";
        return null;
    }

    // ---------------- SOLANA TRANSACTION-LEVEL WATCH ----------------

    private static void checkSolanaTransactions(Context context, SharedPreferences p, boolean background, StringBuilder notes) throws Exception {
        String rpc = p.getString("rpc_url", "https://api.mainnet-beta.solana.com");
        List<SmartTraderQualificationEngine.Profile> traders = SmartTraderQualificationEngine.qualifiedSolanaProfiles(context);
        int totalNew = 0;
        if (traders.isEmpty()) {
            appendNote(notes, "Solana qualification engine: no wallet currently passes the configured trader gates");
            return;
        }

        for (SmartTraderQualificationEngine.Profile trader : traders) {
            String wallet = trader.address;
            JSONArray params = new JSONArray().put(wallet).put(new JSONObject().put("limit", 24).put("commitment", "confirmed"));
            JSONObject req = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getSignaturesForAddress").put("params", params);
            JSONObject res = postJson(rpc, req);
            JSONArray sigs = res.optJSONArray("result");
            if (sigs == null || sigs.length() == 0) continue;

            String stateKey = "sol_q_last_sig_" + Integer.toHexString(wallet.hashCode());
            String last = p.getString(stateKey, "");
            boolean initialized = !last.isEmpty();
            List<String> newSigs = new ArrayList<>();
            int initialLimit = 10;
            for (int i=0;i<sigs.length();i++) {
                JSONObject row = sigs.optJSONObject(i);
                String sig = row == null ? "" : row.optString("signature", "");
                if (sig.isEmpty()) continue;
                if (sig.equals(last)) break;
                if (!initialized && newSigs.size() >= initialLimit) break;
                newSigs.add(sig);
            }
            Collections.reverse(newSigs);
            for (String sig : newSigs) {
                totalNew += parseSolanaTransaction(context, p, rpc, wallet, trader.name, sig, initialized);
            }
            JSONObject newestObj = sigs.optJSONObject(0);
            String newest = newestObj == null ? "" : newestObj.optString("signature", "");
            if (!newest.isEmpty()) p.edit().putString(stateKey, newest).apply();
        }
        appendNote(notes, "Solana qualified traders: " + traders.size() + " • new buy/sell events " + totalNew);
    }

    private static int parseSolanaTransaction(Context context, SharedPreferences p, String rpc, String wallet, String traderName, String signature, boolean notifyAllowed) {
        try {
            JSONObject opt = new JSONObject().put("encoding", "jsonParsed").put("commitment", "confirmed").put("maxSupportedTransactionVersion", 0);
            JSONObject req = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getTransaction").put("params", new JSONArray().put(signature).put(opt));
            JSONObject txRes = postJson(rpc, req);
            JSONObject tx = txRes.optJSONObject("result");
            if (tx == null) return 0;
            JSONObject meta = tx.optJSONObject("meta");
            if (meta == null || !meta.isNull("err")) return 0;

            Map<String, Double> pre = tokenBalancesForOwner(meta.optJSONArray("preTokenBalances"), wallet);
            Map<String, Double> post = tokenBalancesForOwner(meta.optJSONArray("postTokenBalances"), wallet);
            Set<String> mints = new HashSet<>(); mints.addAll(pre.keySet()); mints.addAll(post.keySet());

            double stableSpent = 0, stableReceived = 0;
            String spentStableLabel = "", receivedStableLabel = "";
            double biggestOtherOut = 0, biggestOtherIn = 0;
            for (String mint : mints) {
                double d = post.getOrDefault(mint,0.0) - pre.getOrDefault(mint,0.0);
                if (SOL_USDC.equals(mint) || SOL_USDT.equals(mint)) {
                    if (d < 0) { stableSpent += -d; spentStableLabel = SOL_USDC.equals(mint) ? "USDC" : "USDT"; }
                    if (d > 0) { stableReceived += d; receivedStableLabel = SOL_USDC.equals(mint) ? "USDC" : "USDT"; }
                } else if (!SOL_WSOL.equals(mint)) {
                    if (d < 0) biggestOtherOut = Math.max(biggestOtherOut, -d);
                    if (d > 0) biggestOtherIn = Math.max(biggestOtherIn, d);
                }
            }

            double solFlow = solNetFlow(tx, meta, wallet);
            double solSpent = Math.max(0, -solFlow);
            double solReceived = Math.max(0, solFlow);
            long blockTime = tx.optLong("blockTime", System.currentTimeMillis()/1000L) * 1000L;
            int added = 0;

            for (String mint : mints) {
                if (SOL_USDC.equals(mint) || SOL_USDT.equals(mint) || SOL_WSOL.equals(mint)) continue;
                double before = pre.getOrDefault(mint,0.0), after = post.getOrDefault(mint,0.0);
                double delta = after - before;
                if (Math.abs(delta) <= 1e-12) continue;

                boolean isBuy = delta > 0;
                if (!isBuy && !SmartTraderQualificationEngine.hasOpenPosition(context,"solana",wallet,mint)) continue;
                boolean swapLike = isBuy
                        ? (stableSpent > 0 || solSpent > 0 || biggestOtherOut > Math.abs(delta) * 1e-12)
                        : (stableReceived > 0 || solReceived > 0 || biggestOtherIn > Math.abs(delta) * 1e-12);
                if (!swapLike) continue;

                TokenMetrics m = fetchDexMetrics("solana", mint);
                if (m.symbol.isEmpty() && m.liquidityUsd <= 0) continue;
                double amount = Math.abs(delta);
                double estimate;
                String flowLabel;
                String confidence;
                if (isBuy) {
                    estimate = stableSpent > 0 ? stableSpent : (m.priceUsd > 0 ? amount * m.priceUsd : 0);
                    flowLabel = stableSpent > 0 ? String.format(Locale.US,"Spent %.2f %s",stableSpent,spentStableLabel)
                            : (solSpent > 0 ? String.format(Locale.US,"Spent ~%.4f SOL",solSpent) : "Token-to-token swap outflow matched");
                    confidence = stableSpent > 0 ? "HIGH • stablecoin outflow matched" : (solSpent > 0 ? "HIGH • SOL outflow matched" : "MEDIUM • token swap outflow matched");
                } else {
                    estimate = stableReceived > 0 ? stableReceived : (m.priceUsd > 0 ? amount * m.priceUsd : 0);
                    flowLabel = stableReceived > 0 ? String.format(Locale.US,"Received %.2f %s",stableReceived,receivedStableLabel)
                            : (solReceived > 0 ? String.format(Locale.US,"Received ~%.4f SOL",solReceived) : "Token-to-token proceeds matched");
                    confidence = stableReceived > 0 ? "HIGH • stablecoin proceeds matched" : (solReceived > 0 ? "HIGH • SOL proceeds matched" : "MEDIUM • token swap proceeds matched");
                }

                double top10 = fetchTop10Pct(rpc, mint);
                EarlyTokenStore.Event e = eventFromMetrics(m);
                e.id = "solana|" + signature + "|" + mint + "|" + wallet + "|" + (isBuy?"buy":"sell");
                e.chain="Solana"; e.chainSlug="solana"; e.trader=traderName; e.traderAddress=wallet;
                e.action=isBuy?"BUY":"SELL"; e.confidence=confidence;
                e.tokenAddress=mint; e.txHash=signature; e.timestamp=blockTime; e.tokenAmount=amount; e.walletTokenBalance=after;
                e.estimatedSpendUsd=estimate; e.spendLabel=flowLabel;
                e.explorerTxUrl="https://solscan.io/tx/"+signature; e.explorerTraderUrl="https://solscan.io/account/"+wallet; e.explorerTokenUrl="https://solscan.io/token/"+mint;
                e.top10Pct=top10; e.riskNote=riskNote(m,top10);

                boolean traderPass = SmartTraderQualificationEngine.processEvent(context,e);
                boolean tokenPass = !isBuy || passesFilters(p,m);
                e.qualifying = traderPass && tokenPass;
                if (traderPass && EarlyTokenStore.add(context,e)) {
                    added++;
                    if (notifyAllowed && e.qualifying && p.getBoolean("token_notifications",true)) notifyEarlyEvent(context,e);
                }
            }
            return added;
        } catch (Exception ignored) { return 0; }
    }

    private static Map<String,Double> tokenBalancesForOwner(JSONArray a,String owner) {
        Map<String,Double> out=new HashMap<>();
        if(a==null)return out;
        for(int i=0;i<a.length();i++){
            JSONObject b=a.optJSONObject(i); if(b==null)continue;
            String o=b.optString("owner",""); if(!owner.equals(o))continue;
            String mint=b.optString("mint",""); JSONObject ui=b.optJSONObject("uiTokenAmount");
            double amount=ui==null?0:parseDouble(ui.optString("uiAmountString",String.valueOf(ui.optDouble("uiAmount",0))));
            if(!mint.isEmpty())out.put(mint,out.getOrDefault(mint,0.0)+amount);
        }
        return out;
    }

    /** Positive means the wallet received SOL; negative means it spent SOL. Fee is neutralized. */
    private static double solNetFlow(JSONObject tx,JSONObject meta,String wallet){
        try{
            JSONObject transaction=tx.optJSONObject("transaction"); JSONObject message=transaction==null?null:transaction.optJSONObject("message");
            JSONArray keys=message==null?null:message.optJSONArray("accountKeys"); if(keys==null)return 0;
            int idx=-1;
            for(int i=0;i<keys.length();i++){
                Object k=keys.opt(i); String pub="";
                if(k instanceof JSONObject)pub=((JSONObject)k).optString("pubkey",""); else if(k!=null)pub=String.valueOf(k);
                if(wallet.equals(pub)){idx=i;break;}
            }
            if(idx<0)return 0;
            JSONArray pre=meta.optJSONArray("preBalances"),post=meta.optJSONArray("postBalances");
            if(pre==null||post==null||idx>=pre.length()||idx>=post.length())return 0;
            long before=pre.optLong(idx),after=post.optLong(idx),fee=meta.optLong("fee",0);
            // Solana transaction fees are paid by the fee-payer (account index 0).
            long feeCorrection = idx==0 ? fee : 0;
            return (after-before+feeCorrection)/1_000_000_000.0;
        }catch(Exception e){return 0;}
    }

    // ---------------- GENERIC EVM WALLET WATCH ----------------

    private static void checkEvmTransactions(Context context, SharedPreferences p, boolean background, StringBuilder notes) throws Exception {
        Map<String,String> manualWallets = parseEvmWallets(p.getString("evm_wallets", ""));
        Set<String> enabled = parseCsvSet(p.getString("evm_chains", defaultChainList()));
        int chainCount=0, eventCount=0, autoCount=SmartTraderDiscoveryEngine.autoEvmWalletCount(context);
        for(EvmNetwork n:EVM_NETWORKS){
            if(!enabled.contains("all")&&!enabled.contains(n.slug))continue;
            Map<String,String> wallets = new LinkedHashMap<>(manualWallets);
            wallets.putAll(SmartTraderDiscoveryEngine.autoEvmWalletsForChain(context,n.slug));
            if(wallets.isEmpty())continue;
            chainCount++;
            try{eventCount+=scanEvmNetwork(context,p,n,wallets,background);}catch(Exception ignored){}
        }

        String customRpc=p.getString("custom_evm_rpc","").trim();
        String customSlug=p.getString("custom_evm_slug","").trim().toLowerCase(Locale.US);
        if(!customRpc.isEmpty()&&!customSlug.isEmpty()){
            String customName=p.getString("custom_evm_name",customSlug).trim();
            String customExplorer=p.getString("custom_evm_explorer","").trim();
            String nativeSymbol=p.getString("custom_evm_native","ETH").trim();
            Map<String,String> customWallets = new LinkedHashMap<>(manualWallets);
            customWallets.putAll(SmartTraderDiscoveryEngine.autoEvmWalletsForChain(context,customSlug));
            if(!customWallets.isEmpty()){
                try{eventCount+=scanEvmNetwork(context,p,new EvmNetwork(customSlug,customName,customRpc,customExplorer,nativeSymbol),customWallets,background); chainCount++;}catch(Exception ignored){}
            }
        }
        appendNote(notes,"EVM direct follow-up: manual "+manualWallets.size()+" • auto-qualified "+autoCount+" • chains scanned "+chainCount+" • published qualified buy/sell events "+eventCount);
    }

    private static int scanEvmNetwork(Context context,SharedPreferences p,EvmNetwork n,Map<String,String> wallets,boolean background) throws Exception {
        long latest=hexLong(evmCall(n.rpc,"eth_blockNumber",new JSONArray()).optString("result","0x0"));
        if(latest<=0)return 0;
        String blockKey="evm_q_block_"+n.slug;
        long last=p.getLong(blockKey,-1);
        boolean initial = last < 0;
        long from = initial ? Math.max(0, latest - 300) : Math.max(last + 1, Math.max(0, latest - 2500));
        if(from>latest){p.edit().putLong(blockKey,latest).apply();return 0;}
        int added=0;
        for(Map.Entry<String,String> w:wallets.entrySet()){
            String wallet=w.getKey(); if(!isEvmAddress(wallet))continue;
            SmartTraderQualificationEngine.ensureManualCandidate(context,n.slug,w.getValue(),wallet);

            JSONObject baseFilter=new JSONObject().put("fromBlock",toHex(from)).put("toBlock",toHex(latest));

            // Incoming token transfers -> possible BUY.
            JSONObject inFilter=new JSONObject(baseFilter.toString());
            inFilter.put("topics",new JSONArray().put(TRANSFER_TOPIC).put(JSONObject.NULL).put(paddedAddressTopic(wallet)));
            JSONArray inLogs=evmCall(n.rpc,"eth_getLogs",new JSONArray().put(inFilter)).optJSONArray("result");
            Set<String> seenIncoming=new HashSet<>();
            if(inLogs!=null){
                for(int i=0;i<inLogs.length();i++){
                    JSONObject log=inLogs.optJSONObject(i); if(log==null)continue;
                    String token=log.optString("address","").toLowerCase(Locale.US);
                    String txHash=log.optString("transactionHash","");
                    if(token.isEmpty()||txHash.isEmpty()||!seenIncoming.add(txHash+"|"+token))continue;
                    EarlyTokenStore.Event e=parseEvmIncoming(context,p,n,w.getValue(),wallet,token,txHash,log);
                    if(e==null)continue;
                    boolean traderPass=SmartTraderQualificationEngine.processEvent(context,e);
                    e.qualifying=traderPass&&passesFilters(p,eventMetrics(e));
                    if(traderPass&&EarlyTokenStore.add(context,e)){
                        added++;
                        if(!initial&&e.qualifying&&p.getBoolean("token_notifications",true))notifyEarlyEvent(context,e);
                    }
                }
            }

            // Outgoing token transfers -> possible SELL, but only for positions the engine saw us buy.
            JSONObject outFilter=new JSONObject(baseFilter.toString());
            outFilter.put("topics",new JSONArray().put(TRANSFER_TOPIC).put(paddedAddressTopic(wallet)));
            JSONArray outLogs=evmCall(n.rpc,"eth_getLogs",new JSONArray().put(outFilter)).optJSONArray("result");
            Set<String> seenOutgoing=new HashSet<>();
            if(outLogs!=null){
                for(int i=0;i<outLogs.length();i++){
                    JSONObject log=outLogs.optJSONObject(i); if(log==null)continue;
                    String token=log.optString("address","").toLowerCase(Locale.US);
                    String txHash=log.optString("transactionHash","");
                    if(token.isEmpty()||txHash.isEmpty()||!seenOutgoing.add(txHash+"|"+token))continue;
                    if(!SmartTraderQualificationEngine.hasOpenPosition(context,n.slug,wallet,token))continue;
                    EarlyTokenStore.Event e=parseEvmOutgoing(context,n,w.getValue(),wallet,token,txHash,log);
                    if(e==null)continue;
                    boolean traderPass=SmartTraderQualificationEngine.processEvent(context,e);
                    e.qualifying=traderPass; // exit alerts are not blocked by entry market-cap filters
                    if(traderPass&&EarlyTokenStore.add(context,e)){
                        added++;
                        if(!initial&&p.getBoolean("token_notifications",true))notifyEarlyEvent(context,e);
                    }
                }
            }
        }
        p.edit().putLong(blockKey,latest).apply();
        return added;
    }

    private static EarlyTokenStore.Event parseEvmIncoming(Context context,SharedPreferences p,EvmNetwork n,String traderName,String wallet,String token,String txHash,JSONObject incomingLog){
        try{
            int decimals=erc20Decimals(n.rpc,token);
            String symbol=erc20Symbol(n.rpc,token);
            BigInteger raw=hexBig(incomingLog.optString("data","0x0"));
            double amount=scale(raw,decimals);
            if(amount<=0)return null;

            JSONObject txObj=evmCall(n.rpc,"eth_getTransactionByHash",new JSONArray().put(txHash)).optJSONObject("result");
            JSONObject receipt=evmCall(n.rpc,"eth_getTransactionReceipt",new JSONArray().put(txHash)).optJSONObject("result");
            if(txObj==null||receipt==null)return null;
            String blockHex=receipt.optString("blockNumber",incomingLog.optString("blockNumber","0x0"));
            JSONObject block=evmCall(n.rpc,"eth_getBlockByNumber",new JSONArray().put(blockHex).put(false)).optJSONObject("result");
            long timestamp=block==null?System.currentTimeMillis():hexLong(block.optString("timestamp","0x0"))*1000L;

            double nativeSpent=scale(hexBig(txObj.optString("value","0x0")),18);
            Outflow out=findEvmOutflow(n,wallet,token,receipt.optJSONArray("logs"));
            boolean swapLike=nativeSpent>0||out.amount>0;
            if(!swapLike)return null;

            TokenMetrics m=fetchDexMetrics(n.slug,token);
            if(m.symbol.isEmpty())m.symbol=symbol;
            if(m.name.isEmpty())m.name=symbol;
            if(m.symbol.isEmpty()&&m.liquidityUsd<=0)return null;
            double estimated=m.priceUsd>0?amount*m.priceUsd:0;

            EarlyTokenStore.Event e=eventFromMetrics(m);
            e.id=n.slug+"|"+txHash+"|"+token+"|"+wallet.toLowerCase(Locale.US)+"|buy";
            e.chain=n.name; e.chainSlug=n.slug; e.trader=traderName; e.traderAddress=wallet;
            e.action="BUY"; e.confidence=nativeSpent>0?"HIGH • native-asset spend matched":"HIGH • ERC-20 outflow matched";
            e.tokenAddress=token; e.txHash=txHash; e.timestamp=timestamp; e.tokenAmount=amount; e.estimatedSpendUsd=estimated;
            if(nativeSpent>0)e.spendLabel=String.format(Locale.US,"Spent ~%.6f %s",nativeSpent,n.nativeSymbol);
            else e.spendLabel="Spent ~"+fmt(out.amount)+" "+(out.symbol.isEmpty()?shortAddress(out.token):out.symbol);
            e.explorerTxUrl=explorer(n,"tx",txHash); e.explorerTraderUrl=explorer(n,"address",wallet); e.explorerTokenUrl=explorer(n,"address",token);
            e.riskNote=riskNote(m,-1);
            return e;
        }catch(Exception ex){return null;}
    }

    private static EarlyTokenStore.Event parseEvmOutgoing(Context context,EvmNetwork n,String traderName,String wallet,String token,String txHash,JSONObject outgoingLog){
        try{
            int decimals=erc20Decimals(n.rpc,token);
            String symbol=erc20Symbol(n.rpc,token);
            double amount=scale(hexBig(outgoingLog.optString("data","0x0")),decimals);
            if(amount<=0)return null;
            JSONObject receipt=evmCall(n.rpc,"eth_getTransactionReceipt",new JSONArray().put(txHash)).optJSONObject("result");
            if(receipt==null)return null;
            Inflow in=findEvmInflow(n,wallet,token,receipt.optJSONArray("logs"));
            if(in.amount<=0)return null; // strict: do not call a plain transfer a SELL
            String blockHex=receipt.optString("blockNumber",outgoingLog.optString("blockNumber","0x0"));
            JSONObject block=evmCall(n.rpc,"eth_getBlockByNumber",new JSONArray().put(blockHex).put(false)).optJSONObject("result");
            long timestamp=block==null?System.currentTimeMillis():hexLong(block.optString("timestamp","0x0"))*1000L;

            TokenMetrics m=fetchDexMetrics(n.slug,token);
            if(m.symbol.isEmpty())m.symbol=symbol;
            if(m.name.isEmpty())m.name=symbol;
            double estimated=m.priceUsd>0?amount*m.priceUsd:0;

            EarlyTokenStore.Event e=eventFromMetrics(m);
            e.id=n.slug+"|"+txHash+"|"+token+"|"+wallet.toLowerCase(Locale.US)+"|sell";
            e.chain=n.name; e.chainSlug=n.slug; e.trader=traderName; e.traderAddress=wallet;
            e.action="SELL"; e.confidence="HIGH • ERC-20 proceeds matched";
            e.tokenAddress=token; e.txHash=txHash; e.timestamp=timestamp; e.tokenAmount=amount; e.estimatedSpendUsd=estimated;
            e.spendLabel="Received ~"+fmt(in.amount)+" "+(in.symbol.isEmpty()?shortAddress(in.token):in.symbol);
            e.explorerTxUrl=explorer(n,"tx",txHash); e.explorerTraderUrl=explorer(n,"address",wallet); e.explorerTokenUrl=explorer(n,"address",token);
            e.riskNote=riskNote(m,-1);
            return e;
        }catch(Exception ex){return null;}
    }

    private static Outflow findEvmOutflow(EvmNetwork n,String wallet,String acquiredToken,JSONArray logs){
        Outflow best=new Outflow(); if(logs==null)return best;
        String fromTopic=paddedAddressTopic(wallet);
        for(int i=0;i<logs.length();i++){
            JSONObject l=logs.optJSONObject(i); if(l==null)continue;
            JSONArray t=l.optJSONArray("topics"); if(t==null||t.length()<3||!TRANSFER_TOPIC.equalsIgnoreCase(t.optString(0)))continue;
            if(!fromTopic.equalsIgnoreCase(t.optString(1)))continue;
            String token=l.optString("address","").toLowerCase(Locale.US); if(token.equalsIgnoreCase(acquiredToken))continue;
            try{
                int dec=erc20Decimals(n.rpc,token); double amount=scale(hexBig(l.optString("data","0x0")),dec);
                if(amount>best.amount){best.amount=amount;best.token=token;best.symbol=erc20Symbol(n.rpc,token);}
            }catch(Exception ignored){}
        }
        return best;
    }

    private static Inflow findEvmInflow(EvmNetwork n,String wallet,String soldToken,JSONArray logs){
        Inflow best=new Inflow(); if(logs==null)return best;
        String toTopic=paddedAddressTopic(wallet);
        for(int i=0;i<logs.length();i++){
            JSONObject l=logs.optJSONObject(i); if(l==null)continue;
            JSONArray t=l.optJSONArray("topics"); if(t==null||t.length()<3||!TRANSFER_TOPIC.equalsIgnoreCase(t.optString(0)))continue;
            if(!toTopic.equalsIgnoreCase(t.optString(2)))continue;
            String token=l.optString("address","").toLowerCase(Locale.US); if(token.equalsIgnoreCase(soldToken))continue;
            try{
                int dec=erc20Decimals(n.rpc,token); double amount=scale(hexBig(l.optString("data","0x0")),dec);
                if(amount>best.amount){best.amount=amount;best.token=token;best.symbol=erc20Symbol(n.rpc,token);}
            }catch(Exception ignored){}
        }
        return best;
    }

    private static TokenMetrics eventMetrics(EarlyTokenStore.Event e){
        TokenMetrics m=new TokenMetrics();
        m.liquidityUsd=e.liquidityUsd;m.volume24h=e.volume24h;m.marketCap=e.marketCap;m.fdv=e.fdv;
        return m;
    }

    private static int erc20Decimals(String rpc,String token)throws Exception{
        JSONObject call=new JSONObject().put("to",token).put("data","0x313ce567");
        String h=evmCall(rpc,"eth_call",new JSONArray().put(call).put("latest")).optString("result","0x12");
        return Math.max(0,Math.min(36,(int)hexLong(h)));
    }
    private static String erc20Symbol(String rpc,String token){
        try{
            JSONObject call=new JSONObject().put("to",token).put("data","0x95d89b41");
            String h=evmCall(rpc,"eth_call",new JSONArray().put(call).put("latest")).optString("result","");
            return decodeAbiString(h);
        }catch(Exception e){return "";}
    }

    private static void refreshTrackedPositionPeaks(Context context) {
        List<SmartTraderQualificationEngine.TrackedPosition> positions = SmartTraderQualificationEngine.positionsForRefresh(context, 6);
        for (SmartTraderQualificationEngine.TrackedPosition pos : positions) {
            try {
                TokenMetrics m = fetchDexMetrics(pos.chainSlug, pos.token);
                double cap = m.marketCap > 0 ? m.marketCap : m.fdv;
                if (cap > 0) SmartTraderQualificationEngine.updatePeak(context, pos, cap);
            } catch (Exception ignored) {}
        }
    }

    // ---------------- DEX SCREENER ENRICHMENT ----------------

    private static TokenMetrics fetchDexMetrics(String chainSlug,String token) throws Exception {
        String raw=getText("https://api.dexscreener.com/token-pairs/v1/"+urlPart(chainSlug)+"/"+urlPart(token));
        JSONArray pairs;
        try{pairs=new JSONArray(raw);}catch(Exception e){return new TokenMetrics();}
        TokenMetrics best=new TokenMetrics();
        for(int i=0;i<pairs.length();i++){
            JSONObject pair=pairs.optJSONObject(i); if(pair==null)continue;
            JSONObject base=pair.optJSONObject("baseToken");
            if(base==null||!token.equalsIgnoreCase(base.optString("address","")))continue;
            double liq=pair.optJSONObject("liquidity")==null?0:pair.optJSONObject("liquidity").optDouble("usd",0);
            if(liq<best.liquidityUsd)continue;
            best.liquidityUsd=liq; best.chainId=pair.optString("chainId",chainSlug); best.dexId=pair.optString("dexId","");
            best.url=pair.optString("url",""); best.pairAddress=pair.optString("pairAddress",""); best.priceUsd=parseDouble(pair.optString("priceUsd","0"));
            best.marketCap=pair.optDouble("marketCap",pair.optDouble("fdv",0)); best.fdv=pair.optDouble("fdv",0); best.pairCreatedAt=pair.optLong("pairCreatedAt",0);
            best.symbol=base.optString("symbol",""); best.name=base.optString("name","");
            JSONObject quote=pair.optJSONObject("quoteToken"); best.quoteSymbol=quote==null?"":quote.optString("symbol","");
            JSONObject vol=pair.optJSONObject("volume"); best.volume24h=vol==null?0:vol.optDouble("h24",0);
            JSONObject pc=pair.optJSONObject("priceChange");
            if(pc!=null){best.pc5=optNaN(pc,"m5");best.pc1h=optNaN(pc,"h1");best.pc6h=optNaN(pc,"h6");best.pc24h=optNaN(pc,"h24");}
            JSONObject txns=pair.optJSONObject("txns");
            if(txns!=null){
                JSONObject m5=txns.optJSONObject("m5"); JSONObject h1=txns.optJSONObject("h1");
                if(m5!=null){best.buys5=m5.optInt("buys",-1);best.sells5=m5.optInt("sells",-1);}
                if(h1!=null){best.buys1h=h1.optInt("buys",-1);best.sells1h=h1.optInt("sells",-1);}
            }
        }
        return best;
    }

    private static EarlyTokenStore.Event eventFromMetrics(TokenMetrics m){
        EarlyTokenStore.Event e=new EarlyTokenStore.Event();
        e.tokenName=m.name;e.tokenSymbol=m.symbol;e.dexId=m.dexId;e.pairAddress=m.pairAddress;e.dexUrl=m.url;
        e.detectionPriceUsd=m.priceUsd;e.marketCap=m.marketCap;e.fdv=m.fdv;e.liquidityUsd=m.liquidityUsd;e.volume24h=m.volume24h;e.pairCreatedAt=m.pairCreatedAt;
        e.priceChange5m=m.pc5;e.priceChange1h=m.pc1h;e.priceChange6h=m.pc6h;e.priceChange24h=m.pc24h;
        e.buys5m=m.buys5;e.sells5m=m.sells5;e.buys1h=m.buys1h;e.sells1h=m.sells1h;
        return e;
    }

    private static boolean passesFilters(SharedPreferences p,TokenMetrics m){
        double minL=prefDouble(p,"token_min_liq",50000); double minV=prefDouble(p,"token_min_vol",20000);
        double minMc=prefDouble(p,"token_min_mc",100000); double maxMc=prefDouble(p,"token_max_mc",20000000);
        double cap=m.marketCap>0?m.marketCap:m.fdv;
        return m.liquidityUsd>=minL&&m.volume24h>=minV&&cap>=minMc&&cap<=maxMc;
    }

    private static String riskNote(TokenMetrics m,double top10){
        List<String> r=new ArrayList<>();
        if(m.liquidityUsd>0&&m.liquidityUsd<50000)r.add("low liquidity");
        if(m.pairCreatedAt>0&&System.currentTimeMillis()-m.pairCreatedAt<60*60_000L)r.add("pair <1h old");
        if(top10>=0&&top10>50)r.add("top-10 concentration >50%");
        if(!Double.isNaN(m.pc5)&&Math.abs(m.pc5)>30)r.add("extreme 5m move");
        if(r.isEmpty())return "No basic liquidity/age red flag detected • not a security audit";
        return "Watch: "+join(r,", ")+" • not a security audit";
    }

    private static void notifyEarlyEvent(Context c,EarlyTokenStore.Event e){
        String sym=e.tokenSymbol==null||e.tokenSymbol.isEmpty()?shortAddress(e.tokenAddress):e.tokenSymbol;
        String action="SELL".equalsIgnoreCase(e.action)?"SELL":"BUY";
        String body=e.chain+" • "+e.trader+" • Q"+e.traderScore+" • "+e.spendLabel+" • "+fmt(e.tokenAmount)+" "+sym+" • Liq $"+fmt(e.liquidityUsd)+" • MC $"+fmt(e.marketCap);
        String title=("SELL".equals(action)?"Smart Trader SELL • ":"Early Token BUY • ")+sym;
        NotificationHelper.notify(c,title,body,Math.abs(e.id.hashCode()));
        AlertStore.add(c,title,body);
    }

    // ---------------- SOLANA CONCENTRATION ----------------

    private static double fetchTop10Pct(String rpc, String mint) {
        try {
            JSONObject supplyReq = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getTokenSupply").put("params", new JSONArray().put(mint));
            JSONObject supplyRes = postJson(rpc, supplyReq);
            JSONObject value = supplyRes.optJSONObject("result") == null ? null : supplyRes.optJSONObject("result").optJSONObject("value");
            double supply = value == null ? 0 : parseDouble(value.optString("uiAmountString",String.valueOf(value.optDouble("uiAmount",0))));
            if (supply <= 0) return -1;
            JSONObject largestReq = new JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", "getTokenLargestAccounts").put("params", new JSONArray().put(mint));
            JSONObject largestRes = postJson(rpc, largestReq);
            JSONArray vals = largestRes.optJSONObject("result") == null ? null : largestRes.optJSONObject("result").optJSONArray("value");
            if (vals == null) return -1;
            double sum = 0;
            for (int i = 0; i < Math.min(10, vals.length()); i++) sum += parseDouble(vals.optJSONObject(i).optString("uiAmountString",String.valueOf(vals.optJSONObject(i).optDouble("uiAmount",0))));
            return 100.0 * sum / supply;
        } catch (Exception ignored) { return -1; }
    }

    // ---------------- NETWORK / JSON HELPERS ----------------

    private static JSONObject postJson(String endpoint, JSONObject body) throws Exception {
        HttpURLConnection c = connection(endpoint,"POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8); try(OutputStream os=c.getOutputStream()){os.write(bytes);} return new JSONObject(readResponse(c));
    }

    private static JSONObject evmCall(String endpoint,String method,JSONArray params)throws Exception{
        return postJson(endpoint,new JSONObject().put("jsonrpc","2.0").put("id",1).put("method",method).put("params",params));
    }

    private static String getText(String endpoint)throws Exception{HttpURLConnection c=connection(endpoint,"GET");return readResponse(c);}
    private static HttpURLConnection connection(String endpoint,String method)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();c.setRequestMethod(method);c.setConnectTimeout(6500);c.setReadTimeout(9000);c.setRequestProperty("User-Agent","SmartMarketWatchUltra/4.0");return c;
    }
    private static String readResponse(HttpURLConnection c)throws Exception{
        int code=c.getResponseCode();InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();if(is==null)throw new Exception("HTTP "+code);
        StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}if(code<200||code>=300)throw new Exception("HTTP "+code+": "+sb);return sb.toString();
    }

    private static Map<String,String> parseEvmWallets(String raw){
        Map<String,String> out=new LinkedHashMap<>(); if(raw==null)return out;
        String[] lines=raw.split("[\\n,;]+");int n=1;
        for(String line:lines){
            String s=line.trim();if(s.isEmpty())continue;String label="Wallet "+n,address=s;
            int eq=s.indexOf('=');if(eq>0){label=s.substring(0,eq).trim();address=s.substring(eq+1).trim();}
            if(isEvmAddress(address)){out.put(address.toLowerCase(Locale.US),label.isEmpty()?shortAddress(address):label);n++;}
        }return out;
    }
    private static Set<String> parseCsvSet(String raw){Set<String>s=new HashSet<>();if(raw==null)return s;for(String x:raw.split("[,;\\s]+"))if(!x.trim().isEmpty())s.add(x.trim().toLowerCase(Locale.US));return s;}
    private static String defaultChainList(){return "ethereum,base,arbitrum,optimism,bsc,polygon,avalanche,linea,scroll,zksync,mantle,sonic,unichain,berachain,blast,robinhood";}
    private static boolean isEvmAddress(String s){return s!=null&&s.matches("(?i)^0x[0-9a-f]{40}$");}
    private static String paddedAddressTopic(String a){String x=a.toLowerCase(Locale.US).replace("0x","");return "0x000000000000000000000000"+x;}
    private static String explorer(EvmNetwork n,String type,String value){if(n.explorer==null||n.explorer.isEmpty())return"";String base=n.explorer.endsWith("/")?n.explorer.substring(0,n.explorer.length()-1):n.explorer;return base+"/"+type+"/"+value;}
    private static long hexLong(String h){try{return hexBig(h).longValue();}catch(Exception e){return 0;}}
    private static BigInteger hexBig(String h){if(h==null||h.isEmpty()||"0x".equals(h))return BigInteger.ZERO;String x=h.startsWith("0x")?h.substring(2):h;if(x.isEmpty())return BigInteger.ZERO;return new BigInteger(x,16);}
    private static String toHex(long x){return "0x"+Long.toHexString(Math.max(0,x));}
    private static double scale(BigInteger v,int decimals){if(v==null)return 0;return v.doubleValue()/Math.pow(10,Math.max(0,decimals));}
    private static String decodeAbiString(String hex){
        try{
            if(hex==null)return"";String h=hex.startsWith("0x")?hex.substring(2):hex;if(h.isEmpty())return"";
            byte[] bytes=hexBytes(h);
            if(bytes.length>=64){int len=new BigInteger(sliceHex(h,64,128),16).intValue();int start=128;if(len>0&&start+len*2<=h.length())return new String(hexBytes(h.substring(start,start+len*2)),StandardCharsets.UTF_8).replace("\u0000","").trim();}
            String s=new String(bytes,StandardCharsets.UTF_8).replace("\u0000","").trim();return s.length()>32?s.substring(0,32):s;
        }catch(Exception e){return"";}
    }
    private static String sliceHex(String h,int a,int b){return h.substring(Math.min(a,h.length()),Math.min(b,h.length()));}
    private static byte[] hexBytes(String s){int len=s.length();if((len&1)==1)s="0"+s;byte[]out=new byte[s.length()/2];for(int i=0;i<out.length;i++)out[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return out;}
    private static String urlPart(String s){try{return java.net.URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private static double prefDouble(SharedPreferences p,String key,double d){try{return Double.parseDouble(p.getString(key,String.valueOf(d)));}catch(Exception e){return d;}}
    private static double parseDouble(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    private static double optNaN(JSONObject o,String key){return o.has(key)?o.optDouble(key,Double.NaN):Double.NaN;}
    private static String fmt(double v){if(Double.isNaN(v)||Double.isInfinite(v))return"—";if(Math.abs(v)>=1_000_000_000)return String.format(Locale.US,"%.2fB",v/1_000_000_000.0);if(Math.abs(v)>=1_000_000)return String.format(Locale.US,"%.2fM",v/1_000_000.0);if(Math.abs(v)>=1000)return String.format(Locale.US,"%.2fK",v/1000.0);if(Math.abs(v)>=1)return String.format(Locale.US,"%.2f",v);return String.format(Locale.US,"%.6f",v);}
    private static String shortAddress(String s){if(s==null)return"";return s.length()<=12?s:s.substring(0,6)+"…"+s.substring(s.length()-4);}
    private static String clean(String s){if(s==null||s.isEmpty())return"unknown error";return s.length()>160?s.substring(0,160)+"…":s;}
    private static void appendNote(StringBuilder b,String s){if(b==null||s==null||s.isEmpty())return;if(b.length()>0)b.append("\n");b.append(s);}
    private static String join(List<String> xs,String sep){StringBuilder b=new StringBuilder();for(String x:xs){if(b.length()>0)b.append(sep);b.append(x);}return b.toString();}

    private static class EvmNetwork {
        final String slug,name,rpc,explorer,nativeSymbol;
        EvmNetwork(String slug,String name,String rpc,String explorer,String nativeSymbol){this.slug=slug;this.name=name;this.rpc=rpc;this.explorer=explorer;this.nativeSymbol=nativeSymbol;}
    }
    private static class Outflow {String token="",symbol="";double amount=0;}
    private static class Inflow {String token="",symbol="";double amount=0;}
    private static class TokenMetrics {
        String chainId="",dexId="",url="",pairAddress="",symbol="",name="",quoteSymbol="";
        double priceUsd=0,marketCap=0,fdv=0,liquidityUsd=0,volume24h=0;
        long pairCreatedAt=0;double pc5=Double.NaN,pc1h=Double.NaN,pc6h=Double.NaN,pc24h=Double.NaN;int buys5=-1,sells5=-1,buys1h=-1,sells1h=-1;
    }
}
