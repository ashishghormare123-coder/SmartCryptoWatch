package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * BTC smart-trader scalp watcher.
 *
 * v12 changes the BTC panel from two static open-position snapshots into a recent-fill feed:
 * - selects active, profitable Hyperliquid leaderboard traders (cached hourly),
 * - checks their actual BTC fills every minute,
 * - only labels a LONG/SHORT when the fill opens/adds/flips exposure,
 * - keeps exits in history so the user can see when the watched trader gets out,
 * - shows each trader fill exactly as executed; user sizing remains separate.
 *
 * Read-only: no keys, wallet connection, signing, or order placement.
 */
public final class BtcSmartTraderEngine {
    private static final String PREFS = "scw";
    private static final String INFO = "https://api.hyperliquid.xyz/info";
    private static final String LEADERBOARD = "https://stats-data.hyperliquid.xyz/Mainnet/leaderboard";
    private static final long ROSTER_TTL_MS = 60L * 60_000L;
    private static final long EVENT_KEEP_MS = 24L * 60L * 60_000L;
    private static final long FILL_LOOKBACK_MS = 30L * 60_000L;
    private static final int MAX_ROSTER = 6;

    // Fallback only if the leaderboard host is unavailable and there is no cached roster.
    private static final String[] FALLBACK_WALLETS = {
            "0x5e13d5cedbddd7237f659947ce64bec1294e2607",
            "0xb6dca3c627fd9fb0e865c4c8fb5c2584ac8237e5"
    };

    private BtcSmartTraderEngine() {}

    public static final class Result {
        public String display = "";
        public int monitored = 0;
        public int freshEntries = 0;
        public int freshExits = 0;
        public double btcMid = 0;
    }

    public static Result scan(Context context, boolean background) throws Exception {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        List<Trader> traders = loadOrRefreshRoster(p, now);
        Result result = new Result();
        result.monitored = traders.size();
        result.btcMid = fetchBtcMid();

        JSONArray events = loadEvents(p);
        pruneEvents(events, now);
        Set<String> seen = eventIds(events);

        for (Trader trader : traders) {
            JSONArray fills;
            try {
                fills = userFillsByTime(trader.address, now - FILL_LOOKBACK_MS, now);
            } catch (Exception ignored) {
                continue;
            }
            for (int i = 0; i < fills.length(); i++) {
                JSONObject fill = fills.optJSONObject(i);
                if (fill == null || !"BTC".equalsIgnoreCase(fill.optString("coin", ""))) continue;
                long time = fill.optLong("time", 0L);
                if (time <= 0 || now - time > FILL_LOOKBACK_MS) continue;

                String action = classify(fill);
                if (action.isEmpty()) continue;
                String id = fillId(trader.address, fill);
                if (seen.contains(id)) continue;

                double px = d(fill.optString("px", "0"));
                double sz = Math.abs(d(fill.optString("sz", "0")));
                if (px <= 0 || sz <= 0) continue;

                JSONObject e = new JSONObject();
                e.put("id", id);
                e.put("time", time);
                e.put("address", trader.address);
                e.put("label", trader.label);
                e.put("score", trader.score);
                e.put("weekPnl", trader.weekPnl);
                e.put("btcWinRate", trader.btcWinRate);
                e.put("action", action);
                e.put("price", px);
                e.put("size", sz);
                e.put("sourceNotional", px * sz);
                e.put("closedPnl", d(fill.optString("closedPnl", "0")));
                e.put("hash", fill.optString("hash", ""));
                events.put(e);
                seen.add(id);

                boolean entry = "LONG".equals(action) || "SHORT".equals(action);
                if (entry) result.freshEntries++; else result.freshExits++;

                // Only alert on genuinely fresh fills. Initial history can still be displayed without noisy old alerts.
                if (background && now - time <= 3L * 60_000L) notifyEvent(context, e);
            }
        }

        events = newestFirst(events);
        if (events.length() > 40) {
            JSONArray clipped = new JSONArray();
            for (int i = 0; i < 40; i++) clipped.put(events.optJSONObject(i));
            events = clipped;
        }
        p.edit().putString("btc_scalp_events", events.toString()).apply();
        result.display = buildDisplay(traders, events, result.btcMid, now);
        p.edit().putString("btc_display", result.display)
                .putLong("btc_last_scan", now)
                .apply();
        return result;
    }

    private static List<Trader> loadOrRefreshRoster(SharedPreferences p, long now) {
        String cached = p.getString("btc_trader_roster", "");
        long cachedAt = p.getLong("btc_trader_roster_time", 0L);
        if (!cached.isEmpty() && now - cachedAt < ROSTER_TTL_MS) {
            List<Trader> parsed = parseRoster(cached);
            if (!parsed.isEmpty()) return parsed;
        }

        try {
            List<Trader> refreshed = refreshRoster(now);
            if (!refreshed.isEmpty()) {
                p.edit().putString("btc_trader_roster", rosterJson(refreshed).toString())
                        .putLong("btc_trader_roster_time", now)
                        .apply();
                return refreshed;
            }
        } catch (Exception ignored) {}

        if (!cached.isEmpty()) {
            List<Trader> parsed = parseRoster(cached);
            if (!parsed.isEmpty()) return parsed;
        }

        List<Trader> fallback = new ArrayList<>();
        for (int i = 0; i < FALLBACK_WALLETS.length; i++) {
            Trader t = new Trader();
            t.address = FALLBACK_WALLETS[i];
            t.label = "Fallback " + (i + 1);
            t.score = 60;
            fallback.add(t);
        }
        return fallback;
    }

    private static List<Trader> refreshRoster(long now) throws Exception {
        String raw = get(LEADERBOARD, 30_000, 35_000);
        JSONObject root = new JSONObject(raw);
        JSONArray rows = root.optJSONArray("leaderboardRows");
        if (rows == null) return Collections.emptyList();

        List<Trader> candidates = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String address = row.optString("ethAddress", "").toLowerCase(Locale.US);
            if (!address.matches("0x[0-9a-f]{40}")) continue;
            double account = d(row.optString("accountValue", "0"));
            if (account < 50_000 || account > 25_000_000) continue;

            Perf day = perf(row, "day");
            Perf week = perf(row, "week");
            Perf month = perf(row, "month");
            Perf all = perf(row, "allTime");
            if (week.pnl <= 0 || month.pnl <= 0) continue;
            if (day.vlm < 250_000 || week.vlm < 2_000_000) continue;
            double turnover = account > 0 ? day.vlm / account : 9999;
            if (turnover < 0.03 || turnover > 180.0) continue; // avoids inactive accounts and extreme maker/HFT profiles

            Trader t = new Trader();
            t.address = address;
            String display = row.optString("displayName", "").trim();
            t.label = display.isEmpty() ? shortAddress(address) : display;
            t.accountValue = account;
            t.dayPnl = day.pnl;
            t.weekPnl = week.pnl;
            t.monthPnl = month.pnl;
            t.dayVolume = day.vlm;
            t.score = 60;
            if (day.pnl > 0) t.score += 6;
            if (week.pnl / account > 0.01) t.score += 6;
            if (month.pnl / account > 0.03) t.score += 6;
            if (week.pnl > 50_000) t.score += 4;
            if (all.pnl > 0) t.score += 3;
            if (turnover >= 0.5 && turnover <= 40) t.score += 4;
            candidates.add(t);
        }

        Collections.sort(candidates, new Comparator<Trader>() {
            @Override public int compare(Trader a, Trader b) {
                int byScore = Integer.compare(b.score, a.score);
                if (byScore != 0) return byScore;
                return Double.compare(b.weekPnl, a.weekPnl);
            }
        });

        // Validate a limited number against their actual BTC history so the fast loop follows BTC-active traders,
        // not merely profitable accounts that never touch BTC.
        List<Trader> qualified = new ArrayList<>();
        int inspect = Math.min(12, candidates.size());
        long start = now - 7L * 24L * 60L * 60_000L;
        for (int i = 0; i < inspect && qualified.size() < MAX_ROSTER; i++) {
            Trader t = candidates.get(i);
            try {
                JSONArray fills = userFillsByTime(t.address, start, now);
                int btcFills = 0, closes = 0, wins = 0;
                double realized = 0;
                for (int j = 0; j < fills.length(); j++) {
                    JSONObject f = fills.optJSONObject(j);
                    if (f == null || !"BTC".equalsIgnoreCase(f.optString("coin", ""))) continue;
                    btcFills++;
                    double cp = d(f.optString("closedPnl", "0"));
                    if (Math.abs(cp) > 1e-9) {
                        closes++;
                        realized += cp;
                        if (cp > 0) wins++;
                    }
                }
                double winRate = closes > 0 ? 100.0 * wins / closes : 0;
                if (btcFills < 3 || btcFills > 300 || closes < 2 || realized <= 0 || winRate < 45.0) continue;
                t.btcFills7d = btcFills;
                t.btcRealized7d = realized;
                t.btcWinRate = winRate;
                t.score += winRate >= 60 ? 8 : winRate >= 50 ? 5 : 2;
                if (realized > 5_000) t.score += 5;
                t.score = Math.min(95, t.score);
                qualified.add(t);
            } catch (Exception ignored) {}
        }

        // If the strict BTC-history filter yields too few, supplement with top active profitable accounts.
        for (Trader t : candidates) {
            if (qualified.size() >= MAX_ROSTER) break;
            boolean exists = false;
            for (Trader q : qualified) if (q.address.equalsIgnoreCase(t.address)) { exists = true; break; }
            if (!exists) qualified.add(t);
        }
        if (qualified.size() > MAX_ROSTER) qualified = new ArrayList<>(qualified.subList(0, MAX_ROSTER));
        return qualified;
    }

    private static Perf perf(JSONObject row, String name) {
        JSONArray windows = row.optJSONArray("windowPerformances");
        if (windows != null) {
            for (int i = 0; i < windows.length(); i++) {
                JSONArray pair = windows.optJSONArray(i);
                if (pair == null || pair.length() < 2 || !name.equals(pair.optString(0))) continue;
                JSONObject o = pair.optJSONObject(1);
                if (o == null) break;
                Perf p = new Perf();
                p.pnl = d(o.optString("pnl", "0"));
                p.roi = d(o.optString("roi", "0"));
                p.vlm = d(o.optString("vlm", "0"));
                return p;
            }
        }
        return new Perf();
    }

    private static JSONArray userFillsByTime(String address, long start, long end) throws Exception {
        JSONObject req = new JSONObject()
                .put("type", "userFillsByTime")
                .put("user", address)
                .put("startTime", start)
                .put("endTime", end)
                .put("aggregateByTime", true);
        return postArray(INFO, req);
    }

    private static double fetchBtcMid() {
        try {
            JSONObject mids = postObject(INFO, new JSONObject().put("type", "allMids"));
            return d(mids.optString("BTC", "0"));
        } catch (Exception e) { return 0; }
    }

    private static String classify(JSONObject fill) {
        String dir = fill.optString("dir", "").toLowerCase(Locale.US);
        if (dir.contains("open long") || dir.contains("short > long")) return "LONG";
        if (dir.contains("open short") || dir.contains("long > short")) return "SHORT";
        if (dir.contains("close long")) return "EXIT LONG";
        if (dir.contains("close short")) return "EXIT SHORT";

        double start = d(fill.optString("startPosition", "0"));
        double sz = Math.abs(d(fill.optString("sz", "0")));
        String side = fill.optString("side", "");
        if (sz <= 0) return "";
        if ("B".equalsIgnoreCase(side)) {
            double end = start + sz;
            if (end > 0 && Math.abs(end) > Math.abs(start) + 1e-9) return "LONG";
            if (start < 0 && Math.abs(end) < Math.abs(start)) return "EXIT SHORT";
        } else if ("A".equalsIgnoreCase(side)) {
            double end = start - sz;
            if (end < 0 && Math.abs(end) > Math.abs(start) + 1e-9) return "SHORT";
            if (start > 0 && Math.abs(end) < Math.abs(start)) return "EXIT LONG";
        }
        return "";
    }

    private static String buildDisplay(List<Trader> traders, JSONArray events, double btcMid, long now) {
        StringBuilder b = new StringBuilder();
        b.append("LIVE BTC SMART-TRADER SCALP FEED")
                .append("\nBTC mid: $").append(money(btcMid))
                .append("\nMonitoring: ").append(traders.size()).append(" active profitable traders")
                .append(" • BTC scan every 60s")
                .append("\nActual trader fills shown • signals only, no orders");

        int longs = 0, shorts = 0;
        long consensusSince = now - 15L * 60_000L;
        for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e == null || e.optLong("time", 0) < consensusSince) continue;
            String a = e.optString("action", "");
            if ("LONG".equals(a)) longs++;
            else if ("SHORT".equals(a)) shorts++;
        }
        b.append("\n15m fresh entries: LONG ").append(longs).append(" • SHORT ").append(shorts);
        if (longs + shorts > 0) {
            String bias = longs == shorts ? "MIXED" : longs > shorts ? "LONG" : "SHORT";
            b.append(" • bias ").append(bias);
        }

        int shown = 0;
        for (int i = 0; i < events.length() && shown < 8; i++) {
            JSONObject e = events.optJSONObject(i);
            if (e == null) continue;
            long time = e.optLong("time", 0L);
            if (now - time > EVENT_KEEP_MS) continue;
            shown++;
            String action = e.optString("action", "");
            double px = e.optDouble("price", 0);
            double size = e.optDouble("size", 0);
            double source = e.optDouble("sourceNotional", 0);
            int score = e.optInt("score", 0);
            double wr = e.optDouble("btcWinRate", 0);
            b.append("\n\n").append(age(now - time)).append(" • ").append(action)
                    .append(" • ").append(e.optString("label", shortAddress(e.optString("address", ""))))
                    .append(" • Q").append(score)
                    .append("\nFill: $").append(money(px)).append(" • source ").append(sizeFmt(size)).append(" BTC (~$").append(compact(source)).append(")");
            if (wr > 0) b.append(" • 7d BTC win ").append(String.format(Locale.US, "%.0f%%", wr));
            double cp = e.optDouble("closedPnl", 0);
            if (action.startsWith("EXIT") && Math.abs(cp) > 0.01) b.append("\nClosed PnL: $").append(money(cp));
        }
        if (shown == 0) {
            b.append("\n\nNo fresh BTC smart-trader fills in the last 24h yet. The old static position snapshot is no longer treated as a new trade.");
        }
        return b.toString();
    }

    private static void notifyEvent(Context context, JSONObject e) {
        String action = e.optString("action", "BTC");
        String label = e.optString("label", "Smart trader");
        double px = e.optDouble("price", 0);
        String title = "BTC smart trader • " + action;
        double size = e.optDouble("size", 0);
        String body = label + " • fill $" + money(px) + (size > 0 ? " • " + sizeFmt(size) + " BTC" : "");
        NotificationHelper.notify(context, title, body, Math.abs(e.optString("id", title).hashCode()));
        AlertStore.add(context, title, body);
    }

    private static JSONArray loadEvents(SharedPreferences p) {
        try { return new JSONArray(p.getString("btc_scalp_events", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void pruneEvents(JSONArray events, long now) {
        JSONArray kept = new JSONArray();
        for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e != null && now - e.optLong("time", 0L) <= EVENT_KEEP_MS) kept.put(e);
        }
        while (events.length() > 0) events.remove(events.length() - 1);
        for (int i = 0; i < kept.length(); i++) events.put(kept.optJSONObject(i));
    }

    private static Set<String> eventIds(JSONArray events) {
        Set<String> out = new HashSet<>();
        for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e != null) out.add(e.optString("id", ""));
        }
        return out;
    }

    private static JSONArray newestFirst(JSONArray events) {
        List<JSONObject> rows = new ArrayList<>();
        for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e != null) rows.add(e);
        }
        Collections.sort(rows, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                return Long.compare(b.optLong("time", 0L), a.optLong("time", 0L));
            }
        });
        JSONArray out = new JSONArray();
        for (JSONObject e : rows) out.put(e);
        return out;
    }

    private static String fillId(String address, JSONObject fill) {
        String hash = fill.optString("hash", "");
        String tid = String.valueOf(fill.opt("tid"));
        if (!hash.isEmpty()) return address + ":" + hash + ":" + tid;
        return address + ":" + fill.optLong("time", 0) + ":" + fill.optString("px", "") + ":" + fill.optString("sz", "") + ":" + fill.optString("dir", "");
    }

    private static JSONArray rosterJson(List<Trader> traders) {
        JSONArray a = new JSONArray();
        for (Trader t : traders) {
            JSONObject o = new JSONObject();
            try {
                o.put("address", t.address); o.put("label", t.label); o.put("score", t.score);
                o.put("accountValue", t.accountValue); o.put("dayPnl", t.dayPnl); o.put("weekPnl", t.weekPnl); o.put("monthPnl", t.monthPnl);
                o.put("dayVolume", t.dayVolume); o.put("btcFills7d", t.btcFills7d); o.put("btcRealized7d", t.btcRealized7d); o.put("btcWinRate", t.btcWinRate);
            } catch (Exception ignored) {}
            a.put(o);
        }
        return a;
    }

    private static List<Trader> parseRoster(String raw) {
        List<Trader> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i); if (o == null) continue;
                Trader t = new Trader();
                t.address = o.optString("address", ""); t.label = o.optString("label", shortAddress(t.address)); t.score = o.optInt("score", 60);
                t.accountValue = o.optDouble("accountValue", 0); t.dayPnl = o.optDouble("dayPnl", 0); t.weekPnl = o.optDouble("weekPnl", 0); t.monthPnl = o.optDouble("monthPnl", 0);
                t.dayVolume = o.optDouble("dayVolume", 0); t.btcFills7d = o.optInt("btcFills7d", 0); t.btcRealized7d = o.optDouble("btcRealized7d", 0); t.btcWinRate = o.optDouble("btcWinRate", 0);
                if (t.address.matches("(?i)^0x[0-9a-f]{40}$")) out.add(t);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static JSONObject postObject(String endpoint, JSONObject body) throws Exception {
        String raw = post(endpoint, body, 8_000, 12_000);
        return new JSONObject(raw);
    }

    private static JSONArray postArray(String endpoint, JSONObject body) throws Exception {
        String raw = post(endpoint, body, 8_000, 14_000);
        return new JSONArray(raw);
    }

    private static String post(String endpoint, JSONObject body, int connectMs, int readMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(connectMs); c.setReadTimeout(readMs); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("User-Agent", "SmartMarketWatchUltra/12.0");
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        return read(c);
    }

    private static String get(String endpoint, int connectMs, int readMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(connectMs); c.setReadTimeout(readMs);
        c.setRequestProperty("User-Agent", "SmartMarketWatchUltra/12.0");
        return read(c);
    }

    private static String read(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        if (is == null) throw new Exception("HTTP " + code);
        StringBuilder b = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line; while ((line = br.readLine()) != null) b.append(line);
        }
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        return b.toString();
    }

    private static double d(String s) { try { return Double.parseDouble(s); } catch (Exception e) { return 0; } }
    private static String shortAddress(String s) { return s == null || s.length() <= 12 ? (s == null ? "" : s) : s.substring(0, 6) + "…" + s.substring(s.length() - 4); }
    private static String money(double v) { return String.format(Locale.US, "%,.2f", v); }
    private static String sizeFmt(double v) { return v >= 1 ? String.format(Locale.US, "%.4f", v) : String.format(Locale.US, "%.6f", v); }
    private static String compact(double v) {
        if (Math.abs(v) >= 1_000_000) return String.format(Locale.US, "%.2fM", v / 1_000_000.0);
        if (Math.abs(v) >= 1_000) return String.format(Locale.US, "%.2fK", v / 1_000.0);
        return String.format(Locale.US, "%.2f", v);
    }
    private static String age(long ms) {
        if (ms < 60_000) return Math.max(0, ms / 1000) + "s ago";
        if (ms < 60L * 60_000L) return (ms / 60_000L) + "m ago";
        return (ms / (60L * 60_000L)) + "h ago";
    }

    private static final class Perf { double pnl, roi, vlm; }
    private static final class Trader {
        String address = "", label = "";
        int score = 60, btcFills7d = 0;
        double accountValue = 0, dayPnl = 0, weekPnl = 0, monthPnl = 0, dayVolume = 0, btcRealized7d = 0, btcWinRate = 0;
    }
}
