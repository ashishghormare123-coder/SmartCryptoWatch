package com.smartmarketwatch.pro;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * v15 live crypto monitor:
 * - BTC 24h backfill + smart-trader fills every 60 seconds.
 * - Early-token multi-chain radar every 5 minutes.
 */
public class CryptoMonitorService extends Service {
    public static final int NOTIFICATION_ID = 21002;
    private ScheduledExecutorService scheduler;

    @Override public void onCreate() {
        super.onCreate();
        NotificationHelper.ensureChannels(this);
        startForeground(NOTIFICATION_ID, NotificationHelper.persistentNotification(this,
                "Live crypto radar", "BTC smart-trader fills every 60s • early tokens every 5m"));
        getSharedPreferences("scw", MODE_PRIVATE).edit().putBoolean("token_radar_running", true).apply();
        scheduler = Executors.newScheduledThreadPool(2);
        scheduler.scheduleWithFixedDelay(this::scanBtc, 0, 60, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(this::scanTokens, 5, 5, TimeUnit.MINUTES);
    }

    private void scanBtc() {
        try {
            BtcSmartTraderEngine.Result r = BtcSmartTraderEngine.scan(getApplicationContext(), true);
            String text = "BTC $" + String.format(java.util.Locale.US, "%,.0f", r.btcMid)
                    + " • " + r.monitored + " traders • new entries " + r.freshEntries
                    + " • exits " + r.freshExits;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, NotificationHelper.persistentNotification(this, "Live crypto radar", text));
        } catch (Exception e) {
            // Keep the foreground service alive; the next minute retries automatically.
        }
    }

    private void scanTokens() {
        try {
            StringBuilder summary = new StringBuilder();
            CryptoEngine.runEarlyTokenWatch(getApplicationContext(), true, summary);
            String text = summary.toString().replace('\n', ' ');
            if (text.length() > 160) text = text.substring(0, 160) + "…";
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, NotificationHelper.persistentNotification(this, "Live crypto radar", text));
        } catch (Exception ignored) {}
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        getSharedPreferences("scw", MODE_PRIVATE).edit().putBoolean("token_radar_running", false).apply();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
