package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Persists and tracks issued READY XAU/USD signals against live prices.
 * A setup stays active until TP2, SL, or a six-hour expiry. TP1 can be
 * recorded first and the same setup can later finish at TP2 or SL.
 */
public final class GoldSignalTracker {
    private static final String PREFS = "smw";
    private static final String KEY_ACTIVE = "gold_active_setups_v17";
    private static final long MAX_LIFE_MS = 6L * 60L * 60_000L;
    private GoldSignalTracker() {}

    public static synchronized boolean registerReady(Context context, GoldEngine.Analysis a, String fingerprint) {
        if (a == null || !a.actionable() || fingerprint == null || fingerprint.isEmpty()) return false;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray arr = load(p);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject x = arr.optJSONObject(i);
            if (x != null && fingerprint.equals(x.optString("id", ""))) return false;
        }
        JSONObject x = new JSONObject();
        try {
            x.put("id", fingerprint);
            x.put("direction", a.direction);
            x.put("entry", a.entry);
            x.put("stop", a.stop);
            x.put("tp1", a.tp1);
            x.put("tp2", a.tp2);
            x.put("score", a.score);
            x.put("startedAt", System.currentTimeMillis());
            x.put("signalCandleTime", a.signalCandleTime);
            x.put("tp1Hit", false);
            x.put("tp1HitAt", 0L);
            arr.put(x);
        } catch (Exception ignored) { return false; }
        save(p, arr);
        p.edit().putInt("gold_stats_signals", p.getInt("gold_stats_signals", 0) + 1).apply();
        return true;
    }

    public static synchronized void onPrice(Context context, double price, long now) {
        if (price <= 0) return;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray arr = load(p);
        JSONArray kept = new JSONArray();
        boolean changed = false;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject x = arr.optJSONObject(i);
            if (x == null) continue;
            String dir = x.optString("direction", "");
            double stop = x.optDouble("stop", 0), tp1 = x.optDouble("tp1", 0), tp2 = x.optDouble("tp2", 0);
            long started = x.optLong("startedAt", now);
            boolean tp1Hit = x.optBoolean("tp1Hit", false);
            boolean close = false;

            if (now - started > MAX_LIFE_MS) {
                increment(p, "gold_stats_expired");
                lifecycle(context, "XAU/USD setup EXPIRED", detail(x, price, "No TP2/SL resolution within 6h."), x.optString("id", "expired") + "|expired");
                changed = true;
                continue;
            }

            boolean longSide = "LONG".equals(dir);
            boolean slHit = longSide ? price <= stop : price >= stop;
            boolean t1HitNow = longSide ? price >= tp1 : price <= tp1;
            boolean t2HitNow = longSide ? price >= tp2 : price <= tp2;

            // With live ticks, a direct jump to TP2 means both targets were crossed.
            if (!tp1Hit && t2HitNow) {
                increment(p, "gold_stats_tp1");
                increment(p, "gold_stats_tp2");
                String body = detail(x, price, "TP1 and TP2 both reached. Setup closed at TP2 milestone.");
                lifecycle(context, "XAU/USD TP1 + TP2 HIT", body, x.optString("id", "tp2") + "|tp2");
                close = true; changed = true;
            } else if (slHit) {
                increment(p, "gold_stats_sl");
                if (tp1Hit) increment(p, "gold_stats_sl_after_tp1");
                else increment(p, "gold_stats_sl_before_tp1");
                String note = tp1Hit ? "SL reached after TP1. Setup closed." : "Stop loss reached before TP1. Setup closed.";
                lifecycle(context, tp1Hit ? "XAU/USD SL HIT after TP1" : "XAU/USD STOP LOSS HIT", detail(x, price, note), x.optString("id", "sl") + "|sl");
                close = true; changed = true;
            } else {
                if (!tp1Hit && t1HitNow) {
                    increment(p, "gold_stats_tp1");
                    tp1Hit = true;
                    try { x.put("tp1Hit", true); x.put("tp1HitAt", now); } catch (Exception ignored) {}
                    lifecycle(context, "XAU/USD TP1 HIT", detail(x, price, "First target reached. TP2/SL tracking continues."), x.optString("id", "tp1") + "|tp1");
                    changed = true;
                }
                if (tp1Hit && t2HitNow) {
                    increment(p, "gold_stats_tp2");
                    lifecycle(context, "XAU/USD TP2 HIT", detail(x, price, "Second target reached. Setup completed."), x.optString("id", "tp2") + "|tp2");
                    close = true; changed = true;
                }
            }
            if (!close) kept.put(x);
        }
        if (changed || kept.length() != arr.length()) save(p, kept);
    }

    public static synchronized String summary(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int signals = p.getInt("gold_stats_signals", 0);
        int tp1 = p.getInt("gold_stats_tp1", 0);
        int tp2 = p.getInt("gold_stats_tp2", 0);
        int sl = p.getInt("gold_stats_sl", 0);
        int slBefore = p.getInt("gold_stats_sl_before_tp1", 0);
        int slAfter = p.getInt("gold_stats_sl_after_tp1", 0);
        int expired = p.getInt("gold_stats_expired", 0);
        int active = load(p).length();
        double tp1Rate = signals > 0 ? 100.0 * tp1 / signals : 0;
        double tp2Rate = signals > 0 ? 100.0 * tp2 / signals : 0;
        double slRate = signals > 0 ? 100.0 * sl / signals : 0;
        return String.format(Locale.US,
                "LIVE GOLD SIGNAL RECORD • since v17\nSignals issued: %d • active: %d\nTP1 hit: %d (%.1f%%) • TP2 hit: %d (%.1f%%)\nSL hit: %d (%.1f%%) • before TP1: %d • after TP1: %d • expired: %d\nTP1 and TP2 can both count on the same trade.",
                signals, active, tp1, tp1Rate, tp2, tp2Rate, sl, slRate, slBefore, slAfter, expired);
    }

    private static String detail(JSONObject x, double livePrice, String note) {
        return String.format(Locale.US,
                "%s • live %.2f\nEntry %.2f • SL %.2f • TP1 %.2f • TP2 %.2f\n%s",
                x.optString("direction", "XAU"), livePrice, x.optDouble("entry", 0), x.optDouble("stop", 0), x.optDouble("tp1", 0), x.optDouble("tp2", 0), note);
    }

    private static void lifecycle(Context context, String title, String body, String id) {
        AlertStore.add(context, title, body);
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (p.getBoolean("gold_alerts", true)) NotificationHelper.notify(context, title, body, Math.abs(id.hashCode()));
    }

    private static void increment(SharedPreferences p, String key) {
        p.edit().putInt(key, p.getInt(key, 0) + 1).apply();
    }

    private static JSONArray load(SharedPreferences p) {
        try { return new JSONArray(p.getString(KEY_ACTIVE, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void save(SharedPreferences p, JSONArray arr) {
        p.edit().putString(KEY_ACTIVE, arr.toString()).apply();
    }
}
