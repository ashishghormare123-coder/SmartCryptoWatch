package com.smartmarketwatch.pro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class CandleChartView extends View {
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint upPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint downPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emaFastPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint emaSlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint levelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<GoldEngine.Candle> candles = new ArrayList<>();
    private double entry, stop, tp1, tp2;
    private boolean showLevels;

    public CandleChartView(Context context) { super(context); init(); }
    public CandleChartView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public CandleChartView(Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); init(); }

    private void init() {
        gridPaint.setColor(0xFF243453); gridPaint.setStrokeWidth(dp(1));
        textPaint.setColor(0xFFA8B3CC); textPaint.setTextSize(dp(10));
        upPaint.setColor(0xFF1BC48A); upPaint.setStrokeWidth(dp(1.5f));
        downPaint.setColor(0xFFFF637A); downPaint.setStrokeWidth(dp(1.5f));
        emaFastPaint.setColor(0xFF7EA2FF); emaFastPaint.setStrokeWidth(dp(1.6f)); emaFastPaint.setStyle(Paint.Style.STROKE);
        emaSlowPaint.setColor(0xFFF5BD4E); emaSlowPaint.setStrokeWidth(dp(1.2f)); emaSlowPaint.setStyle(Paint.Style.STROKE);
        levelPaint.setStrokeWidth(dp(1)); levelPaint.setStyle(Paint.Style.STROKE);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setData(List<GoldEngine.Candle> candles, double entry, double stop, double tp1, double tp2, boolean showLevels) {
        this.candles = candles == null ? new ArrayList<>() : new ArrayList<>(candles);
        this.entry = entry; this.stop = stop; this.tp1 = tp1; this.tp2 = tp2; this.showLevels = showLevels;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        canvas.drawColor(0x00101C33);
        if (candles == null || candles.size() < 2 || w <= 0 || h <= 0) {
            textPaint.setTextSize(dp(12));
            canvas.drawText("Run analysis to load XAUUSD candles", dp(8), h / 2f, textPaint);
            return;
        }
        float left = dp(4), right = w - dp(4), top = dp(10), bottom = h - dp(18);
        for (int g = 1; g <= 3; g++) {
            float y = top + (bottom - top) * g / 4f;
            canvas.drawLine(left, y, right, y, gridPaint);
        }

        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
        for (GoldEngine.Candle c : candles) { min = Math.min(min, c.low); max = Math.max(max, c.high); }
        if (showLevels) { min = Math.min(min, Math.min(stop, Math.min(tp1, tp2))); max = Math.max(max, Math.max(entry, Math.max(tp1, tp2))); }
        double pad = Math.max((max - min) * 0.08, 0.01); min -= pad; max += pad;
        float cw = (right - left) / candles.size();
        float bodyW = Math.max(dp(2), cw * 0.58f);
        for (int i = 0; i < candles.size(); i++) {
            GoldEngine.Candle c = candles.get(i);
            Paint p = c.close >= c.open ? upPaint : downPaint;
            float x = left + cw * (i + 0.5f);
            float yH = y(c.high, min, max, top, bottom), yL = y(c.low, min, max, top, bottom);
            float yO = y(c.open, min, max, top, bottom), yC = y(c.close, min, max, top, bottom);
            canvas.drawLine(x, yH, x, yL, p);
            float t = Math.min(yO, yC), b = Math.max(yO, yC);
            if (b - t < dp(1.4f)) b = t + dp(1.4f);
            p.setStyle(Paint.Style.FILL);
            canvas.drawRect(x - bodyW / 2f, t, x + bodyW / 2f, b, p);
        }

        drawEma(canvas, left, cw, min, max, top, bottom, 9, emaFastPaint);
        drawEma(canvas, left, cw, min, max, top, bottom, 21, emaSlowPaint);

        if (showLevels) {
            drawLevel(canvas, entry, "ENTRY", 0xFF7EA2FF, min, max, top, bottom, left, right);
            drawLevel(canvas, stop, "SL", 0xFFFF637A, min, max, top, bottom, left, right);
            drawLevel(canvas, tp1, "TP1", 0xFF1BC48A, min, max, top, bottom, left, right);
            drawLevel(canvas, tp2, "TP2", 0xFF55C7FF, min, max, top, bottom, left, right);
        }
        textPaint.setTextSize(dp(9));
        canvas.drawText(String.format(java.util.Locale.US, "%.2f", max - pad), left, dp(9), textPaint);
        canvas.drawText(String.format(java.util.Locale.US, "%.2f", min + pad), left, h - dp(3), textPaint);
    }

    private void drawEma(Canvas canvas, float left, float cw, double min, double max, float top, float bottom, int period, Paint paint) {
        if (candles.size() < period) return;
        double k = 2.0 / (period + 1.0);
        double ema = candles.get(0).close;
        Path path = new Path();
        for (int i = 0; i < candles.size(); i++) {
            ema = i == 0 ? candles.get(i).close : candles.get(i).close * k + ema * (1 - k);
            float x = left + cw * (i + 0.5f);
            float yy = y(ema, min, max, top, bottom);
            if (i == 0) path.moveTo(x, yy); else path.lineTo(x, yy);
        }
        canvas.drawPath(path, paint);
    }

    private void drawLevel(Canvas canvas, double value, String label, int color, double min, double max, float top, float bottom, float left, float right) {
        levelPaint.setColor(color);
        textPaint.setColor(color);
        float yy = y(value, min, max, top, bottom);
        canvas.drawLine(left, yy, right, yy, levelPaint);
        textPaint.setTextSize(dp(8));
        canvas.drawText(label, Math.max(left, right - dp(32)), yy - dp(2), textPaint);
        textPaint.setColor(0xFFA8B3CC);
    }

    private float y(double v, double min, double max, float top, float bottom) {
        return (float) (bottom - (v - min) / Math.max(max - min, 0.00001) * (bottom - top));
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
