package com.smartmarketwatch.pro;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private EditText apiKey, minScore, pointSize, tp1, tp2, minRr;
    private EditText evmWallets, evmChains, solRpc, tokenMinLiq, tokenMinVol, tokenMinMc, tokenMaxMc;
    private EditText smartMinScore, smartMinWinrate, smartMinHold, smartMaxFastExit;
    private EditText customName, customSlug, customRpc, customExplorer, customNative;
    private CheckBox sessionOnly, goldAlerts, cryptoAlerts, smartOnlyQualified;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        apiKey=findViewById(R.id.apiKeyInput); minScore=findViewById(R.id.minScoreInput); pointSize=findViewById(R.id.pointSizeInput);
        tp1=findViewById(R.id.tp1Input); tp2=findViewById(R.id.tp2Input); minRr=findViewById(R.id.minRrInput);
        sessionOnly=findViewById(R.id.sessionOnlyCheck); goldAlerts=findViewById(R.id.goldAlertsCheck); cryptoAlerts=findViewById(R.id.cryptoAlertsCheck);
        evmWallets=findViewById(R.id.evmWalletsInput); evmChains=findViewById(R.id.evmChainsInput); solRpc=findViewById(R.id.solRpcInput);
        tokenMinLiq=findViewById(R.id.tokenMinLiqInput); tokenMinVol=findViewById(R.id.tokenMinVolInput); tokenMinMc=findViewById(R.id.tokenMinMcInput); tokenMaxMc=findViewById(R.id.tokenMaxMcInput);
        smartMinScore=findViewById(R.id.smartMinScoreInput); smartMinWinrate=findViewById(R.id.smartMinWinrateInput); smartMinHold=findViewById(R.id.smartMinHoldInput); smartMaxFastExit=findViewById(R.id.smartMaxFastExitInput);
        smartOnlyQualified=findViewById(R.id.smartOnlyQualifiedCheck);
        customName=findViewById(R.id.customChainNameInput); customSlug=findViewById(R.id.customChainSlugInput); customRpc=findViewById(R.id.customChainRpcInput);
        customExplorer=findViewById(R.id.customChainExplorerInput); customNative=findViewById(R.id.customChainNativeInput);

        SharedPreferences p=getSharedPreferences("smw",MODE_PRIVATE);
        apiKey.setText(p.getString("twelve_key","")); minScore.setText(p.getString("min_score","72")); pointSize.setText(p.getString("point_size","1.0"));
        tp1.setText(p.getString("tp1_points","8")); tp2.setText(p.getString("tp2_points","10")); minRr.setText(p.getString("min_rr","1.0"));
        sessionOnly.setChecked(p.getBoolean("session_only",false)); goldAlerts.setChecked(p.getBoolean("gold_alerts",true));

        SharedPreferences cp=getSharedPreferences("scw",MODE_PRIVATE);
        cryptoAlerts.setChecked(cp.getBoolean("btc_notifications",true)&&cp.getBoolean("token_notifications",true));
        evmWallets.setText(cp.getString("evm_wallets",""));
        evmChains.setText(cp.getString("evm_chains","ethereum,base,arbitrum,optimism,bsc,polygon,avalanche,linea,scroll,zksync,mantle,sonic,unichain,berachain,blast,robinhood"));
        solRpc.setText(cp.getString("rpc_url","https://api.mainnet-beta.solana.com"));
        tokenMinLiq.setText(cp.getString("token_min_liq","50000")); tokenMinVol.setText(cp.getString("token_min_vol","20000"));
        tokenMinMc.setText(cp.getString("token_min_mc","100000")); tokenMaxMc.setText(cp.getString("token_max_mc","20000000"));
        smartMinScore.setText(cp.getString("smart_min_score","70")); smartMinWinrate.setText(cp.getString("smart_min_winrate","45"));
        smartMinHold.setText(cp.getString("smart_min_hold_hours","24")); smartMaxFastExit.setText(cp.getString("smart_max_fast_exit_pct","35"));
        smartOnlyQualified.setChecked(cp.getBoolean("smart_only_qualified",true));
        customName.setText(cp.getString("custom_evm_name","")); customSlug.setText(cp.getString("custom_evm_slug","")); customRpc.setText(cp.getString("custom_evm_rpc",""));
        customExplorer.setText(cp.getString("custom_evm_explorer","")); customNative.setText(cp.getString("custom_evm_native","ETH"));

        ((Button)findViewById(R.id.saveSettingsButton)).setOnClickListener(v->save());
        ((Button)findViewById(R.id.backButton)).setOnClickListener(v->finish());
    }

    private void save(){
        double score=number(minScore.getText().toString(),72),ps=number(pointSize.getText().toString(),1),t1=number(tp1.getText().toString(),8),t2=number(tp2.getText().toString(),10),rr=number(minRr.getText().toString(),1.0);
        if(score<55||score>95){toast("Use a confidence threshold between 55 and 95");return;}
        if(ps<=0||t1<=0||t2<t1){toast("Check point size and targets");return;}
        if(rr<0.7||rr>5){toast("Use a minimum R:R between 0.7 and 5.0");return;}
        double liq=number(tokenMinLiq.getText().toString(),50000),vol=number(tokenMinVol.getText().toString(),20000),minMc=number(tokenMinMc.getText().toString(),100000),maxMc=number(tokenMaxMc.getText().toString(),20000000);
        if(liq<0||vol<0||minMc<0||maxMc<=minMc){toast("Check Early Token Watch market filters");return;}
        double traderScore=number(smartMinScore.getText().toString(),70),traderWin=number(smartMinWinrate.getText().toString(),45),traderHold=number(smartMinHold.getText().toString(),24),fastExit=number(smartMaxFastExit.getText().toString(),35);
        if(traderScore<40||traderScore>100||traderWin<25||traderWin>100||traderHold<1||traderHold>720||fastExit<0||fastExit>100){toast("Check Smart Trader qualification thresholds");return;}

        getSharedPreferences("smw",MODE_PRIVATE).edit()
                .putString("twelve_key",apiKey.getText().toString().trim()).putString("min_score",cleanNum(score)).putString("point_size",cleanNum(ps))
                .putString("tp1_points",cleanNum(t1)).putString("tp2_points",cleanNum(t2)).putString("min_rr",cleanNum(rr))
                .putBoolean("session_only",sessionOnly.isChecked()).putBoolean("gold_alerts",goldAlerts.isChecked()).putString("live_feed_state","reconnect requested").apply();

        getSharedPreferences("scw",MODE_PRIVATE).edit()
                .putBoolean("btc_notifications",cryptoAlerts.isChecked()).putBoolean("token_notifications",cryptoAlerts.isChecked())
                .putString("evm_wallets",evmWallets.getText().toString().trim()).putString("evm_chains",evmChains.getText().toString().trim().toLowerCase())
                .putString("rpc_url",solRpc.getText().toString().trim())
                .putString("token_min_liq",cleanNum(liq)).putString("token_min_vol",cleanNum(vol)).putString("token_min_mc",cleanNum(minMc)).putString("token_max_mc",cleanNum(maxMc))
                .putBoolean("smart_only_qualified",smartOnlyQualified.isChecked()).putString("smart_min_score",cleanNum(traderScore)).putString("smart_min_winrate",cleanNum(traderWin))
                .putString("smart_min_hold_hours",cleanNum(traderHold)).putString("smart_max_fast_exit_pct",cleanNum(fastExit))
                .putString("custom_evm_name",customName.getText().toString().trim()).putString("custom_evm_slug",customSlug.getText().toString().trim().toLowerCase())
                .putString("custom_evm_rpc",customRpc.getText().toString().trim()).putString("custom_evm_explorer",customExplorer.getText().toString().trim())
                .putString("custom_evm_native",customNative.getText().toString().trim().isEmpty()?"ETH":customNative.getText().toString().trim()).apply();
        SmartTraderQualificationEngine.ensureSeedProfiles(this);
        Toast.makeText(this,"Settings saved • trader qualification recalculated",Toast.LENGTH_SHORT).show();
    }

    private double number(String s,double d){try{return Double.parseDouble(s.trim());}catch(Exception e){return d;}}
    private String cleanNum(double x){return x==Math.rint(x)?String.valueOf((long)x):String.valueOf(x);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
