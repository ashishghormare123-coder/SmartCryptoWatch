package com.smartmarketwatch.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class NotificationHelper {
    public static final String ALERT_CHANNEL = "smw_trade_alerts";
    public static final String LIVE_CHANNEL = "smw_live_monitor";
    private NotificationHelper() {}

    public static void ensureChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel alerts = new NotificationChannel(ALERT_CHANNEL, "Smart trade alerts", NotificationManager.IMPORTANCE_HIGH);
            alerts.setDescription("Actionable XAUUSD, BTC trader and early-token alerts");
            nm.createNotificationChannel(alerts);
            NotificationChannel live = new NotificationChannel(LIVE_CHANNEL, "Live XAU monitor", NotificationManager.IMPORTANCE_LOW);
            live.setDescription("Persistent status while the XAUUSD live monitor is running");
            nm.createNotificationChannel(live);
        }
    }

    public static void notify(Context context, String title, String text, int id) {
        ensureChannels(context);
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, ALERT_CHANNEL)
                : new Notification.Builder(context);
        b.setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setAutoCancel(true)
                .setContentIntent(pi);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(id, b.build());
    }

    public static Notification liveNotification(Context context, String text) {
        return persistentNotification(context, "XAUUSD live monitor", text);
    }

    public static Notification persistentNotification(Context context, String title, String text) {
        ensureChannels(context);
        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, LIVE_CHANNEL)
                : new Notification.Builder(context);
        return b.setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }
}
