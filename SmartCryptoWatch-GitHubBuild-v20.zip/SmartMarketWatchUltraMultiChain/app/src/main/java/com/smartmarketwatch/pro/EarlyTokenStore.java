package com.smartmarketwatch.pro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Lightweight local event store for multi-chain smart-wallet token events. */
public final class EarlyTokenStore {
    private static final String PREF = "scw";
    private static final String KEY = "early_token_events_v4";
    private static final int MAX_EVENTS = 200;

    private EarlyTokenStore() {}

    public static class Event {
        public String id = "";
        public String chain = "";
        public String chainSlug = "";
        public String trader = "";
        public String traderAddress = "";
        public String action = "BUY";
        public String confidence = "";
        public String tokenName = "";
        public String tokenSymbol = "";
        public String tokenAddress = "";
        public String txHash = "";
        public String dexId = "";
        public String pairAddress = "";
        public String dexUrl = "";
        public String explorerTxUrl = "";
        public String explorerTraderUrl = "";
        public String explorerTokenUrl = "";
        public String spendLabel = "";
        public String riskNote = "";
        public long timestamp = 0L;
        public long pairCreatedAt = 0L;
        public double tokenAmount = 0;
        public double walletTokenBalance = -1;
        public double estimatedSpendUsd = 0;
        public double detectionPriceUsd = 0;
        public double marketCap = 0;
        public double fdv = 0;
        public double liquidityUsd = 0;
        public double volume24h = 0;
        public double priceChange5m = Double.NaN;
        public double priceChange1h = Double.NaN;
        public double priceChange6h = Double.NaN;
        public double priceChange24h = Double.NaN;
        public int buys5m = -1;
        public int sells5m = -1;
        public int buys1h = -1;
        public int sells1h = -1;
        public double top10Pct = -1;
        public boolean qualifying = false;

        // Smart Trader Qualification Engine snapshot attached at detection time.
        public int traderScore = 0;
        public String traderStatus = "";
        public String traderReason = "";
        public String traderSource = "";
        public String traderSourceUrl = "";
        public long traderSourceAsOf = 0L;
        public double traderWinRate30d = Double.NaN;
        public double traderPnlUsd30d = Double.NaN;
        public double traderAvgHoldHours30d = Double.NaN;
        public int traderObservedClosed = 0;
        public int traderObservedMoonshots = 0;
        public double realizedRoiPct = Double.NaN;
        public double positionRemaining = -1;

        JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id); o.put("chain", chain); o.put("chainSlug", chainSlug);
                o.put("trader", trader); o.put("traderAddress", traderAddress); o.put("action", action);
                o.put("confidence", confidence); o.put("tokenName", tokenName); o.put("tokenSymbol", tokenSymbol);
                o.put("tokenAddress", tokenAddress); o.put("txHash", txHash); o.put("dexId", dexId);
                o.put("pairAddress", pairAddress); o.put("dexUrl", dexUrl); o.put("explorerTxUrl", explorerTxUrl);
                o.put("explorerTraderUrl", explorerTraderUrl); o.put("explorerTokenUrl", explorerTokenUrl);
                o.put("spendLabel", spendLabel); o.put("riskNote", riskNote); o.put("timestamp", timestamp);
                o.put("pairCreatedAt", pairCreatedAt); o.put("tokenAmount", tokenAmount);
                o.put("walletTokenBalance", walletTokenBalance); o.put("estimatedSpendUsd", estimatedSpendUsd);
                o.put("detectionPriceUsd", detectionPriceUsd); o.put("marketCap", marketCap); o.put("fdv", fdv);
                o.put("liquidityUsd", liquidityUsd); o.put("volume24h", volume24h);
                putDouble(o, "priceChange5m", priceChange5m); putDouble(o, "priceChange1h", priceChange1h);
                putDouble(o, "priceChange6h", priceChange6h); putDouble(o, "priceChange24h", priceChange24h);
                o.put("buys5m", buys5m); o.put("sells5m", sells5m); o.put("buys1h", buys1h); o.put("sells1h", sells1h);
                o.put("top10Pct", top10Pct); o.put("qualifying", qualifying);
                o.put("traderScore", traderScore); o.put("traderStatus", traderStatus); o.put("traderReason", traderReason); o.put("traderSource", traderSource);
                o.put("traderSourceUrl", traderSourceUrl); o.put("traderSourceAsOf", traderSourceAsOf);
                putDouble(o, "traderWinRate30d", traderWinRate30d); putDouble(o, "traderPnlUsd30d", traderPnlUsd30d); putDouble(o, "traderAvgHoldHours30d", traderAvgHoldHours30d);
                o.put("traderObservedClosed", traderObservedClosed); o.put("traderObservedMoonshots", traderObservedMoonshots);
                putDouble(o, "realizedRoiPct", realizedRoiPct); o.put("positionRemaining", positionRemaining);
            } catch (Exception ignored) {}
            return o;
        }

        static Event fromJson(JSONObject o) {
            Event e = new Event();
            e.id=o.optString("id",""); e.chain=o.optString("chain",""); e.chainSlug=o.optString("chainSlug","");
            e.trader=o.optString("trader",""); e.traderAddress=o.optString("traderAddress",""); e.action=o.optString("action","BUY");
            e.confidence=o.optString("confidence",""); e.tokenName=o.optString("tokenName",""); e.tokenSymbol=o.optString("tokenSymbol","");
            e.tokenAddress=o.optString("tokenAddress",""); e.txHash=o.optString("txHash",""); e.dexId=o.optString("dexId","");
            e.pairAddress=o.optString("pairAddress",""); e.dexUrl=o.optString("dexUrl",""); e.explorerTxUrl=o.optString("explorerTxUrl","");
            e.explorerTraderUrl=o.optString("explorerTraderUrl",""); e.explorerTokenUrl=o.optString("explorerTokenUrl","");
            e.spendLabel=o.optString("spendLabel",""); e.riskNote=o.optString("riskNote",""); e.timestamp=o.optLong("timestamp",0L);
            e.pairCreatedAt=o.optLong("pairCreatedAt",0L); e.tokenAmount=o.optDouble("tokenAmount",0);
            e.walletTokenBalance=o.optDouble("walletTokenBalance",-1); e.estimatedSpendUsd=o.optDouble("estimatedSpendUsd",0);
            e.detectionPriceUsd=o.optDouble("detectionPriceUsd",0); e.marketCap=o.optDouble("marketCap",0); e.fdv=o.optDouble("fdv",0);
            e.liquidityUsd=o.optDouble("liquidityUsd",0); e.volume24h=o.optDouble("volume24h",0);
            e.priceChange5m=optNullableDouble(o,"priceChange5m"); e.priceChange1h=optNullableDouble(o,"priceChange1h");
            e.priceChange6h=optNullableDouble(o,"priceChange6h"); e.priceChange24h=optNullableDouble(o,"priceChange24h");
            e.buys5m=o.optInt("buys5m",-1); e.sells5m=o.optInt("sells5m",-1); e.buys1h=o.optInt("buys1h",-1); e.sells1h=o.optInt("sells1h",-1);
            e.top10Pct=o.optDouble("top10Pct",-1); e.qualifying=o.optBoolean("qualifying",false);
            e.traderScore=o.optInt("traderScore",0); e.traderStatus=o.optString("traderStatus",""); e.traderReason=o.optString("traderReason",""); e.traderSource=o.optString("traderSource","");
            e.traderSourceUrl=o.optString("traderSourceUrl",""); e.traderSourceAsOf=o.optLong("traderSourceAsOf",0L);
            e.traderWinRate30d=optNullableDouble(o,"traderWinRate30d"); e.traderPnlUsd30d=optNullableDouble(o,"traderPnlUsd30d"); e.traderAvgHoldHours30d=optNullableDouble(o,"traderAvgHoldHours30d");
            e.traderObservedClosed=o.optInt("traderObservedClosed",0); e.traderObservedMoonshots=o.optInt("traderObservedMoonshots",0);
            e.realizedRoiPct=optNullableDouble(o,"realizedRoiPct"); e.positionRemaining=o.optDouble("positionRemaining",-1);
            return e;
        }

        private static void putDouble(JSONObject o,String k,double v) throws Exception {
            if(Double.isNaN(v)||Double.isInfinite(v)) o.put(k,JSONObject.NULL); else o.put(k,v);
        }
        private static double optNullableDouble(JSONObject o,String k){return o.isNull(k)?Double.NaN:o.optDouble(k,Double.NaN);}
    }

    public static synchronized boolean add(Context c, Event e) {
        if (e == null) return false;
        if (e.id == null || e.id.isEmpty()) e.id = e.chainSlug + "|" + e.txHash + "|" + e.tokenAddress + "|" + e.traderAddress;
        List<Event> list = get(c);
        for (Event old : list) if (e.id.equals(old.id)) return false;
        list.add(0, e);
        if (list.size() > MAX_EVENTS) list = new ArrayList<>(list.subList(0, MAX_EVENTS));
        save(c, list);
        return true;
    }

    public static synchronized List<Event> get(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = p.getString(KEY, "[]");
        List<Event> list = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(raw);
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.optJSONObject(i); if(o!=null) list.add(Event.fromJson(o));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static synchronized void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    private static void save(Context c, List<Event> list) {
        JSONArray a = new JSONArray();
        for (Event e : list) a.put(e.toJson());
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }
}
